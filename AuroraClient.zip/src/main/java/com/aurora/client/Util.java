package com.aurora.client;

import com.mojang.blaze3d.matrix.MatrixStack;
import net.minecraft.client.gui.AbstractGui;
import net.minecraft.client.gui.FontRenderer;

public class Util {
    private static final int[][] THEMES = {
            {0x8B5CF6, 0xEC4899}, // Aurora
            {0x38BDF8, 0x6366F1}, // Ocean
            {0xF97316, 0xEF4444}, // Sunset
            {0x34D399, 0x22D3EE}, // Mint
            {0xE5E7EB, 0x9CA3AF}  // Mono
    };

    public static int lerp(int a, int b, float t) {
        int r = (int) (((a >> 16) & 255) * (1 - t) + ((b >> 16) & 255) * t);
        int g = (int) (((a >> 8) & 255) * (1 - t) + ((b >> 8) & 255) * t);
        int bl = (int) ((a & 255) * (1 - t) + (b & 255) * t);
        return (r << 16) | (g << 8) | bl;
    }

    public static int mix(int a, int b, float t) { return 0xFF000000 | lerp(a, b, t); }

    public static int withAlpha(int color, int alpha) { return (alpha << 24) | (color & 0xFFFFFF); }

    /** Theme accent color, optionally animated. */
    public static int accent(float offset) {
        int[] c = THEMES[Modules.THEME.mode];
        if (!Modules.ANIMATED.enabled) return 0xFF000000 | c[0];
        double t = (Math.sin(System.currentTimeMillis() / 700.0 + offset * 6.0) + 1) / 2;
        return mix(c[0], c[1], (float) t);
    }

    public static int gradientText(MatrixStack ms, FontRenderer fr, String text, float x, float y, float offset) {
        float cx = x;
        for (int i = 0; i < text.length(); i++) {
            String ch = String.valueOf(text.charAt(i));
            fr.drawShadow(ms, ch, cx, y, accent(offset + i * 0.12f));
            cx += fr.width(ch);
        }
        return (int) (cx - x);
    }

    /** Rounded rectangle built from horizontal strips. */
    public static void rrect(MatrixStack ms, float x1, float y1, float x2, float y2, int r, int color) {
        int ax = (int) x1, ay = (int) y1, bx = (int) x2, by = (int) y2;
        r = Math.max(0, Math.min(r, Math.min((bx - ax) / 2, (by - ay) / 2)));
        AbstractGui.fill(ms, ax, ay + r, bx, by - r, color);
        for (int i = 0; i < r; i++) {
            double d = r - i - 0.5;
            int inset = (int) Math.round(r - Math.sqrt(r * r - d * d));
            AbstractGui.fill(ms, ax + inset, ay + i, bx - inset, ay + i + 1, color);
            AbstractGui.fill(ms, ax + inset, by - i - 1, bx - inset, by - i, color);
        }
    }
}
