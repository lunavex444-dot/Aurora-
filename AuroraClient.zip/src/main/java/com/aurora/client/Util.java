package com.aurora.client;

import com.mojang.blaze3d.matrix.MatrixStack;
import net.minecraft.client.gui.AbstractGui;
import net.minecraft.client.gui.FontRenderer;

public class Util {
    private static final int[][] THEMES = {
            {0x8B5CF6, 0xEC4899}, // Aurora
            {0x38BDF8, 0x6366F1}, // Ocean
            {0xF97316, 0xEF4444}, // Sunset
            {0x34D399, 0x22D3EE}, // Mint
            {0xFB7185, 0xE11D48}, // Cherry
            {0xFBBF24, 0xEF4444}, // Gold
            {0x22D3EE, 0xA3E635}, // Neon
            {0xE5E7EB, 0x9CA3AF}  // Mono
    };

    public static int lerp(int a, int b, float t) {
        int r = (int) (((a >> 16) & 255) * (1 - t) + ((b >> 16) & 255) * t);
        int g = (int) (((a >> 8) & 255) * (1 - t) + ((b >> 8) & 255) * t);
        int bl = (int) ((a & 255) * (1 - t) + (b & 255) * t);
        return (r << 16) | (g << 8) | bl;
    }

    public static int themeColor(int i) {
        return THEMES[Math.max(0, Math.min(THEMES.length - 1, i))][0];
    }

    public static int mix(int a, int b, float t) { return 0xFF000000 | lerp(a, b, t); }

    public static int withAlpha(int color, int alpha) { return (alpha << 24) | (color & 0xFFFFFF); }

    /** Theme accent color, optionally animated. */
    public static int accent(float offset) {
        int[] c = THEMES[Modules.THEME.mode];
        if (!Modules.ANIMATED.enabled) return 0xFF000000 | c[0];
        double t = (Math.sin(System.currentTimeMillis() / 700.0 + offset * 6.0) + 1) / 2;
        return mix(c[0], c[1], (float) t);
    }

    public static int gradientText(MatrixStack ms, FontRenderer fr, String text, float x, float y, float offset) {
        float cx = x;
        for (int i = 0; i < text.length(); i++) {
            String ch = String.valueOf(text.charAt(i));
            fr.drawShadow(ms, ch, cx, y, accent(offset + i * 0.12f));
            cx += fr.width(ch);
        }
        return (int) (cx - x);
    }

    /** Rounded rectangle built from horizontal strips. */
    public static void rrect(MatrixStack ms, float x1, float y1, float x2, float y2, int r, int color) {
        int ax = (int) x1, ay = (int) y1, bx = (int) x2, by = (int) y2;
        r = Math.max(0, Math.min(r, Math.min((bx - ax) / 2, (by - ay) / 2)));
        AbstractGui.fill(ms, ax, ay + r, bx, by - r, color);
        for (int i = 0; i < r; i++) {
            double d = r - i - 0.5;
            int inset = (int) Math.round(r - Math.sqrt(r * r - d * d));
            AbstractGui.fill(ms, ax + inset, ay + i, bx - inset, ay + i + 1, color);
            AbstractGui.fill(ms, ax + inset, by - i - 1, bx - inset, by - i, color);
        }
    }

    /** Логотип Aurora: скруглённая плашка с "занавесом" северного сияния. */
    public static void logo(MatrixStack ms, int x, int y, int s) {
        rrect(ms, x - 1, y - 1, x + s + 1, y + s + 1, Math.max(3, s / 3), withAlpha(accent(0.3f), 0x55));
        rrect(ms, x, y, x + s, y + s, Math.max(3, s / 3), accent(0f));
        float[] hs = {0.40f, 0.80f, 0.60f, 0.30f};
        int bw = Math.max(1, s / 8);
        int m = Math.max(2, s / 4);
        int gap = Math.max(1, (s - 2 * m - 4 * bw) / 3);
        int total = 4 * bw + 3 * gap;
        int sx = x + (s - total) / 2;
        for (int i = 0; i < 4; i++) {
            int h = Math.max(2, Math.round((s - 2 * m + 2) * hs[i]));
            int bx = sx + i * (bw + gap);
            int by = y + (s - h) / 2;
            AbstractGui.fill(ms, bx, by, bx + bw, by + h, 0xFFFFFFFF);
        }
    }

    /** Рисует иконку из строкового битмапа ('#' = пиксель). */
    public static void icon(MatrixStack ms, String[] bmp, int x, int y, int color) {
        for (int r = 0; r < bmp.length; r++)
            for (int c = 0; c < bmp[r].length(); c++)
                if (bmp[r].charAt(c) == '#') AbstractGui.fill(ms, x + c, y + r, x + c + 1, y + r + 1, color);
    }

    public static final String[][] ICONS = {
        // COMBAT - прицел
        {"....#....", "..#####..", ".#..#..#.", ".#..#..#.", "#########", ".#..#..#.", ".#..#..#.", "..#####..", "....#...."},
        // MOVEMENT - стрелка
        {"....#....", "...###...", "..#.#.#..", ".#..#..#.", "....#....", "....#....", "....#....", "....#....", "........."},
        // HUD - окно
        {"#########", "#.......#", "#########", "#..#....#", "#..#....#", "#..#....#", "#..#....#", "#.......#", "#########"},
        // VISUALS - глаз
        {".........", ".........", "..#####..", ".#..#..#.", "#..###..#", ".#..#..#.", "..#####..", ".........", "........."},
        // EFFECTS - звезда
        {"....#....", "....#....", "...###...", "..#####..", "#########", "..#####..", "...###...", "....#....", "....#...."},
        // COSMETICS - корона
        {".........", "#...#...#", "##.###.##", "#########", "#########", "#########", ".........", ".........", "........."},
        // CLIENT - ползунки
        {".........", "##.######", "##.######", ".........", "######.##", "######.##", ".........", "##..#####", "........."},
        // CONFIGS - дискета
        {"#########", "#.#####.#", "#.#####.#", "#.......#", "#.#####.#", "#.#####.#", "#.#####.#", "#########", "........."}
    };
}
