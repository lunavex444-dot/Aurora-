package com.aurora.client;

import java.util.Arrays;
import java.util.List;

public class Modules {
    public static final Module WATERMARK = new Module("Watermark", "Плашка сверху слева", Category.HUD, true);
    public static final Module COORDS    = new Module("Coordinates", "Координаты XYZ", Category.HUD, true);
    public static final Module ARRAYLIST = new Module("ArrayList", "Список модулей справа", Category.HUD, true);

    public static final Module FULLBRIGHT = new Module("Fullbright", "Максимальная яркость", Category.VISUALS, false);
    public static final Module ZOOM       = new Module("Zoom", "Приближение камеры", Category.VISUALS, false);

    public static final Module THEME    = new Module("Theme", "Цвет интерфейса", Category.CLIENT,
            new String[]{"Aurora", "Ocean", "Sunset", "Mint", "Mono"});
    public static final Module ANIMATED = new Module("Animated", "Переливы цвета", Category.CLIENT, true);

    public static final List<Module> ALL = Arrays.asList(
            WATERMARK, COORDS, ARRAYLIST, FULLBRIGHT, ZOOM, THEME, ANIMATED);
}
