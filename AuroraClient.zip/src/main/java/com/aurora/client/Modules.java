package com.aurora.client;

import net.minecraft.client.Minecraft;

import java.util.Arrays;
import java.util.List;

public class Modules {
    // Combat
    public static final Module TARGETHUD  = new Module("Target HUD", "Здоровье и ник цели", Category.COMBAT, true);
    public static final Module AUTOSPRINT = new Module("AutoSprint", "Авто-бег при ходьбе", Category.COMBAT, false);

    // Movement
    public static final Module GUIMOVE  = new Module("GuiMove", "Ходьба при открытом меню", Category.MOVEMENT, false);
    public static final Module AUTOJUMP = new Module("AutoJump", "Авто-прыжок на блоки", Category.MOVEMENT, false);

    // HUD
    public static final Module WATERMARK  = new Module("Watermark", "Плашка сверху слева", Category.HUD, true);
    public static final Module COORDS     = new Module("Coordinates", "Координаты XYZ", Category.HUD, true);
    public static final Module ARRAYLIST  = new Module("ArrayList", "Список модулей справа", Category.HUD, true);
    public static final Module KEYSTROKES = new Module("Keystrokes", "WASD, клики и CPS", Category.HUD, false);
    public static final Module ARMOR      = new Module("ArmorHUD", "Броня и прочность", Category.HUD, false);

    // Visuals
    public static final Module FULLBRIGHT  = new Module("Fullbright", "Максимальная яркость", Category.VISUALS, false);
    public static final Module ZOOM        = new Module("Zoom", "Приближение камеры", Category.VISUALS, false);
    public static final Module CROSSHAIR   = new Module("Crosshair", "Свой прицел", Category.VISUALS, false);
    public static final Module CROSSSTYLE  = new Module("Crosshair Style", "Вид прицела", Category.VISUALS,
            new String[]{"Cross", "Dot", "Ring"});

    // Client
    public static final Module THEME    = new Module("Theme", "Цвет интерфейса", Category.CLIENT,
            new String[]{"Aurora", "Ocean", "Sunset", "Mint", "Cherry", "Gold", "Neon", "Mono"});
    public static final Module ANIMATED = new Module("Animated", "Переливы цвета", Category.CLIENT, true);
    public static final Module SHOWPING = new Module("Show Ping", "Пинг в ватермарке", Category.CLIENT, true);
    public static final Module SHOWCPS  = new Module("Show CPS", "CPS в ватермарке", Category.CLIENT, true);
    public static final Module HUDEDIT  = new Module("HUD Editor", "Перетащи элементы HUD", Category.CLIENT,
            () -> Minecraft.getInstance().setScreen(new HudEditor()));

    public static final List<Module> ALL = Arrays.asList(
            TARGETHUD, AUTOSPRINT,
            GUIMOVE, AUTOJUMP,
            WATERMARK, COORDS, ARRAYLIST, KEYSTROKES, ARMOR,
            FULLBRIGHT, ZOOM, CROSSHAIR, CROSSSTYLE,
            THEME, ANIMATED, SHOWPING, SHOWCPS, HUDEDIT);
}
