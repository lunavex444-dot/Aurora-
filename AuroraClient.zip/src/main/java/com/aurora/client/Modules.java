package com.aurora.client;

import net.minecraft.client.Minecraft;

import java.util.Arrays;
import java.util.List;

public class Modules {
    // Combat
    public static final Module TARGETHUD  = new Module("Target HUD", "Здоровье и ник цели", Category.COMBAT, true);
    public static final Module AUTOSPRINT = new Module("AutoSprint", "Авто-бег при ходьбе", Category.COMBAT, false);

    // Combat: KillAura
    public static final Module KILLAURA     = new Module("KillAura", "Авто-атака целей рядом", Category.COMBAT, false);
    public static final Module AURARANGE    = new Module("Aura Range", "Дальность атаки", Category.COMBAT,
            new String[]{"3.0", "3.5", "4.0", "4.5", "5.0", "6.0"});
    public static final Module AURAROTATION = new Module("Aura Rotation", "Поворот к цели", Category.COMBAT,
            new String[]{"Smooth", "Snap", "None"});
    public static final Module AURATARGETS  = new Module("Aura Targets", "Кого бить", Category.COMBAT,
            new String[]{"Players", "Mobs", "All"});
    public static final Module AURAPRIORITY = new Module("Aura Priority", "Приоритет цели", Category.COMBAT,
            new String[]{"Distance", "Health"});
    public static final Module AURADELAY    = new Module("Aura Delay", "Скорость ударов", Category.COMBAT,
            new String[]{"Cooldown", "100ms", "60ms"});

    // Combat: aim / clicks
    public static final Module AIMASSIST  = new Module("AimAssist", "Плавное наведение на цель", Category.COMBAT, false);
    public static final Module AIMSPEED   = new Module("Aim Speed", "Скорость наведения", Category.COMBAT,
            new String[]{"Slow", "Medium", "Fast"});
    public static final Module TRIGGERBOT = new Module("TriggerBot", "Бьёт, когда прицел на цели", Category.COMBAT, false);
    public static final Module AUTOCLICKER = new Module("AutoClicker", "Авто-клик при зажатой ЛКМ", Category.COMBAT, false);
    public static final Module CLICKCPS   = new Module("Click CPS", "Скорость автокликера", Category.COMBAT,
            new String[]{"6", "8", "10", "12", "14", "16", "20"});

    // Combat: hit modifiers
    public static final Module CRITICALS   = new Module("Criticals", "Криты на земле (пакеты)", Category.COMBAT, false);
    public static final Module SPRINTRESET = new Module("Sprint Reset", "W-tap: больше отбрасывания", Category.COMBAT, false);
    public static final Module VELOCITY    = new Module("Velocity", "Меньше отбрасывания", Category.COMBAT, false);
    public static final Module VELOCITYAMT = new Module("Velocity Amount", "Сколько отброса оставить", Category.COMBAT,
            new String[]{"0%", "25%", "50%", "75%"});

    // Combat: totem
    public static final Module AUTOTOTEM = new Module("AutoTotem", "Тотем в левую руку", Category.COMBAT, false);
    public static final Module TOTEMHP   = new Module("Totem HP", "Когда брать тотем", Category.COMBAT,
            new String[]{"Always", "10 HP", "6 HP"});

    // Movement
    public static final Module GUIMOVE  = new Module("GuiMove", "Ходьба при открытом меню", Category.MOVEMENT, false);
    public static final Module AUTOJUMP = new Module("AutoJump", "Авто-прыжок на блоки", Category.MOVEMENT, false);

    // HUD
    public static final Module WATERMARK  = new Module("Watermark", "Плашка сверху слева", Category.HUD, true);
    public static final Module COORDS     = new Module("Coordinates", "Координаты XYZ", Category.HUD, true);
    public static final Module ARRAYLIST  = new Module("ArrayList", "Список модулей справа", Category.HUD, true);
    public static final Module KEYSTROKES = new Module("Keystrokes", "WASD, клики и CPS", Category.HUD, false);
    public static final Module ARMOR      = new Module("ArmorHUD", "Броня и прочность", Category.HUD, false);

    // Visuals
    public static final Module FULLBRIGHT  = new Module("Fullbright", "Максимальная яркость", Category.VISUALS, false);
    public static final Module ZOOM        = new Module("Zoom", "Приближение камеры", Category.VISUALS, false);
    public static final Module CROSSHAIR   = new Module("Crosshair", "Свой прицел", Category.VISUALS, false);
    public static final Module CROSSSTYLE  = new Module("Crosshair Style", "Вид прицела", Category.VISUALS,
            new String[]{"Cross", "Dot", "Ring"});

    // Client
    public static final Module THEME    = new Module("Theme", "Цвет интерфейса", Category.CLIENT,
            new String[]{"Aurora", "Ocean", "Sunset", "Mint", "Cherry", "Gold", "Neon", "Mono"});
    public static final Module ANIMATED = new Module("Animated", "Переливы цвета", Category.CLIENT, true);
    public static final Module SHOWPING = new Module("Show Ping", "Пинг в ватермарке", Category.CLIENT, true);
    public static final Module SHOWCPS  = new Module("Show CPS", "CPS в ватермарке", Category.CLIENT, true);
    public static final Module HUDEDIT  = new Module("HUD Editor", "Перетащи элементы HUD", Category.CLIENT,
            () -> Minecraft.getInstance().setScreen(new HudEditor()));

    public static final List<Module> ALL = Arrays.asList(
            TARGETHUD, AUTOSPRINT,
            KILLAURA, AURARANGE, AURAROTATION, AURATARGETS, AURAPRIORITY, AURADELAY,
            AIMASSIST, AIMSPEED, TRIGGERBOT, AUTOCLICKER, CLICKCPS,
            CRITICALS, SPRINTRESET, VELOCITY, VELOCITYAMT,
            AUTOTOTEM, TOTEMHP,
            GUIMOVE, AUTOJUMP,
            WATERMARK, COORDS, ARRAYLIST, KEYSTROKES, ARMOR,
            FULLBRIGHT, ZOOM, CROSSHAIR, CROSSSTYLE,
            THEME, ANIMATED, SHOWPING, SHOWCPS, HUDEDIT);

    static {
        CLICKCPS.mode = 2;    // 10 CPS
        VELOCITYAMT.mode = 2; // 50%
    }
}
