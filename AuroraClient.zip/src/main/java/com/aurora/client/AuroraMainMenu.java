package com.aurora.client;

import com.mojang.blaze3d.matrix.MatrixStack;
import net.minecraft.client.gui.screen.MultiplayerScreen;
import net.minecraft.client.gui.screen.OptionsScreen;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.screen.WorldSelectionScreen;
import net.minecraft.client.gui.widget.button.Button;
import net.minecraft.util.text.StringTextComponent;

import java.util.Random;

public class AuroraMainMenu extends Screen {
    private final Star[] stars = new Star[55];
    private float fade;

    public AuroraMainMenu() {
        super(new StringTextComponent("Aurora Client"));
        Random r = new Random(0xA0F0);
        for (int i = 0; i < stars.length; i++) {
            stars[i] = new Star(r);
        }
    }

    @Override
    protected void init() {
        int bw = Math.min(260, width - 40);
        int bh = 25;
        int gap = 7;
        int total = bh * 4 + gap * 3;
        int x = (width - bw) / 2;
        int y = Math.max(82, height / 2 - total / 2 + 12);

        addButton(new Button(x, y, bw, bh, new StringTextComponent("Singleplayer"),
                b -> minecraft.setScreen(new WorldSelectionScreen(this))));
        addButton(new Button(x, y + bh + gap, bw, bh, new StringTextComponent("Multiplayer"),
                b -> minecraft.setScreen(new MultiplayerScreen(this))));
        addButton(new Button(x, y + (bh + gap) * 2, bw, bh, new StringTextComponent("Options"),
                b -> minecraft.setScreen(new OptionsScreen(this, minecraft.options))));
        addButton(new Button(x, y + (bh + gap) * 3, bw, bh, new StringTextComponent("Quit Game"),
                b -> minecraft.stop()));
    }

    @Override
    public void render(MatrixStack ms, int mouseX, int mouseY, float partialTicks) {
        fade = Math.min(1f, fade + 0.045f);
        fill(ms, 0, 0, width, height, 0xFF05050A);
        drawAurora(ms);

        String title = "AURORA";
        String sub = "CLIENT 1.9";
        font.drawShadow(ms, title, (width - font.width(title)) / 2f,
                Math.max(24, height * 0.16f), color(0xFFB98CFF, fade));
        font.drawShadow(ms, sub, (width - font.width(sub)) / 2f,
                Math.max(42, height * 0.16f + 18), color(0xFF77758D, fade));

        String footer = "Aurora Client 1.9  •  Minecraft 1.16.5";
        font.drawShadow(ms, footer, (width - font.width(footer)) / 2f,
                height - 18, 0xFF666675);

        super.render(ms, mouseX, mouseY, partialTicks);
    }

    private void drawAurora(MatrixStack ms) {
        long now = System.currentTimeMillis();
        float t = (now % 12000L) / 12000f;
        int bandW = Math.max(180, width / 2);
        int x1 = (int) ((t * (width + bandW * 2)) - bandW * 2);
        int x2 = (int) (((t + 0.47f) % 1f) * (width + bandW * 2) - bandW * 2);
        fill(ms, x1, 0, x1 + bandW, height, 0x140F0A22);
        fill(ms, x2, 0, x2 + bandW / 2, height, 0x100C1024);

        for (Star star : stars) {
            float sx = (star.x * width + (now * star.speed) % (width + 20)) % (width + 20) - 10;
            float sy = star.y * height;
            int a = 55 + (int)(35 * Math.sin((now / 500.0) + star.phase));
            fill(ms, (int)sx, (int)sy, (int)sx + 1, (int)sy + 1, (a << 24) | 0xD7C9FF);
        }
    }

    private int color(int rgb, float alpha) {
        int a = Math.max(0, Math.min(255, (int)(255 * alpha)));
        return (a << 24) | (rgb & 0xFFFFFF);
    }

    @Override
    public boolean isPauseScreen() {
        return false;
    }

    private static class Star {
        final float x, y, speed, phase;
        Star(Random r) {
            x = r.nextFloat();
            y = r.nextFloat();
            speed = 0.000006f + r.nextFloat() * 0.000012f;
            phase = r.nextFloat() * 6.28f;
        }
    }
}
