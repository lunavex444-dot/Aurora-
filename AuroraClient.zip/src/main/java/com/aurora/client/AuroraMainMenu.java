package com.aurora.client;

import com.mojang.blaze3d.matrix.MatrixStack;
import net.minecraft.client.gui.screen.MainMenuScreen;
import net.minecraft.client.gui.screen.MultiplayerScreen;
import net.minecraft.client.gui.screen.OptionsScreen;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.screen.WorldSelectionScreen;
import net.minecraft.client.gui.widget.button.Button;
import net.minecraft.util.text.StringTextComponent;
import net.minecraftforge.client.event.GuiOpenEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;

public class AuroraMainMenu extends Screen {
    public AuroraMainMenu(){super(new StringTextComponent("Aurora Client 1.9"));}

    @Override protected void init(){
        int bw=Math.min(280,Math.max(210,width/3)),x=(width-bw)/2,y=height/2-5;
        addButton(new Button(x,y,bw,28,new StringTextComponent("Singleplayer"),b->minecraft.setScreen(new WorldSelectionScreen(this))));
        addButton(new Button(x,y+36,bw,28,new StringTextComponent("Multiplayer"),b->minecraft.setScreen(new MultiplayerScreen(this))));
        addButton(new Button(x,y+72,bw,28,new StringTextComponent("Options"),b->minecraft.setScreen(new OptionsScreen(this,minecraft.options))));
        addButton(new Button(x,y+108,bw,28,new StringTextComponent("Quit Game"),b->minecraft.stop()));
    }

    @Override public void render(MatrixStack m,int mx,int my,float pt){
        fill(m,0,0,width,height,0xFF04030B);
        long t=System.currentTimeMillis()/18L;int a=Util.accent(0),b=Util.accent(2);
        for(int i=0;i<20;i++){int yy=(int)((t+i*43)%Math.max(1,height));fill(m,0,yy,width,yy+2,Util.withAlpha(i%2==0?a:b,0x18));}
        for(int i=0;i<60;i++){int sx=(i*97+31)%Math.max(1,width),sy=(i*53+17)%Math.max(1,height);fill(m,sx,sy,sx+1,sy+1,0xA0FFFFFF);}
        int g=Util.accent(0);
        Util.rrect(m,width/2-210,height/2-155,width/2+210,height/2+170,18,Util.withAlpha(g,0x55));
        Util.rrect(m,width/2-206,height/2-151,width/2+206,height/2+166,16,0xD30A0914);
        Util.gradientText(m,font,"AURORA",width/2-70,height/2-122,0);
        font.drawShadow(m,"CLIENT 1.9",width/2-29,height/2-101,0xFFFFFFFF);
        font.drawShadow(m,"Premium Minecraft Client",width/2-64,height/2-82,0xFF9E98AA);
        super.render(m,mx,my,pt);
        font.drawShadow(m,"AuroraClient 1.9 • Minecraft 1.16.5",12,height-22,0xFFAAA3B7);
        font.drawShadow(m,"Made with ♥ by Aurora Team",width-148,height-22,0xFFAAA3B7);
    }
    @Override public boolean isPauseScreen(){return false;}

    public static class Hook {
        @SubscribeEvent public static void onGuiOpen(GuiOpenEvent e){
            if(e.getGui() instanceof MainMenuScreen)e.setGui(new AuroraMainMenu());
        }
    }
}
