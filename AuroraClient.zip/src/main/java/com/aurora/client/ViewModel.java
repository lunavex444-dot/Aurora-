package com.aurora.client;

import com.mojang.blaze3d.matrix.MatrixStack;
import net.minecraft.util.Hand;
import net.minecraft.util.math.vector.Vector3f;
import net.minecraftforge.client.event.RenderHandEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;

/** ViewModel: сдвиг, размер и наклон рук в первом лице. */
public class ViewModel {
    @SubscribeEvent
    public void onHand(RenderHandEvent e) {
        if (!Modules.VIEWMODEL.enabled) return;
        MatrixStack ms = e.getMatrixStack();
        double x = Modules.VMX.value, y = Modules.VMY.value, z = Modules.VMZ.value;
        float s = (float) Math.max(0.2, Modules.VMSCALE.value);
        float roll = (float) Modules.VMROLL.value;
        boolean mainOnly = Modules.VMHANDS.mode == 1;

        // матрица общая для обеих рук: меняем в событии основной руки,
        // а для режима "Main" откатываем перед второй рукой
        if (e.getHand() == Hand.MAIN_HAND) {
            ms.translate(x, y, z);
            if (roll != 0f) ms.mulPose(Vector3f.ZP.rotationDegrees(roll));
            ms.scale(s, s, s);
        } else if (mainOnly) {
            ms.scale(1f / s, 1f / s, 1f / s);
            if (roll != 0f) ms.mulPose(Vector3f.ZP.rotationDegrees(-roll));
            ms.translate(-x, -y, -z);
        }
    }
}
