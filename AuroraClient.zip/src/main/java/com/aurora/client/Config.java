package com.aurora.client;

import net.minecraft.client.Minecraft;

import java.io.*;
import java.util.Properties;

public class Config {
    private static File file() {
        return new File(Minecraft.getInstance().gameDirectory, "auroraclient.properties");
    }

    private static String key(Module m) { return m.name.replace(' ', '_'); }

    public static void load() {
        Properties p = new Properties();
        try (FileInputStream in = new FileInputStream(file())) {
            p.load(in);
        } catch (IOException e) {
            return;
        }
        for (Module m : Modules.ALL) {
            String v = p.getProperty(key(m));
            if (v == null) continue;
            try {
                if (m.isToggle()) { m.enabled = Boolean.parseBoolean(v); m.anim = m.enabled ? 1f : 0f; }
                else m.mode = Math.max(0, Math.min(m.modes.length - 1, Integer.parseInt(v)));
            } catch (NumberFormatException ignored) {}
        }
    }

    public static void save() {
        Properties p = new Properties();
        for (Module m : Modules.ALL)
            p.setProperty(key(m), m.isToggle() ? String.valueOf(m.enabled) : String.valueOf(m.mode));
        try (FileOutputStream out = new FileOutputStream(file())) {
            p.store(out, "Aurora Client");
        } catch (IOException ignored) {}
    }
}
