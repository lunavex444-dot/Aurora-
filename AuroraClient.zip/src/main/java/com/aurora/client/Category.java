package com.aurora.client;

public enum Category {
    COMBAT("Combat", "Боевые функции"),
    MOVEMENT("Movement", "Перемещение"),
    HUD("HUD", "Элементы интерфейса"),
    VISUALS("Visuals", "Визуальные эффекты"),
    CLIENT("Client", "Настройки клиента"),
    CONFIGS("Configs", "Сохранение настроек");

    public final String label, sub;
    Category(String label, String sub) { this.label = label; this.sub = sub; }
}
