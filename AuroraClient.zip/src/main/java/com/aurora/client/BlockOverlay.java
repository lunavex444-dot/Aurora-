package com.aurora.client;

import com.mojang.blaze3d.systems.RenderSystem;
import net.minecraft.block.BlockState;
import net.minecraft.client.Minecraft;
import net.minecraft.client.renderer.BufferBuilder;
import net.minecraft.client.renderer.Tessellator;
import net.minecraft.client.renderer.vertex.DefaultVertexFormats;
import net.minecraft.util.math.AxisAlignedBB;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.BlockRayTraceResult;
import net.minecraft.util.math.RayTraceResult;
import net.minecraft.util.math.shapes.VoxelShape;
import net.minecraft.util.math.vector.Matrix4f;
import net.minecraft.util.math.vector.Vector3d;
import net.minecraftforge.client.event.DrawHighlightEvent;
import net.minecraftforge.client.event.RenderWorldLastEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import org.lwjgl.opengl.GL11;

import java.util.ArrayList;
import java.util.List;

/**
 * BlockOverlay: подсветка блока, на который смотрит игрок.
 * Стили: Fill / Outline / Both. Цвет: Theme / Rainbow / White.
 * Smooth плавно "переезжает" между блоками и плавно гаснет, когда прицел уходит.
 */
public class BlockOverlay {
    private static final double EXPAND = 0.003; // чтобы не мерцало на гранях блока

    private BlockPos lastPos = null;
    private final List<double[]> exact = new ArrayList<>(); // точные боксы формы блока
    private double[] target = null;                          // общий бокс блока
    private double[] cur = null;                             // текущий (сглаженный) бокс
    private float fade = 0f;
    private long lastNano = System.nanoTime();

    /** Прячем ванильную чёрную рамку, когда включён наш оверлей. */
    @SubscribeEvent
    public void onHighlight(DrawHighlightEvent.HighlightBlock e) {
        if (Modules.BLOCKOVERLAY.enabled && Modules.BOVANILLA.enabled) e.setCanceled(true);
    }

    @SubscribeEvent
    public void onWorld(RenderWorldLastEvent e) {
        Minecraft mc = Minecraft.getInstance();
        long now = System.nanoTime();
        float dt = Math.min(0.1f, (now - lastNano) / 1_000_000_000f);
        lastNano = now;

        if (!Modules.BLOCKOVERLAY.enabled || mc.level == null || mc.player == null) {
            fade = 0f; cur = null; lastPos = null;
            return;
        }

        boolean hit = false;
        if (mc.hitResult != null && mc.hitResult.getType() == RayTraceResult.Type.BLOCK) {
            BlockPos pos = ((BlockRayTraceResult) mc.hitResult).getBlockPos();
            BlockState state = mc.level.getBlockState(pos);
            VoxelShape shape = state.getShape(mc.level, pos);
            if (!state.isAir() && !shape.isEmpty()) {
                hit = true;
                if (!pos.equals(lastPos)) {
                    lastPos = pos.immutable();
                    exact.clear();
                    final BlockPos fp = lastPos;
                    shape.forAllBoxes((x1, y1, z1, x2, y2, z2) -> exact.add(new double[]{
                            fp.getX() + x1, fp.getY() + y1, fp.getZ() + z1,
                            fp.getX() + x2, fp.getY() + y2, fp.getZ() + z2}));
                    AxisAlignedBB b = shape.bounds();
                    target = new double[]{fp.getX() + b.minX, fp.getY() + b.minY, fp.getZ() + b.minZ,
                            fp.getX() + b.maxX, fp.getY() + b.maxY, fp.getZ() + b.maxZ};
                    if (cur == null || fade <= 0.02f) cur = target.clone();
                }
            }
        }

        fade = hit ? Math.min(1f, fade + dt * 8f) : Math.max(0f, fade - dt * 5f);
        if (fade <= 0f || target == null || cur == null) return;

        boolean smooth = Modules.BOSMOOTH.enabled;
        if (smooth) {
            float k = 1f - (float) Math.exp(-dt * 18f);
            for (int i = 0; i < 6; i++) cur[i] += (target[i] - cur[i]) * k;
        }

        Vector3d cp = mc.gameRenderer.getMainCamera().getPosition();
        Matrix4f m = e.getMatrixStack().last().pose();

        int style = Modules.BOSTYLE.mode; // 0 Fill, 1 Outline, 2 Both
        float fillA = (float) Modules.BOALPHA.value * fade;
        float lineA = 0.95f * fade;
        int rgb = color();

        List<double[]> boxes = new ArrayList<>();
        if (smooth) boxes.add(cur); else boxes.addAll(exact);

        RenderSystem.enableBlend();
        RenderSystem.defaultBlendFunc();
        RenderSystem.disableTexture();
        RenderSystem.disableCull();
        RenderSystem.depthMask(false);
        RenderSystem.disableAlphaTest();

        Tessellator tess = Tessellator.getInstance();
        BufferBuilder bb = tess.getBuilder();

        if (style != 1) {
            bb.begin(GL11.GL_QUADS, DefaultVertexFormats.POSITION_COLOR);
            for (double[] b : boxes) fillBox(bb, m, cp, b, rgb, fillA);
            tess.end();
        }
        if (style != 0) {
            RenderSystem.lineWidth(2.0f);
            bb.begin(GL11.GL_LINES, DefaultVertexFormats.POSITION_COLOR);
            for (double[] b : boxes) lineBox(bb, m, cp, b, rgb, lineA);
            tess.end();
            RenderSystem.lineWidth(1.0f);
        }

        RenderSystem.depthMask(true);
        RenderSystem.enableCull();
        RenderSystem.enableTexture();
        RenderSystem.enableAlphaTest();
        RenderSystem.defaultBlendFunc();
        RenderSystem.disableBlend();
    }

    // ------------------------------------------------ color
    private int color() {
        switch (Modules.BOCOLOR.mode) {
            case 1:  return hsv((System.currentTimeMillis() % 5000L) / 5000f);
            case 2:  return 0xFFFFFF;
            default: return Util.accent(0.2f) & 0xFFFFFF;
        }
    }

    private int hsv(float h) {
        h = h - (float) Math.floor(h);
        float s = 0.65f, v = 1f;
        int i = (int) (h * 6);
        float f = h * 6 - i;
        float p = v * (1 - s), q = v * (1 - f * s), t = v * (1 - (1 - f) * s);
        float r, g, b;
        switch (i % 6) {
            case 0:  r = v; g = t; b = p; break;
            case 1:  r = q; g = v; b = p; break;
            case 2:  r = p; g = v; b = t; break;
            case 3:  r = p; g = q; b = v; break;
            case 4:  r = t; g = p; b = v; break;
            default: r = v; g = p; b = q; break;
        }
        return ((int) (r * 255) << 16) | ((int) (g * 255) << 8) | (int) (b * 255);
    }

    // ------------------------------------------------ drawing
    private void v(BufferBuilder bb, Matrix4f m, Vector3d cp, double x, double y, double z, int rgb, float a) {
        bb.vertex(m, (float) (x - cp.x), (float) (y - cp.y), (float) (z - cp.z))
                .color(((rgb >> 16) & 255) / 255f, ((rgb >> 8) & 255) / 255f, (rgb & 255) / 255f, a)
                .endVertex();
    }

    private void fillBox(BufferBuilder bb, Matrix4f m, Vector3d cp, double[] b, int c, float a) {
        double x1 = b[0] - EXPAND, y1 = b[1] - EXPAND, z1 = b[2] - EXPAND;
        double x2 = b[3] + EXPAND, y2 = b[4] + EXPAND, z2 = b[5] + EXPAND;
        // низ
        v(bb, m, cp, x1, y1, z1, c, a); v(bb, m, cp, x2, y1, z1, c, a); v(bb, m, cp, x2, y1, z2, c, a); v(bb, m, cp, x1, y1, z2, c, a);
        // верх
        v(bb, m, cp, x1, y2, z1, c, a); v(bb, m, cp, x1, y2, z2, c, a); v(bb, m, cp, x2, y2, z2, c, a); v(bb, m, cp, x2, y2, z1, c, a);
        // север / юг
        v(bb, m, cp, x1, y1, z1, c, a); v(bb, m, cp, x1, y2, z1, c, a); v(bb, m, cp, x2, y2, z1, c, a); v(bb, m, cp, x2, y1, z1, c, a);
        v(bb, m, cp, x1, y1, z2, c, a); v(bb, m, cp, x2, y1, z2, c, a); v(bb, m, cp, x2, y2, z2, c, a); v(bb, m, cp, x1, y2, z2, c, a);
        // запад / восток
        v(bb, m, cp, x1, y1, z1, c, a); v(bb, m, cp, x1, y1, z2, c, a); v(bb, m, cp, x1, y2, z2, c, a); v(bb, m, cp, x1, y2, z1, c, a);
        v(bb, m, cp, x2, y1, z1, c, a); v(bb, m, cp, x2, y2, z1, c, a); v(bb, m, cp, x2, y2, z2, c, a); v(bb, m, cp, x2, y1, z2, c, a);
    }

    private void lineBox(BufferBuilder bb, Matrix4f m, Vector3d cp, double[] b, int c, float a) {
        double x1 = b[0] - EXPAND, y1 = b[1] - EXPAND, z1 = b[2] - EXPAND;
        double x2 = b[3] + EXPAND, y2 = b[4] + EXPAND, z2 = b[5] + EXPAND;
        // нижняя рамка
        line(bb, m, cp, x1, y1, z1, x2, y1, z1, c, a); line(bb, m, cp, x2, y1, z1, x2, y1, z2, c, a);
        line(bb, m, cp, x2, y1, z2, x1, y1, z2, c, a); line(bb, m, cp, x1, y1, z2, x1, y1, z1, c, a);
        // верхняя рамка
        line(bb, m, cp, x1, y2, z1, x2, y2, z1, c, a); line(bb, m, cp, x2, y2, z1, x2, y2, z2, c, a);
        line(bb, m, cp, x2, y2, z2, x1, y2, z2, c, a); line(bb, m, cp, x1, y2, z2, x1, y2, z1, c, a);
        // стойки
        line(bb, m, cp, x1, y1, z1, x1, y2, z1, c, a); line(bb, m, cp, x2, y1, z1, x2, y2, z1, c, a);
        line(bb, m, cp, x2, y1, z2, x2, y2, z2, c, a); line(bb, m, cp, x1, y1, z2, x1, y2, z2, c, a);
    }

    private void line(BufferBuilder bb, Matrix4f m, Vector3d cp,
                      double ax, double ay, double az, double bx, double by, double bz, int c, float a) {
        v(bb, m, cp, ax, ay, az, c, a);
        v(bb, m, cp, bx, by, bz, c, a);
    }
}
