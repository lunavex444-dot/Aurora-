package com.aurora.client;

import com.mojang.blaze3d.platform.GlStateManager;
import com.mojang.blaze3d.systems.RenderSystem;
import net.minecraft.client.Minecraft;
import net.minecraft.client.entity.player.ClientPlayerEntity;
import net.minecraft.client.renderer.ActiveRenderInfo;
import net.minecraft.client.renderer.BufferBuilder;
import net.minecraft.client.renderer.Tessellator;
import net.minecraft.client.renderer.vertex.DefaultVertexFormats;
import net.minecraft.entity.LivingEntity;
import net.minecraft.util.math.vector.Matrix4f;
import net.minecraft.util.math.vector.Vector3d;
import net.minecraftforge.client.event.RenderWorldLastEvent;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.event.entity.player.AttackEntityEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import org.lwjgl.opengl.GL11;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Random;

/**
 * Собственные частицы Aurora: рисуются сами (светящиеся звёзды, шары и искры),
 * без ванильных текстур. Hit / Kill / World / Landing.
 */
public class Particles {
    private static class P {
        double x, y, z, vx, vy, vz, gravity, drag;
        float size, hue;
        int age, max, kind; // 0 star, 1 orb, 2 spark
        boolean ambient;
    }

    private static class Ring {
        double x, y, z, reach;
        int age, max;
    }

    private final List<P> parts = new ArrayList<>();
    private final List<Ring> rings = new ArrayList<>();
    private final Random rnd = new Random();

    private LivingEntity lastHit;
    private long lastHitTime;
    private boolean wasOnGround = true;
    private float lastFall = 0f;
    private double camX, camY, camZ;

    // ------------------------------------------------ helpers
    private float dens() {
        int m = Modules.PDENSITY.mode;
        return m == 0 ? 0.6f : (m == 1 ? 1f : 1.6f);
    }

    private int kind() {
        int m = Modules.PSTYLE.mode;
        if (m == 0) return 0;
        if (m == 1) return 1;
        if (m == 2) return 2;
        return rnd.nextInt(3);
    }

    private int hsv(float h) {
        h = h - (float) Math.floor(h);
        float s = 0.6f, v = 1f;
        int i = (int) (h * 6);
        float f = h * 6 - i;
        float p = v * (1 - s), q = v * (1 - f * s), t = v * (1 - (1 - f) * s);
        float r, g, b;
        switch (i % 6) {
            case 0:  r = v; g = t; b = p; break;
            case 1:  r = q; g = v; b = p; break;
            case 2:  r = p; g = v; b = t; break;
            case 3:  r = p; g = q; b = v; break;
            case 4:  r = t; g = p; b = v; break;
            default: r = v; g = p; b = q; break;
        }
        return ((int) (r * 255) << 16) | ((int) (g * 255) << 8) | (int) (b * 255);
    }

    private int pcol(float hue, float alpha) {
        int a = (int) (Math.max(0f, Math.min(1f, alpha)) * 255);
        int rgb;
        switch (Modules.PCOLOR.mode) {
            case 1:  rgb = hsv(hue); break;
            case 2:  rgb = Util.lerp(0xFFFFFF, Util.accent(hue) & 0xFFFFFF, 0.2f); break;
            default: rgb = Util.accent(hue) & 0xFFFFFF; break;
        }
        return (a << 24) | rgb;
    }

    private int white(float alpha) {
        return ((int) (Math.max(0f, Math.min(1f, alpha)) * 255) << 24) | 0xFFFFFF;
    }

    private void burst(double x, double y, double z, int n, double speed, int life, float size) {
        int count = Math.round(n * dens());
        for (int i = 0; i < count; i++) {
            P p = new P();
            p.x = x; p.y = y; p.z = z;
            double u = rnd.nextDouble() * 2 - 1;
            double a = rnd.nextDouble() * Math.PI * 2;
            double s = Math.sqrt(1 - u * u);
            double sp = speed * (0.35 + rnd.nextDouble() * 0.65);
            p.vx = s * Math.cos(a) * sp;
            p.vy = u * sp + 0.02;
            p.vz = s * Math.sin(a) * sp;
            p.size = size * (0.6f + rnd.nextFloat() * 0.8f);
            p.max = life + rnd.nextInt(life / 2 + 1);
            p.hue = rnd.nextFloat();
            p.kind = kind();
            p.gravity = 0.006;
            p.drag = 0.92;
            parts.add(p);
        }
        while (parts.size() > 900) parts.remove(0);
    }

    private void rise(double x, double y, double z, int n, float size) {
        int count = Math.round(n * dens());
        for (int i = 0; i < count; i++) {
            P p = new P();
            p.x = x + (rnd.nextDouble() - 0.5) * 0.8;
            p.y = y;
            p.z = z + (rnd.nextDouble() - 0.5) * 0.8;
            p.vx = (rnd.nextDouble() - 0.5) * 0.03;
            p.vy = 0.05 + rnd.nextDouble() * 0.07;
            p.vz = (rnd.nextDouble() - 0.5) * 0.03;
            p.size = size * (0.6f + rnd.nextFloat() * 0.7f);
            p.max = 30 + rnd.nextInt(20);
            p.hue = rnd.nextFloat();
            p.kind = 1;
            p.gravity = 0.0;
            p.drag = 0.95;
            parts.add(p);
        }
        while (parts.size() > 900) parts.remove(0);
    }

    private void ring(double x, double y, double z, int max, double reach) {
        Ring r = new Ring();
        r.x = x; r.y = y; r.z = z; r.max = max; r.reach = reach;
        rings.add(r);
    }

    // ------------------------------------------------ events
    @SubscribeEvent
    public void onAttack(AttackEntityEvent e) {
        Minecraft mc = Minecraft.getInstance();
        if (e.getPlayer() != mc.player || !(e.getTarget() instanceof LivingEntity)) return;
        LivingEntity t = (LivingEntity) e.getTarget();
        lastHit = t;
        lastHitTime = System.currentTimeMillis();
        if (Modules.HITPART.enabled)
            burst(t.getX(), t.getY() + t.getBbHeight() * 0.65, t.getZ(), 18, 0.17, 20, 0.17f);
    }

    @SubscribeEvent
    public void onTick(TickEvent.ClientTickEvent e) {
        if (e.phase != TickEvent.Phase.END) return;
        Minecraft mc = Minecraft.getInstance();
        ClientPlayerEntity p = mc.player;
        if (p == null || mc.level == null) {
            parts.clear();
            rings.clear();
            lastHit = null;
            return;
        }
        if (mc.isPaused()) return;

        // kill effect
        if (lastHit != null) {
            if (System.currentTimeMillis() - lastHitTime > 4000) {
                lastHit = null;
            } else if (lastHit.getHealth() <= 0f) {
                LivingEntity d = lastHit;
                lastHit = null;
                if (Modules.KILLFX.enabled) {
                    burst(d.getX(), d.getY() + d.getBbHeight() * 0.5, d.getZ(), 60, 0.3, 34, 0.26f);
                    rise(d.getX(), d.getY() + 0.2, d.getZ(), 14, 0.2f);
                    ring(d.getX(), d.getY(), d.getZ(), 22, 3.2);
                }
            }
        }

        // landing waves
        boolean og = p.isOnGround();
        if (!og) {
            lastFall = Math.max(lastFall, p.fallDistance);
        } else {
            if (!wasOnGround && lastFall > 1.5f && Modules.LANDING.enabled) {
                ring(p.getX(), p.getY(), p.getZ(), 18, 2.6);
                ring(p.getX(), p.getY(), p.getZ(), 26, 4.0);
                burst(p.getX(), p.getY() + 0.1, p.getZ(), 14, 0.14, 16, 0.13f);
            }
            lastFall = 0f;
        }
        wasOnGround = og;

        // ambient world particles
        if (Modules.WORLDPART.enabled) {
            int amb = 0;
            for (P q : parts) if (q.ambient) amb++;
            int want = Math.round(45 * dens());
            int spawn = amb < want ? 2 : 0;
            for (int i = 0; i < spawn; i++) {
                P q = new P();
                q.ambient = true;
                q.x = p.getX() + (rnd.nextDouble() - 0.5) * 14;
                q.y = p.getY() - 1 + rnd.nextDouble() * 5;
                q.z = p.getZ() + (rnd.nextDouble() - 0.5) * 14;
                q.vx = (rnd.nextDouble() - 0.5) * 0.02;
                q.vy = 0.004 + rnd.nextDouble() * 0.01;
                q.vz = (rnd.nextDouble() - 0.5) * 0.02;
                q.size = 0.05f + rnd.nextFloat() * 0.06f;
                q.max = 90 + rnd.nextInt(70);
                q.hue = rnd.nextFloat();
                int k = kind();
                q.kind = k == 2 ? 1 : k;
                q.gravity = 0.0;
                q.drag = 0.99;
                parts.add(q);
            }
        } else {
            parts.removeIf(q -> q.ambient);
        }

        // update
        Iterator<P> it = parts.iterator();
        while (it.hasNext()) {
            P q = it.next();
            q.x += q.vx;
            q.y += q.vy;
            q.z += q.vz;
            q.vy -= q.gravity;
            q.vx *= q.drag;
            q.vy *= q.drag;
            q.vz *= q.drag;
            if (++q.age >= q.max) it.remove();
        }
        for (Ring r : rings) r.age++;
        rings.removeIf(r -> r.age >= r.max);
    }

    @SubscribeEvent
    public void onWorld(RenderWorldLastEvent e) {
        if (parts.isEmpty() && rings.isEmpty()) return;
        Minecraft mc = Minecraft.getInstance();
        if (mc.player == null || mc.level == null) return;

        float pt = e.getPartialTicks();
        ActiveRenderInfo cam = mc.gameRenderer.getMainCamera();
        Vector3d cp = cam.getPosition();
        camX = cp.x; camY = cp.y; camZ = cp.z;
        Matrix4f m = e.getMatrixStack().last().pose();

        double yaw = Math.toRadians(cam.getYRot());
        double pitch = Math.toRadians(cam.getXRot());
        double lx = -Math.sin(yaw) * Math.cos(pitch);
        double ly = -Math.sin(pitch);
        double lz = Math.cos(yaw) * Math.cos(pitch);
        double[] look = {lx, ly, lz};
        double[] right = {-Math.cos(yaw), 0, -Math.sin(yaw)};
        double[] up = {ly * Math.sin(yaw), lz * Math.cos(yaw) - lx * Math.sin(yaw), -ly * Math.cos(yaw)};

        RenderSystem.enableBlend();
        RenderSystem.blendFunc(GlStateManager.SourceFactor.SRC_ALPHA, GlStateManager.DestFactor.ONE);
        RenderSystem.disableTexture();
        RenderSystem.disableCull();
        RenderSystem.depthMask(false);
        RenderSystem.disableAlphaTest();

        Tessellator tess = Tessellator.getInstance();
        BufferBuilder bb = tess.getBuilder();
        bb.begin(GL11.GL_TRIANGLES, DefaultVertexFormats.POSITION_COLOR);

        for (P q : parts) {
            float f = (q.age + pt) / q.max;
            if (f >= 1f) continue;
            float alpha = q.ambient ? (float) Math.sin(Math.PI * f) : (1f - f);
            double px = q.x + q.vx * pt, py = q.y + q.vy * pt, pz = q.z + q.vz * pt;
            float s = q.size * (q.ambient ? 1f : (1f - f * 0.55f));
            double[] c = {px, py, pz};
            float hue = q.hue + f * 0.25f;

            if (q.kind == 1) {
                orb(bb, m, c, s * 2.4, pcol(hue, alpha * 0.55f), 10, right, up);
                orb(bb, m, c, s * 1.2, pcol(hue, alpha * 0.9f), 10, right, up);
                orb(bb, m, c, s * 0.55, white(alpha), 8, right, up);
            } else if (q.kind == 0) {
                double th = (q.age + pt) * 0.12 + q.hue * 6.28;
                double cs = Math.cos(th), sn = Math.sin(th);
                double[] rr = {right[0] * cs + up[0] * sn, right[1] * cs + up[1] * sn, right[2] * cs + up[2] * sn};
                double[] uu = {up[0] * cs - right[0] * sn, up[1] * cs - right[1] * sn, up[2] * cs - right[2] * sn};
                orb(bb, m, c, s * 1.7, pcol(hue, alpha * 0.45f), 8, right, up);
                diamond(bb, m, c, rr, uu, s * 2.8, s * 0.32, pcol(hue, alpha), true);
                diamond(bb, m, c, rr, uu, s * 2.8, s * 0.32, pcol(hue, alpha), false);
                orb(bb, m, c, s * 0.6, white(alpha), 8, right, up);
            } else {
                double sp = Math.sqrt(q.vx * q.vx + q.vy * q.vy + q.vz * q.vz);
                orb(bb, m, c, s * 1.3, pcol(hue, alpha * 0.6f), 8, right, up);
                if (sp > 1e-4) {
                    double len = Math.min(1.0, 0.1 + sp * 4.5) * (0.6 + s * 3);
                    double dx = q.vx / sp, dy = q.vy / sp, dz = q.vz / sp;
                    double wx = dy * look[2] - dz * look[1];
                    double wy = dz * look[0] - dx * look[2];
                    double wz = dx * look[1] - dy * look[0];
                    double wl = Math.sqrt(wx * wx + wy * wy + wz * wz);
                    if (wl > 1e-5) {
                        double k = s * 0.45 / wl;
                        wx *= k; wy *= k; wz *= k;
                        double[] h1 = {px + wx, py + wy, pz + wz};
                        double[] h2 = {px - wx, py - wy, pz - wz};
                        double[] t1 = {px - dx * len - wx, py - dy * len - wy, pz - dz * len - wz};
                        double[] t2 = {px - dx * len + wx, py - dy * len + wy, pz - dz * len + wz};
                        int ch = pcol(hue, alpha);
                        int ct = pcol(hue, 0f);
                        quad(bb, m, h1, h2, t1, t2, ch, ch, ct, ct);
                    }
                }
                orb(bb, m, c, s * 0.5, white(alpha), 8, right, up);
            }
        }

        // shock waves
        for (Ring r : rings) {
            float f = (r.age + pt) / r.max;
            if (f >= 1f) continue;
            double rad = 0.3 + f * r.reach;
            double w = 0.35 + f * 0.25;
            float al = (float) Math.pow(1f - f, 1.4);
            int n = 44;
            for (int i = 0; i < n; i++) {
                double a0 = Math.PI * 2 * i / n, a1 = Math.PI * 2 * (i + 1) / n;
                double[] i0 = {r.x + Math.cos(a0) * rad, r.y + 0.06, r.z + Math.sin(a0) * rad};
                double[] i1 = {r.x + Math.cos(a1) * rad, r.y + 0.06, r.z + Math.sin(a1) * rad};
                double[] o0 = {r.x + Math.cos(a0) * (rad + w), r.y + 0.06, r.z + Math.sin(a0) * (rad + w)};
                double[] o1 = {r.x + Math.cos(a1) * (rad + w), r.y + 0.06, r.z + Math.sin(a1) * (rad + w)};
                float h0 = (float) i / n, h1 = (float) (i + 1) / n;
                quad(bb, m, i0, i1, o1, o0,
                        pcol(h0, al * 0.08f), pcol(h1, al * 0.08f), pcol(h1, al * 0.95f), pcol(h0, al * 0.95f));
                double[] t0 = {o0[0], o0[1] + 0.35 * al, o0[2]};
                double[] t1 = {o1[0], o1[1] + 0.35 * al, o1[2]};
                quad(bb, m, o0, o1, t1, t0,
                        pcol(h0, al * 0.95f), pcol(h1, al * 0.95f), pcol(h1, 0f), pcol(h0, 0f));
            }
        }

        tess.end();

        RenderSystem.depthMask(true);
        RenderSystem.enableCull();
        RenderSystem.enableTexture();
        RenderSystem.enableAlphaTest();
        RenderSystem.defaultBlendFunc();
        RenderSystem.disableBlend();
    }

    // ------------------------------------------------ drawing helpers
    private void v(BufferBuilder bb, Matrix4f m, double x, double y, double z, int c) {
        bb.vertex(m, (float) (x - camX), (float) (y - camY), (float) (z - camZ))
                .color(((c >> 16) & 255) / 255f, ((c >> 8) & 255) / 255f, (c & 255) / 255f, ((c >>> 24) & 255) / 255f)
                .endVertex();
    }

    private void tri(BufferBuilder bb, Matrix4f m, double[] a, double[] b, double[] c, int ca, int cb, int cc) {
        v(bb, m, a[0], a[1], a[2], ca);
        v(bb, m, b[0], b[1], b[2], cb);
        v(bb, m, c[0], c[1], c[2], cc);
    }

    private void quad(BufferBuilder bb, Matrix4f m, double[] a, double[] b, double[] c, double[] d,
                      int ca, int cb, int cc, int cd) {
        tri(bb, m, a, b, c, ca, cb, cc);
        tri(bb, m, a, c, d, ca, cc, cd);
    }

    private double[] off(double[] c, double[] r, double[] u, double a, double b) {
        return new double[]{c[0] + r[0] * a + u[0] * b, c[1] + r[1] * a + u[1] * b, c[2] + r[2] * a + u[2] * b};
    }

    /** Soft glowing disc: bright centre, transparent edge. */
    private void orb(BufferBuilder bb, Matrix4f m, double[] c, double rad, int color, int segs,
                     double[] r, double[] u) {
        int edge = color & 0x00FFFFFF;
        for (int i = 0; i < segs; i++) {
            double a0 = Math.PI * 2 * i / segs, a1 = Math.PI * 2 * (i + 1) / segs;
            double[] p0 = off(c, r, u, Math.cos(a0) * rad, Math.sin(a0) * rad);
            double[] p1 = off(c, r, u, Math.cos(a1) * rad, Math.sin(a1) * rad);
            tri(bb, m, c, p0, p1, color, edge, edge);
        }
    }

    /** One long thin glowing blade of a sparkle. */
    private void diamond(BufferBuilder bb, Matrix4f m, double[] c, double[] r, double[] u,
                         double len, double wid, int color, boolean horizontal) {
        double[] t1 = horizontal ? off(c, r, u, -len, 0) : off(c, r, u, 0, -len);
        double[] t2 = horizontal ? off(c, r, u, len, 0) : off(c, r, u, 0, len);
        double[] s1 = horizontal ? off(c, r, u, 0, wid) : off(c, r, u, wid, 0);
        double[] s2 = horizontal ? off(c, r, u, 0, -wid) : off(c, r, u, -wid, 0);
        int a = (color >>> 24) & 255;
        int tip = Util.withAlpha(color, a / 6);
        int side = Util.withAlpha(color, a / 2);
        tri(bb, m, c, t1, s1, color, tip, side);
        tri(bb, m, c, s1, t2, color, side, tip);
        tri(bb, m, c, t2, s2, color, tip, side);
        tri(bb, m, c, s2, t1, color, side, tip);
    }
}
