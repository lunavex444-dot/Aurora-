package com.aurora.client;

import com.mojang.blaze3d.systems.RenderSystem;
import net.minecraft.client.Minecraft;
import net.minecraft.client.renderer.BufferBuilder;
import net.minecraft.client.renderer.Tessellator;
import net.minecraft.client.renderer.vertex.DefaultVertexFormats;
import net.minecraftforge.client.event.RenderWorldLastEvent;
import net.minecraftforge.eventbus.api.EventPriority;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import org.lwjgl.opengl.GL11;
import org.lwjgl.opengl.GL12;

/**
 * Aspect Ratio: растягивает картинку мира под выбранное соотношение сторон (4:3, 16:9 и т.д.).
 * Рисуется в конце рендера мира, поэтому интерфейс и рука не искажаются.
 */
public class AspectRatio {
    private static final double[] RATIOS = {0, 4.0 / 3, 5.0 / 4, 3.0 / 2, 16.0 / 10, 16.0 / 9, 21.0 / 9, 1.0};

    private int tex = 0, texW = 0, texH = 0;
    private boolean failed = false;

    @SubscribeEvent(priority = EventPriority.LOWEST)
    public void onWorld(RenderWorldLastEvent e) {
        int mode = Modules.ASPECT.mode;
        if (failed || mode <= 0 || mode >= RATIOS.length) return;
        Minecraft mc = Minecraft.getInstance();
        int w = mc.getWindow().getWidth(), h = mc.getWindow().getHeight();
        if (w < 16 || h < 16) return;

        double k = ((double) w / h) / RATIOS[mode];
        if (Math.abs(k - 1.0) < 0.01) return;

        try {
            if (tex == 0) tex = GL11.glGenTextures();
            RenderSystem.bindTexture(tex);
            if (texW != w || texH != h) {
                GL11.glTexImage2D(GL11.GL_TEXTURE_2D, 0, GL11.GL_RGBA8, w, h, 0, GL11.GL_RGBA,
                        GL11.GL_UNSIGNED_BYTE, 0L);
                GL11.glTexParameteri(GL11.GL_TEXTURE_2D, GL11.GL_TEXTURE_MIN_FILTER, GL11.GL_LINEAR);
                GL11.glTexParameteri(GL11.GL_TEXTURE_2D, GL11.GL_TEXTURE_MAG_FILTER, GL11.GL_LINEAR);
                GL11.glTexParameteri(GL11.GL_TEXTURE_2D, GL11.GL_TEXTURE_WRAP_S, GL12.GL_CLAMP_TO_EDGE);
                GL11.glTexParameteri(GL11.GL_TEXTURE_2D, GL11.GL_TEXTURE_WRAP_T, GL12.GL_CLAMP_TO_EDGE);
                texW = w;
                texH = h;
            }
            GL11.glCopyTexSubImage2D(GL11.GL_TEXTURE_2D, 0, 0, 0, 0, 0, w, h);

            // шире кадра по ширине: обрезаем края и растягиваем; уже кадра: обрезаем верх и низ
            double u0 = 0, u1 = 1, v0 = 0, v1 = 1;
            if (k > 1) {
                u0 = (1 - 1 / k) / 2;
                u1 = 1 - u0;
            } else {
                v0 = (1 - k) / 2;
                v1 = 1 - v0;
            }

            RenderSystem.disableDepthTest();
            RenderSystem.depthMask(false);
            RenderSystem.disableCull();
            RenderSystem.disableBlend();
            RenderSystem.disableAlphaTest();
            RenderSystem.disableFog();
            RenderSystem.disableLighting();
            RenderSystem.enableTexture();
            RenderSystem.color4f(1f, 1f, 1f, 1f);
            RenderSystem.matrixMode(GL11.GL_PROJECTION);
            RenderSystem.pushMatrix();
            RenderSystem.loadIdentity();
            RenderSystem.matrixMode(GL11.GL_MODELVIEW);
            RenderSystem.pushMatrix();
            RenderSystem.loadIdentity();

            Tessellator tess = Tessellator.getInstance();
            BufferBuilder bb = tess.getBuilder();
            bb.begin(GL11.GL_QUADS, DefaultVertexFormats.POSITION_TEX);
            bb.vertex(-1, -1, 0).uv((float) u0, (float) v0).endVertex();
            bb.vertex(1, -1, 0).uv((float) u1, (float) v0).endVertex();
            bb.vertex(1, 1, 0).uv((float) u1, (float) v1).endVertex();
            bb.vertex(-1, 1, 0).uv((float) u0, (float) v1).endVertex();
            tess.end();

            RenderSystem.popMatrix();
            RenderSystem.matrixMode(GL11.GL_PROJECTION);
            RenderSystem.popMatrix();
            RenderSystem.matrixMode(GL11.GL_MODELVIEW);
            RenderSystem.enableDepthTest();
            RenderSystem.depthMask(true);
            RenderSystem.enableCull();
            RenderSystem.enableAlphaTest();
        } catch (Throwable t) {
            failed = true;
        }
    }
}
