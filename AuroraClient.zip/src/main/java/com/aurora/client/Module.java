package com.aurora.client;

import java.util.Locale;

public class Module {
    public final String name, desc;
    public final Category cat;
    public boolean enabled;
    public float anim;
    public final String[] modes;
    public final Runnable action;
    public final boolean slider;
    public final double min, max, step;
    public double value;
    public int mode = 0;
    public int key = -1;

    public Module(String name, String desc, Category cat, boolean enabled) {
        this.name = name; this.desc = desc; this.cat = cat;
        this.enabled = enabled; this.anim = enabled ? 1f : 0f;
        this.modes = null; this.action = null;
        this.slider = false; this.min = 0; this.max = 0; this.step = 0;
    }

    public Module(String name, String desc, Category cat, String[] modes) {
        this.name = name; this.desc = desc; this.cat = cat;
        this.modes = modes; this.action = null;
        this.slider = false; this.min = 0; this.max = 0; this.step = 0;
    }

    public Module(String name, String desc, Category cat, Runnable action) {
        this.name = name; this.desc = desc; this.cat = cat;
        this.modes = null; this.action = action;
        this.slider = false; this.min = 0; this.max = 0; this.step = 0;
    }

    /** Ползунок: от min до max с шагом step. */
    public Module(String name, String desc, Category cat, double min, double max, double step, double value) {
        this.name = name; this.desc = desc; this.cat = cat;
        this.modes = null; this.action = null;
        this.slider = true; this.min = min; this.max = max; this.step = step;
        this.value = value;
    }

    public boolean isToggle() { return modes == null && action == null && !slider; }
    public boolean isAction() { return action != null; }
    public boolean isSlider() { return slider; }

    public void click() {
        if (action != null) action.run();
        else if (modes != null) mode = (mode + 1) % modes.length;
        else if (!slider) enabled = !enabled;
    }

    public double fraction() { return max > min ? (value - min) / (max - min) : 0; }

    public void setFraction(double t) {
        t = Math.max(0, Math.min(1, t));
        double v = min + t * (max - min);
        if (step > 0) v = Math.round(v / step) * step;
        value = Math.max(min, Math.min(max, v));
    }

    public String valueText() {
        return step >= 1 ? String.valueOf((int) Math.round(value)) : String.format(Locale.US, "%.2f", value);
    }
}
