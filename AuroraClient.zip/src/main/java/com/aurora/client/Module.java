package com.aurora.client;

public class Module {
    public final String name, desc;
    public final Category cat;
    public boolean enabled;
    public float anim;
    public final String[] modes;
    public int mode = 0;

    public Module(String name, String desc, Category cat, boolean enabled) {
        this.name = name; this.desc = desc; this.cat = cat;
        this.enabled = enabled; this.anim = enabled ? 1f : 0f;
        this.modes = null;
    }

    public Module(String name, String desc, Category cat, String[] modes) {
        this.name = name; this.desc = desc; this.cat = cat;
        this.modes = modes;
    }

    public boolean isToggle() { return modes == null; }

    public void click() {
        if (modes != null) mode = (mode + 1) % modes.length;
        else enabled = !enabled;
    }
}
