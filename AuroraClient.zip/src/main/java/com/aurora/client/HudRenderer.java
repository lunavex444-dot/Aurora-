package com.aurora.client;

import com.mojang.blaze3d.matrix.MatrixStack;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.AbstractGui;
import net.minecraft.client.gui.FontRenderer;
import net.minecraft.client.network.play.NetworkPlayerInfo;
import net.minecraftforge.client.event.ClientChatEvent;
import net.minecraftforge.client.event.EntityViewRenderEvent;
import net.minecraftforge.client.event.RenderGameOverlayEvent;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

public class HudRenderer {
    private int frames = 0, fps = 0;
    private long lastSecond = System.currentTimeMillis();
    private boolean fbWasOn = false;
    private double savedGamma = 1.0;

    @SubscribeEvent
    public void onTick(TickEvent.ClientTickEvent e) {
        if (e.phase != TickEvent.Phase.END) return;
        Minecraft mc = Minecraft.getInstance();

        while (AuroraClient.OPEN_GUI.consumeClick()) {
            if (mc.screen == null) mc.setScreen(new ClickGui());
        }

        if (Modules.FULLBRIGHT.enabled) {
            if (!fbWasOn) { savedGamma = mc.options.gamma; fbWasOn = true; }
            mc.options.gamma = 15.0;
        } else if (fbWasOn) {
            mc.options.gamma = savedGamma;
            fbWasOn = false;
        }
    }

    @SubscribeEvent
    public void onChat(ClientChatEvent e) {
        String m = e.getMessage().trim();
        if (m.equalsIgnoreCase(".gui") || m.equalsIgnoreCase(".aurora")) {
            e.setCanceled(true);
            Minecraft mc = Minecraft.getInstance();
            mc.gui.getChat().addRecentChat(e.getMessage());
            mc.tell(() -> mc.setScreen(new ClickGui()));
        }
    }

    @SubscribeEvent
    public void onFov(EntityViewRenderEvent.FOVModifier e) {
        if (Modules.ZOOM.enabled) e.setFOV(e.getFOV() / 3.0);
    }

    @SubscribeEvent
    public void onRender(RenderGameOverlayEvent.Post e) {
        if (e.getType() != RenderGameOverlayEvent.ElementType.ALL) return;
        Minecraft mc = Minecraft.getInstance();
        if (mc.player == null || mc.options.hideGui) return;

        frames++;
        long now = System.currentTimeMillis();
        if (now - lastSecond >= 1000) { fps = frames; frames = 0; lastSecond = now; }

        MatrixStack ms = e.getMatrixStack();
        FontRenderer fr = mc.font;

        if (Modules.WATERMARK.enabled) drawWatermark(ms, fr, mc);
        if (Modules.COORDS.enabled) drawCoords(ms, fr, mc);
        if (Modules.ARRAYLIST.enabled) drawArrayList(ms, fr, mc);
    }

    private int ping(Minecraft mc) {
        if (mc.getConnection() == null) return 0;
        NetworkPlayerInfo info = mc.getConnection().getPlayerInfo(mc.player.getUUID());
        return info == null ? 0 : info.getLatency();
    }

    private void drawWatermark(MatrixStack ms, FontRenderer fr, Minecraft mc) {
        String time = new SimpleDateFormat("HH:mm").format(new Date());
        String server = mc.getCurrentServer() == null ? "singleplayer" : mc.getCurrentServer().ip;
        String[] parts = { fps + " fps", ping(mc) + " ms", time, server };

        int x = 6, y = 6, h = 18;
        // logo
        Util.rrect(ms, x, y, x + h, y + h, 5, Util.accent(0f));
        fr.drawShadow(ms, "A", x + (h - fr.width("A")) / 2f, y + 5, 0xFFFFFFFF);

        // capsule
        int px = x + h + 4;
        int n = parts.length + 1;
        int sum = fr.width(AuroraClient.NAME);
        for (String s : parts) sum += fr.width(s);
        int w = 14 + sum + (n - 1) * 11;
        Util.rrect(ms, px, y, px + w, y + h, 5, 0xB0101018);

        int cx = px + 7, ty = y + 5;
        cx += Util.gradientText(ms, fr, AuroraClient.NAME, cx, ty, 0f);
        for (String s : parts) {
            cx += 5;
            AbstractGui.fill(ms, cx, y + 4, cx + 1, y + h - 4, 0x30FFFFFF);
            cx += 6;
            fr.drawShadow(ms, s, cx, ty, 0xFFE6E6F0);
            cx += fr.width(s);
        }
    }

    private void drawCoords(MatrixStack ms, FontRenderer fr, Minecraft mc) {
        String tag = "XYZ";
        String nums = String.format("  %.0f  %.0f  %.0f", mc.player.getX(), mc.player.getY(), mc.player.getZ());
        int w = fr.width(tag) + fr.width(nums) + 12;
        int sw = mc.getWindow().getGuiScaledWidth();
        int sh = mc.getWindow().getGuiScaledHeight();
        int x = sw - w - 6, y = sh - 20;
        Util.rrect(ms, x, y, x + w, y + 14, 5, 0xB0101018);
        fr.drawShadow(ms, tag, x + 6, y + 3, Util.accent(0.3f));
        fr.drawShadow(ms, nums, x + 6 + fr.width(tag), y + 3, 0xFFFFFFFF);
    }

    private void drawArrayList(MatrixStack ms, FontRenderer fr, Minecraft mc) {
        List<Module> on = new ArrayList<>();
        for (Module m : Modules.ALL)
            if (m.isToggle() && m.enabled && m.cat != Category.CLIENT) on.add(m);
        on.sort((a, b) -> fr.width(b.name) - fr.width(a.name));

        int sw = mc.getWindow().getGuiScaledWidth();
        int y = 6, i = 0;
        for (Module m : on) {
            int w = fr.width(m.name);
            int x = sw - w - 16;
            Util.rrect(ms, x, y, sw - 6, y + 13, 4, 0xB0101018);
            Util.rrect(ms, sw - 9, y + 2, sw - 7, y + 11, 1, Util.accent(i * 0.15f));
            fr.drawShadow(ms, m.name, x + 5, y + 3, Util.accent(i * 0.15f));
            y += 15;
            i++;
        }
    }
}
