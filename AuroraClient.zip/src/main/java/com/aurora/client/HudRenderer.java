package com.aurora.client;

import com.mojang.blaze3d.matrix.MatrixStack;
import com.mojang.blaze3d.systems.RenderSystem;
import net.minecraft.client.Minecraft;
import net.minecraft.client.entity.player.AbstractClientPlayerEntity;
import net.minecraft.client.gui.AbstractGui;
import net.minecraft.client.gui.FontRenderer;
import net.minecraft.client.gui.screen.ChatScreen;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.network.play.NetworkPlayerInfo;
import net.minecraft.client.settings.KeyBinding;
import net.minecraft.client.util.InputMappings;
import net.minecraft.entity.Entity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.item.ArmorStandEntity;
import net.minecraft.inventory.EquipmentSlotType;
import net.minecraft.item.ItemStack;
import net.minecraftforge.client.event.ClientChatEvent;
import net.minecraftforge.client.event.EntityViewRenderEvent;
import net.minecraftforge.client.event.InputEvent;
import net.minecraftforge.client.event.RenderGameOverlayEvent;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.event.entity.player.AttackEntityEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;

import java.text.SimpleDateFormat;
import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

public class HudRenderer {
    private int frames = 0, fps = 0;
    private long lastSecond = System.currentTimeMillis();
    private boolean fbWasOn = false, ajState = false;
    private double savedGamma = 1.0;

    private LivingEntity target, lastShown;
    private long targetTime;
    private float shownHp;

    private final ArrayDeque<Long> lmb = new ArrayDeque<>();
    private final ArrayDeque<Long> rmb = new ArrayDeque<>();
    private final float[] keyAnim = new float[7];

    // ------------------------------------------------ events
    @SubscribeEvent
    public void onTick(TickEvent.ClientTickEvent e) {
        if (e.phase != TickEvent.Phase.END) return;
        Minecraft mc = Minecraft.getInstance();

        while (AuroraClient.OPEN_GUI.consumeClick()) {
            if (mc.screen == null) mc.setScreen(new ClickGui());
        }

        if (Modules.AUTOSPRINT.enabled && mc.player != null && mc.screen == null
                && mc.options.keyUp.isDown() && !mc.player.isCrouching() && !mc.player.isUsingItem()
                && !mc.player.horizontalCollision && mc.player.getFoodData().getFoodLevel() > 6) {
            mc.player.setSprinting(true);
        }

        if (Modules.AUTOJUMP.enabled != ajState) {
            ajState = Modules.AUTOJUMP.enabled;
            mc.options.autoJump = ajState;
        }

        if (Modules.GUIMOVE.enabled && mc.player != null && mc.screen != null && guiMoveAllowed(mc.screen)) {
            long win = mc.getWindow().getWindow();
            KeyBinding[] ks = { mc.options.keyUp, mc.options.keyDown, mc.options.keyLeft,
                    mc.options.keyRight, mc.options.keyJump, mc.options.keySprint };
            for (KeyBinding k : ks) k.setDown(InputMappings.isKeyDown(win, k.getKey().getValue()));
        }

        if (Modules.FULLBRIGHT.enabled) {
            if (!fbWasOn) { savedGamma = mc.options.gamma; fbWasOn = true; }
            mc.options.gamma = 15.0;
        } else if (fbWasOn) {
            mc.options.gamma = savedGamma;
            fbWasOn = false;
        }
    }

    private boolean guiMoveAllowed(Screen s) {
        if (s instanceof ChatScreen || s instanceof ClickGui || s instanceof HudEditor) return false;
        String n = s.getClass().getSimpleName();
        return !(n.contains("Anvil") || n.contains("Creative") || n.contains("Sign")
                || n.contains("Book") || n.contains("Edit") || n.contains("Chat"));
    }

    @SubscribeEvent
    public void onKey(InputEvent.KeyInputEvent e) {
        Minecraft mc = Minecraft.getInstance();
        if (mc.screen != null || mc.player == null || e.getAction() != 1) return;
        for (Module m : Modules.ALL) {
            if (m.key >= 0 && m.key == e.getKey() && !m.isAction()) m.click();
        }
    }

    @SubscribeEvent
    public void onMouse(InputEvent.MouseInputEvent e) {
        Minecraft mc = Minecraft.getInstance();
        if (mc.screen != null || e.getAction() != 1) return;
        long now = System.currentTimeMillis();
        if (e.getButton() == 0) lmb.addLast(now);
        else if (e.getButton() == 1) rmb.addLast(now);
    }

    @SubscribeEvent
    public void onChat(ClientChatEvent e) {
        String m = e.getMessage().trim();
        boolean gui = m.equalsIgnoreCase(".gui") || m.equalsIgnoreCase(".aurora");
        boolean hud = m.equalsIgnoreCase(".hud");
        if (gui || hud) {
            e.setCanceled(true);
            Minecraft mc = Minecraft.getInstance();
            mc.gui.getChat().addRecentChat(e.getMessage());
            mc.tell(() -> mc.setScreen(gui ? new ClickGui() : new HudEditor()));
        }
    }

    @SubscribeEvent
    public void onAttack(AttackEntityEvent e) {
        Minecraft mc = Minecraft.getInstance();
        if (e.getPlayer() == mc.player && e.getTarget() instanceof LivingEntity)
            setTarget((LivingEntity) e.getTarget());
    }

    private void setTarget(LivingEntity t) {
        target = t;
        targetTime = System.currentTimeMillis();
    }

    @SubscribeEvent
    public void onFov(EntityViewRenderEvent.FOVModifier e) {
        if (Modules.ZOOM.enabled) e.setFOV(e.getFOV() / 3.0);
    }

    @SubscribeEvent
    public void onPre(RenderGameOverlayEvent.Pre e) {
        if (e.getType() == RenderGameOverlayEvent.ElementType.CROSSHAIRS && Modules.CROSSHAIR.enabled)
            e.setCanceled(true);
    }

    @SubscribeEvent
    public void onRender(RenderGameOverlayEvent.Post e) {
        if (e.getType() != RenderGameOverlayEvent.ElementType.ALL) return;
        Minecraft mc = Minecraft.getInstance();
        if (mc.player == null || mc.options.hideGui) return;

        frames++;
        long now = System.currentTimeMillis();
        if (now - lastSecond >= 1000) { fps = frames; frames = 0; lastSecond = now; }

        MatrixStack ms = e.getMatrixStack();
        FontRenderer fr = mc.font;

        if (Modules.CROSSHAIR.enabled && mc.screen == null) drawCrosshair(ms, mc);
        if (Modules.TARGETHUD.enabled) drawTargetHud(ms, fr, mc);
        if (Modules.WATERMARK.enabled) drawWatermark(ms, fr, mc);
        if (Modules.COORDS.enabled) drawCoords(ms, fr, mc);
        if (Modules.ARRAYLIST.enabled) drawArrayList(ms, fr, mc);
        if (Modules.KEYSTROKES.enabled) drawKeys(ms, fr, mc);
        if (Modules.ARMOR.enabled) drawArmor(ms, fr, mc);
    }

    // ------------------------------------------------ helpers
    private int cps(ArrayDeque<Long> q) {
        long now = System.currentTimeMillis();
        while (!q.isEmpty() && now - q.peekFirst() > 1000) q.pollFirst();
        return q.size();
    }

    private int ping(Minecraft mc) {
        if (mc.getConnection() == null) return 0;
        NetworkPlayerInfo info = mc.getConnection().getPlayerInfo(mc.player.getUUID());
        return info == null ? 0 : info.getLatency();
    }

    private void small(MatrixStack ms, FontRenderer fr, String s, float x, float y, int color) {
        ms.pushPose();
        ms.scale(0.75f, 0.75f, 1f);
        fr.drawShadow(ms, s, x / 0.75f, y / 0.75f, color);
        ms.popPose();
    }

    // ------------------------------------------------ elements
    private void drawCrosshair(MatrixStack ms, Minecraft mc) {
        int cx = mc.getWindow().getGuiScaledWidth() / 2;
        int cy = mc.getWindow().getGuiScaledHeight() / 2;
        int c = Util.accent(0f);
        int style = Modules.CROSSSTYLE.mode;
        if (style == 0) {
            AbstractGui.fill(ms, cx - 8, cy - 1, cx - 3, cy + 1, c);
            AbstractGui.fill(ms, cx + 3, cy - 1, cx + 8, cy + 1, c);
            AbstractGui.fill(ms, cx - 1, cy - 8, cx + 1, cy - 3, c);
            AbstractGui.fill(ms, cx - 1, cy + 3, cx + 1, cy + 8, c);
        } else if (style == 1) {
            Util.rrect(ms, cx - 2, cy - 2, cx + 2, cy + 2, 2, c);
        } else {
            for (int a = 0; a < 360; a += 10) {
                int px = cx + (int) Math.round(6 * Math.cos(Math.toRadians(a)));
                int py = cy + (int) Math.round(6 * Math.sin(Math.toRadians(a)));
                AbstractGui.fill(ms, px, py, px + 1, py + 1, c);
            }
        }
    }

    private void drawTargetHud(MatrixStack ms, FontRenderer fr, Minecraft mc) {
        Entity look = mc.crosshairPickEntity;
        if (look instanceof LivingEntity && look != mc.player && !(look instanceof ArmorStandEntity))
            setTarget((LivingEntity) look);
        if (target != null && (System.currentTimeMillis() - targetTime > 3000 || !target.isAlive()))
            target = null;

        LivingEntity t = target;
        if (t == null && mc.screen instanceof HudEditor) t = mc.player;
        if (t == null) return;
        if (t != lastShown) { lastShown = t; shownHp = t.getHealth(); }

        int sw = mc.getWindow().getGuiScaledWidth();
        int sh = mc.getWindow().getGuiScaledHeight();
        int w = 138, h = 42;
        int x = sw / 2 + 14 + Hud.TARGET.dx, y = sh / 2 + 18 + Hud.TARGET.dy;
        Hud.TARGET.set(x, y, w, h);

        Util.rrect(ms, x - 1, y - 1, x + w + 1, y + h + 1, 8, Util.withAlpha(Util.accent(0.2f), 0x60));
        Util.rrect(ms, x, y, x + w, y + h, 7, 0xD0101018);
        drawHead(ms, fr, mc, t, x + 6, y + 6, 30);

        String name = fr.plainSubstrByWidth(t.getName().getString(), w - 50);
        fr.drawShadow(ms, name, x + 43, y + 7, 0xFFFFFFFF);

        float hp = Math.max(0f, t.getHealth());
        float max = Math.max(1f, t.getMaxHealth());
        shownHp += (hp - shownHp) * 0.12f;
        small(ms, fr, String.format("%.1f HP", hp), x + 43, y + 19, 0xFF9A9AAE);

        int bx = x + 43, by = y + 29, bw = w - 51;
        Util.rrect(ms, bx, by, bx + bw, by + 7, 3, 0x40FFFFFF);
        int fill = Math.max(0, Math.min(bw, Math.round(bw * shownHp / max)));
        if (fill > 0) Util.rrect(ms, bx, by, bx + fill, by + 7, 3, Util.accent(0.1f));
    }

    private void drawHead(MatrixStack ms, FontRenderer fr, Minecraft mc, LivingEntity e, int x, int y, int size) {
        if (e instanceof AbstractClientPlayerEntity) {
            mc.getTextureManager().bind(((AbstractClientPlayerEntity) e).getSkinTextureLocation());
            RenderSystem.color4f(1f, 1f, 1f, 1f);
            float s = size / 8f;
            ms.pushPose();
            ms.translate(x, y, 0);
            ms.scale(s, s, 1f);
            AbstractGui.blit(ms, 0, 0, 8f, 8f, 8, 8, 64, 64);
            AbstractGui.blit(ms, 0, 0, 40f, 8f, 8, 8, 64, 64);
            ms.popPose();
        } else {
            Util.rrect(ms, x, y, x + size, y + size, 6, Util.accent(0.4f));
            String n = e.getName().getString();
            String c = n.isEmpty() ? "?" : n.substring(0, 1).toUpperCase();
            fr.drawShadow(ms, c, x + (size - fr.width(c)) / 2f, y + (size - 8) / 2f, 0xFFFFFFFF);
        }
    }

    private void drawWatermark(MatrixStack ms, FontRenderer fr, Minecraft mc) {
        String time = new SimpleDateFormat("HH:mm").format(new Date());
        String server = mc.getCurrentServer() == null ? "singleplayer" : mc.getCurrentServer().ip;
        List<String> parts = new ArrayList<>();
        parts.add(fps + " fps");
        if (Modules.SHOWPING.enabled) parts.add(ping(mc) + " ms");
        if (Modules.SHOWCPS.enabled) parts.add(cps(lmb) + " cps");
        parts.add(time);
        parts.add(server);

        int x = 6 + Hud.WATERMARK.dx, y = 6 + Hud.WATERMARK.dy, h = 18;
        Util.rrect(ms, x, y, x + h, y + h, 5, Util.accent(0f));
        fr.drawShadow(ms, "A", x + (h - fr.width("A")) / 2f, y + 5, 0xFFFFFFFF);

        int px = x + h + 4;
        int n = parts.size() + 1;
        int sum = fr.width(AuroraClient.NAME);
        for (String s : parts) sum += fr.width(s);
        int w = 14 + sum + (n - 1) * 11;
        Hud.WATERMARK.set(x, y, h + 4 + w, h);
        Util.rrect(ms, px, y, px + w, y + h, 5, 0xB0101018);

        int cx = px + 7, ty = y + 5;
        cx += Util.gradientText(ms, fr, AuroraClient.NAME, cx, ty, 0f);
        for (String s : parts) {
            cx += 5;
            AbstractGui.fill(ms, cx, y + 4, cx + 1, y + h - 4, 0x30FFFFFF);
            cx += 6;
            fr.drawShadow(ms, s, cx, ty, 0xFFE6E6F0);
            cx += fr.width(s);
        }
    }

    private void drawCoords(MatrixStack ms, FontRenderer fr, Minecraft mc) {
        String tag = "XYZ";
        String nums = String.format("  %.0f  %.0f  %.0f", mc.player.getX(), mc.player.getY(), mc.player.getZ());
        int w = fr.width(tag) + fr.width(nums) + 12;
        int sw = mc.getWindow().getGuiScaledWidth();
        int sh = mc.getWindow().getGuiScaledHeight();
        int x = sw - w - 6 + Hud.COORDS.dx, y = sh - 20 + Hud.COORDS.dy;
        Hud.COORDS.set(x, y, w, 14);
        Util.rrect(ms, x, y, x + w, y + 14, 5, 0xB0101018);
        fr.drawShadow(ms, tag, x + 6, y + 3, Util.accent(0.3f));
        fr.drawShadow(ms, nums, x + 6 + fr.width(tag), y + 3, 0xFFFFFFFF);
    }

    private void drawArrayList(MatrixStack ms, FontRenderer fr, Minecraft mc) {
        List<Module> on = new ArrayList<>();
        for (Module m : Modules.ALL)
            if (m.isToggle() && m.enabled && m.cat != Category.CLIENT && m.cat != Category.HUD) on.add(m);
        on.sort((a, b) -> fr.width(b.name) - fr.width(a.name));

        int sw = mc.getWindow().getGuiScaledWidth();
        int ox = Hud.ARRAY.dx, y = 6 + Hud.ARRAY.dy, i = 0;
        int maxW = 40;
        for (Module m : on) maxW = Math.max(maxW, fr.width(m.name) + 14);
        Hud.ARRAY.set(sw - 6 - maxW + ox, 6 + Hud.ARRAY.dy, maxW, Math.max(13, on.size() * 15));

        for (Module m : on) {
            int w = fr.width(m.name);
            int x = sw - w - 16 + ox;
            Util.rrect(ms, x, y, sw - 6 + ox, y + 13, 4, 0xB0101018);
            Util.rrect(ms, sw - 9 + ox, y + 2, sw - 7 + ox, y + 11, 1, Util.accent(i * 0.15f));
            fr.drawShadow(ms, m.name, x + 5, y + 3, Util.accent(i * 0.15f));
            y += 15;
            i++;
        }
    }

    private void drawKeyBox(MatrixStack ms, FontRenderer fr, int idx, boolean down,
                            int x, int y, int w, int h, String label, String sub) {
        keyAnim[idx] += ((down ? 1f : 0f) - keyAnim[idx]) * 0.3f;
        int bg = Util.withAlpha(Util.lerp(0x101018, Util.accent(idx * 0.1f) & 0xFFFFFF, keyAnim[idx]), 0xB0);
        Util.rrect(ms, x, y, x + w, y + h, 4, bg);
        if (sub == null) {
            fr.drawShadow(ms, label, x + (w - fr.width(label)) / 2f, y + (h - 8) / 2f, 0xFFFFFFFF);
        } else {
            fr.drawShadow(ms, label, x + (w - fr.width(label)) / 2f, y + 3, 0xFFFFFFFF);
            small(ms, fr, sub, x + (w - fr.width(sub) * 0.75f) / 2f, y + 12, 0xFFC4C4D4);
        }
    }

    private void drawKeys(MatrixStack ms, FontRenderer fr, Minecraft mc) {
        int sh = mc.getWindow().getGuiScaledHeight();
        int u = 20, g = 2, s = u + g;
        int x = 8 + Hud.KEYS.dx, y = sh - 90 + Hud.KEYS.dy;
        Hud.KEYS.set(x, y, 3 * u + 2 * g, 3 * s + 8);

        drawKeyBox(ms, fr, 0, mc.options.keyUp.isDown(),    x + s,     y,         u, u, "W", null);
        drawKeyBox(ms, fr, 1, mc.options.keyLeft.isDown(),  x,         y + s,     u, u, "A", null);
        drawKeyBox(ms, fr, 2, mc.options.keyDown.isDown(),  x + s,     y + s,     u, u, "S", null);
        drawKeyBox(ms, fr, 3, mc.options.keyRight.isDown(), x + 2 * s, y + s,     u, u, "D", null);
        int bw = (3 * u + 2 * g - g) / 2;
        drawKeyBox(ms, fr, 4, mc.options.keyAttack.isDown(), x,          y + 2 * s, bw, u, "LMB", String.valueOf(cps(lmb)));
        drawKeyBox(ms, fr, 5, mc.options.keyUse.isDown(),    x + bw + g, y + 2 * s, bw, u, "RMB", String.valueOf(cps(rmb)));
        drawKeyBox(ms, fr, 6, mc.options.keyJump.isDown(),   x,          y + 3 * s, 3 * u + 2 * g, 6, "", null);
    }

    private void drawArmor(MatrixStack ms, FontRenderer fr, Minecraft mc) {
        int sh = mc.getWindow().getGuiScaledHeight();
        int x = 6 + Hud.ARMOR.dx, y = sh / 2 - 40 + Hud.ARMOR.dy;
        int w = 56, h = 4 * 18 + 4;
        Hud.ARMOR.set(x, y, w, h);
        Util.rrect(ms, x, y, x + w, y + h, 6, 0xB0101018);

        EquipmentSlotType[] slots = { EquipmentSlotType.HEAD, EquipmentSlotType.CHEST,
                EquipmentSlotType.LEGS, EquipmentSlotType.FEET };
        for (int i = 0; i < slots.length; i++) {
            ItemStack st = mc.player.getItemBySlot(slots[i]);
            int iy = y + 2 + i * 18;
            if (st.isEmpty()) continue;
            mc.getItemRenderer().renderGuiItem(st, x + 3, iy);
            if (st.isDamageableItem() && st.getMaxDamage() > 0) {
                float ratio = (st.getMaxDamage() - st.getDamageValue()) / (float) st.getMaxDamage();
                small(ms, fr, Math.round(ratio * 100) + "%", x + 23, iy + 5,
                        Util.mix(0xEF4444, 0x34D399, ratio));
            }
        }
    }
}
