package com.aurora.client;

import com.mojang.blaze3d.matrix.MatrixStack;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.AbstractGui;
import net.minecraft.client.gui.FontRenderer;
import net.minecraftforge.client.event.RenderGameOverlayEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;

import java.awt.Color;

public class WatermarkRenderer {
    private int frames = 0;
    private int fps = 0;
    private long lastSecond = System.currentTimeMillis();

    @SubscribeEvent
    public void onRender(RenderGameOverlayEvent.Post e) {
        if (e.getType() != RenderGameOverlayEvent.ElementType.ALL) return;
        Minecraft mc = Minecraft.getInstance();
        if (mc.player == null || mc.options.hideGui) return;

        // FPS counter
        frames++;
        long now = System.currentTimeMillis();
        if (now - lastSecond >= 1000) {
            fps = frames;
            frames = 0;
            lastSecond = now;
        }

        MatrixStack ms = e.getMatrixStack();
        FontRenderer fr = mc.font;

        String name = AuroraClient.NAME;
        String info = "  |  " + fps + " FPS  |  " + mc.player.getName().getString();

        int x = 5, y = 5, pad = 4;
        int width = fr.width(name) + fr.width(info) + pad * 2;
        int height = fr.lineHeight + pad * 2 - 1;

        // background + animated accent line
        AbstractGui.fill(ms, x, y, x + width, y + height, 0x90000000);
        float t = (now % 4000L) / 4000f;
        for (int i = 0; i < width; i++) {
            int c = Color.HSBtoRGB((t + i / (float) width * 0.5f) % 1f, 0.6f, 1f);
            AbstractGui.fill(ms, x + i, y, x + i + 1, y + 1, 0xFF000000 | c);
        }

        // gradient name
        float cx = x + pad;
        int ty = y + pad;
        for (int i = 0; i < name.length(); i++) {
            String ch = String.valueOf(name.charAt(i));
            int c = Color.HSBtoRGB((t + i * 0.07f) % 1f, 0.55f, 1f);
            fr.drawShadow(ms, ch, cx, ty, 0xFF000000 | c);
            cx += fr.width(ch);
        }
        fr.drawShadow(ms, info, cx, ty, 0xFFCCCCCC);
    }
}
