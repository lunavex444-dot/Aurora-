package com.aurora.client;

import net.minecraft.client.Minecraft;
import net.minecraft.client.entity.player.ClientPlayerEntity;
import net.minecraft.entity.Entity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.item.ArmorStandEntity;
import net.minecraft.entity.monster.IMob;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.inventory.container.ClickType;
import net.minecraft.item.Items;
import net.minecraft.network.play.client.CEntityActionPacket;
import net.minecraft.network.play.client.CPlayerPacket;
import net.minecraft.util.Hand;
import net.minecraft.util.math.AxisAlignedBB;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.RayTraceResult;
import net.minecraft.util.math.vector.Vector3d;
import net.minecraftforge.client.event.InputEvent;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;

import java.util.List;
import java.util.Random;

/**
 * Боевые модули Aurora: KillAura, AimAssist, TriggerBot, AutoClicker,
 * Criticals, Sprint Reset, Velocity, AutoTotem.
 */
public class Combat {
    private final Random rnd = new Random();

    private long lastAttack = 0L;
    private long nextClick = 0L;
    private int lastHurt = 0;
    private int totemTimer = 0;

    // ------------------------------------------------ events
    @SubscribeEvent
    public void onTick(TickEvent.ClientTickEvent e) {
        if (e.phase != TickEvent.Phase.END) return;
        Minecraft mc = Minecraft.getInstance();
        ClientPlayerEntity p = mc.player;
        if (p == null || mc.level == null || mc.gameMode == null) {
            lastHurt = 0;
            return;
        }

        velocity(p);

        if (mc.screen != null || !p.isAlive() || p.isSpectator()) return;

        boolean auraBusy = false;
        if (Modules.KILLAURA.enabled) auraBusy = killAura(mc, p);
        if (Modules.AIMASSIST.enabled && !auraBusy) aimAssist(mc, p);
        if (Modules.TRIGGERBOT.enabled) triggerBot(mc, p);
        if (Modules.AUTOCLICKER.enabled) autoClicker(mc, p);
        if (Modules.AUTOTOTEM.enabled) autoTotem(mc, p);
    }

    /** Ручной удар по сущности: подмешиваем крит/спринт-ресет перед атакой. */
    @SubscribeEvent
    public void onClick(InputEvent.ClickInputEvent e) {
        if (!e.isAttack()) return;
        Minecraft mc = Minecraft.getInstance();
        if (mc.player == null || mc.hitResult == null) return;
        if (mc.hitResult.getType() == RayTraceResult.Type.ENTITY) preAttack(mc, mc.player);
    }

    // ------------------------------------------------ modules
    private boolean killAura(Minecraft mc, ClientPlayerEntity p) {
        double range = Double.parseDouble(Modules.AURARANGE.modes[Modules.AURARANGE.mode]);
        LivingEntity t = findTarget(mc, p, range, false);
        if (t == null) return false;

        int rotMode = Modules.AURAROTATION.mode; // 0 Smooth, 1 Snap, 2 None
        boolean aimed = true;
        if (rotMode != 2) {
            float[] r = rotationTo(p, t);
            if (rotMode == 1) {
                p.yRot = r[0];
                p.xRot = MathHelper.clamp(r[1], -90.0F, 90.0F);
            } else {
                turn(p, r[0], r[1], 32.0F);
            }
            float dy = Math.abs(MathHelper.wrapDegrees(r[0] - p.yRot));
            float dp = Math.abs(MathHelper.wrapDegrees(r[1] - p.xRot));
            aimed = dy < 25.0F && dp < 35.0F;
        }

        if (aimed && !p.isUsingItem() && ready(p, Modules.AURADELAY.mode)) attack(mc, p, t);
        return true;
    }

    private void aimAssist(Minecraft mc, ClientPlayerEntity p) {
        if (!mc.options.keyAttack.isDown()) return;
        LivingEntity t = findTarget(mc, p, 4.5, true);
        if (t == null) return;
        float speed;
        switch (Modules.AIMSPEED.mode) {
            case 0:  speed = 3.0F; break;
            case 1:  speed = 6.0F; break;
            default: speed = 11.0F; break;
        }
        float[] r = rotationTo(p, t);
        turn(p, r[0], r[1], speed);
    }

    private void triggerBot(Minecraft mc, ClientPlayerEntity p) {
        Entity look = mc.crosshairPickEntity;
        if (!(look instanceof LivingEntity)) return;
        LivingEntity t = (LivingEntity) look;
        if (!valid(mc, t) || p.isUsingItem()) return;
        if (ready(p, 0)) attack(mc, p, t);
    }

    private void autoClicker(Minecraft mc, ClientPlayerEntity p) {
        if (!mc.options.keyAttack.isDown()) return;
        Entity look = mc.crosshairPickEntity;
        if (!(look instanceof LivingEntity) || look == p || look instanceof ArmorStandEntity) return;
        long now = System.currentTimeMillis();
        if (now < nextClick) return;
        int cps = Integer.parseInt(Modules.CLICKCPS.modes[Modules.CLICKCPS.mode]);
        nextClick = now + (long) (1000.0 / cps * (0.85 + rnd.nextDouble() * 0.30));
        attack(mc, p, look);
    }

    private void velocity(ClientPlayerEntity p) {
        int hurt = p.hurtTime;
        if (Modules.VELOCITY.enabled && hurt > lastHurt && hurt > 0) {
            double[] keep = {0.0, 0.25, 0.5, 0.75};
            double f = keep[Math.max(0, Math.min(3, Modules.VELOCITYAMT.mode))];
            Vector3d m = p.getDeltaMovement();
            p.setDeltaMovement(m.x * f, m.y, m.z * f);
        }
        lastHurt = hurt;
    }

    private void autoTotem(Minecraft mc, ClientPlayerEntity p) {
        if (p.containerMenu != p.inventoryMenu) return;
        if (p.getOffhandItem().getItem() == Items.TOTEM_OF_UNDYING) { totemTimer = 0; return; }

        float hp = p.getHealth();
        int mode = Modules.TOTEMHP.mode;
        if (mode == 1 && hp > 10.0F) return;
        if (mode == 2 && hp > 6.0F) return;

        if (++totemTimer < 4) return;
        totemTimer = 0;

        // сначала основной инвентарь (9..35), потом хотбар (0..8)
        int found = -1;
        for (int i = 9; i < 36 && found < 0; i++)
            if (p.inventory.getItem(i).getItem() == Items.TOTEM_OF_UNDYING) found = i;
        for (int i = 0; i < 9 && found < 0; i++)
            if (p.inventory.getItem(i).getItem() == Items.TOTEM_OF_UNDYING) found = i;
        if (found < 0) return;

        int slot = found < 9 ? 36 + found : found;
        // SWAP с кнопкой 40 = обмен слота с левой рукой
        mc.gameMode.handleInventoryMouseClick(p.inventoryMenu.containerId, slot, 40, ClickType.SWAP, p);
    }

    // ------------------------------------------------ attack helpers
    private boolean ready(ClientPlayerEntity p, int delayMode) {
        long now = System.currentTimeMillis();
        switch (delayMode) {
            case 0:  return p.getAttackStrengthScale(0.5F) >= 0.95F && now - lastAttack >= 60L;
            case 1:  return now - lastAttack >= 100L;
            default: return now - lastAttack >= 60L;
        }
    }

    private void attack(Minecraft mc, ClientPlayerEntity p, Entity target) {
        preAttack(mc, p);
        mc.gameMode.attack(p, target);
        p.swing(Hand.MAIN_HAND);
        lastAttack = System.currentTimeMillis();
    }

    private void preAttack(Minecraft mc, ClientPlayerEntity p) {
        if (mc.getConnection() == null) return;

        if (Modules.SPRINTRESET.enabled && p.isSprinting()) {
            mc.getConnection().send(new CEntityActionPacket(p, CEntityActionPacket.Action.STOP_SPRINTING));
            mc.getConnection().send(new CEntityActionPacket(p, CEntityActionPacket.Action.START_SPRINTING));
        }

        if (Modules.CRITICALS.enabled && p.isOnGround() && !p.isInWater() && !p.isInLava()
                && !p.onClimbable() && !p.isPassenger()) {
            double x = p.getX(), y = p.getY(), z = p.getZ();
            mc.getConnection().send(new CPlayerPacket.PositionPacket(x, y + 0.0625D, z, false));
            mc.getConnection().send(new CPlayerPacket.PositionPacket(x, y, z, false));
        }
    }

    // ------------------------------------------------ targeting
    private boolean valid(Minecraft mc, LivingEntity e) {
        if (e == mc.player || !e.isAlive() || e.getHealth() <= 0.0F
                || e instanceof ArmorStandEntity || e.isSpectator()) return false;
        switch (Modules.AURATARGETS.mode) {
            case 0:  return e instanceof PlayerEntity;
            case 1:  return e instanceof IMob;
            default: return true;
        }
    }

    private LivingEntity findTarget(Minecraft mc, ClientPlayerEntity p, double range, boolean needFov) {
        AxisAlignedBB area = p.getBoundingBox().inflate(range + 1.0);
        List<LivingEntity> list = mc.level.getEntitiesOfClass(LivingEntity.class, area);
        boolean byHealth = Modules.AURAPRIORITY.mode == 1;

        LivingEntity best = null;
        double bestScore = Double.MAX_VALUE;
        for (LivingEntity e : list) {
            if (!valid(mc, e)) continue;
            double d = distance(p, e);
            if (d > range) continue;
            if (needFov) {
                float[] r = rotationTo(p, e);
                if (Math.abs(MathHelper.wrapDegrees(r[0] - p.yRot)) > 50.0F) continue;
                if (Math.abs(MathHelper.wrapDegrees(r[1] - p.xRot)) > 60.0F) continue;
            }
            double score = byHealth ? e.getHealth() + d * 0.01 : d;
            if (score < bestScore) { bestScore = score; best = e; }
        }
        return best;
    }

    /** Расстояние от глаз до ближайшей точки хитбокса цели. */
    private static double distance(ClientPlayerEntity p, Entity e) {
        Vector3d eye = p.getEyePosition(1.0F);
        AxisAlignedBB bb = e.getBoundingBox();
        double dx = Math.max(Math.max(bb.minX - eye.x, 0.0), eye.x - bb.maxX);
        double dy = Math.max(Math.max(bb.minY - eye.y, 0.0), eye.y - bb.maxY);
        double dz = Math.max(Math.max(bb.minZ - eye.z, 0.0), eye.z - bb.maxZ);
        return Math.sqrt(dx * dx + dy * dy + dz * dz);
    }

    /** {yaw, pitch} от глаз игрока к телу цели. */
    private static float[] rotationTo(ClientPlayerEntity p, Entity e) {
        Vector3d eye = p.getEyePosition(1.0F);
        AxisAlignedBB bb = e.getBoundingBox();
        double h = bb.maxY - bb.minY;
        double tx = e.getX();
        double tz = e.getZ();
        double ty = Math.max(bb.minY + h * 0.2, Math.min(bb.maxY - h * 0.1, eye.y));
        double dx = tx - eye.x, dy = ty - eye.y, dz = tz - eye.z;
        double flat = Math.sqrt(dx * dx + dz * dz);
        float yaw = (float) Math.toDegrees(Math.atan2(dz, dx)) - 90.0F;
        float pitch = (float) -Math.toDegrees(Math.atan2(dy, flat));
        return new float[]{yaw, pitch};
    }

    private static void turn(ClientPlayerEntity p, float yaw, float pitch, float speed) {
        float dy = MathHelper.wrapDegrees(yaw - p.yRot);
        float dp = pitch - p.xRot;
        p.yRot += MathHelper.clamp(dy, -speed, speed);
        p.xRot = MathHelper.clamp(p.xRot + MathHelper.clamp(dp, -speed * 0.7F, speed * 0.7F), -90.0F, 90.0F);
    }
}
