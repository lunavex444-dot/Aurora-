package com.aurora.client;

import com.mojang.blaze3d.platform.GlStateManager;
import com.mojang.blaze3d.systems.RenderSystem;
import net.minecraft.client.Minecraft;
import net.minecraft.client.renderer.BufferBuilder;
import net.minecraft.client.renderer.Tessellator;
import net.minecraft.client.renderer.vertex.DefaultVertexFormats;
import net.minecraft.util.math.vector.Matrix4f;
import net.minecraft.world.World;
import net.minecraftforge.client.event.EntityViewRenderEvent;
import net.minecraftforge.client.event.RenderWorldLastEvent;
import net.minecraftforge.eventbus.api.EventPriority;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import org.lwjgl.opengl.GL11;

import java.util.Random;

/**
 * Custom Sky: своё небо в обычном мире (Overworld). Градиентный купол выбранного цвета,
 * своё солнце, луна и звёзды. Туман подстраивается под цвет горизонта.
 */
public class Sky {
    private static final double R = 150.0;

    // зенит, середина, горизонт
    private static final int[][] PAL = {
            {0x1A0204, 0x8A0F14, 0xFF4A3A}, // Red
            {0x2B1202, 0xC2570C, 0xFFB347}, // Orange
            {0x2A0A2E, 0xC2458F, 0xFF9ED2}, // Pink
            {0x0D0620, 0x5B2A9E, 0xB77BFF}, // Purple
            {0x020B2E, 0x1F5FD1, 0x7FC4FF}, // Blue
            {0x02160A, 0x12864A, 0x7DFFB3}, // Green
            {0x000000, 0x07070C, 0x1C1C28}  // Black
    };

    private final float[][] stars = new float[170][];

    public Sky() {
        Random r = new Random(1337);
        for (int i = 0; i < stars.length; i++) {
            double y, x, z;
            do {
                x = r.nextDouble() * 2 - 1;
                y = r.nextDouble() * 2 - 1;
                z = r.nextDouble() * 2 - 1;
            } while (x * x + y * y + z * z > 1 || x * x + y * y + z * z < 0.05);
            double l = Math.sqrt(x * x + y * y + z * z);
            if (y < 0) y = -y;
            stars[i] = new float[]{(float) (x / l), (float) (y / l), (float) (z / l),
                    0.6f + r.nextFloat() * 0.9f, r.nextFloat() * 6.28f};
        }
    }

    // ------------------------------------------------ helpers
    private boolean active() {
        Minecraft mc = Minecraft.getInstance();
        return Modules.SKY.enabled && mc.level != null && mc.level.dimension() == World.OVERWORLD;
    }

    private int[] palette() {
        int m = Modules.SKYCOLOR.mode;
        if (m >= 0 && m < PAL.length) return PAL[m];
        int acc = Util.accent(0f) & 0xFFFFFF;
        return new int[]{Util.lerp(0x000000, acc, 0.12f), Util.lerp(0x000000, acc, 0.5f),
                Util.lerp(acc, 0xFFFFFF, 0.2f)};
    }

    /** Направление на солнце (как у ванили): утром на востоке, днём вверху. */
    private double[] sunDir(float pt) {
        Minecraft mc = Minecraft.getInstance();
        long t = mc.level.getDayTime();
        double dt = ((t % 24000L) + pt) / 24000.0;
        double d0 = dt - 0.25;
        d0 = d0 - Math.floor(d0);
        double d1 = 0.5 - Math.cos(d0 * Math.PI) / 2.0;
        double tod = (d0 * 2.0 + d1) / 3.0;
        double th = tod * Math.PI * 2;
        return new double[]{-Math.sin(th), Math.cos(th), 0};
    }

    /** 1 днём, около 0.3 ночью. */
    private double dayFactor(double sunY) {
        double t = Math.max(0, Math.min(1, (sunY + 0.15) / 0.40));
        return 0.3 + 0.7 * t * t * (3 - 2 * t);
    }

    private double smooth(double t) {
        t = Math.max(0, Math.min(1, t));
        return t * t * (3 - 2 * t);
    }

    private int skyColor(int[] pal, double lat, double f) {
        double t = Math.max(0, lat) / 90.0;
        int c;
        if (lat <= 0) c = pal[2];
        else if (t < 0.4) c = Util.lerp(pal[2], pal[1], (float) smooth(t / 0.4));
        else c = Util.lerp(pal[1], pal[0], (float) smooth((t - 0.4) / 0.6));
        c = Util.lerp(0x000000, c, (float) f);
        return 0xFF000000 | c;
    }

    // ------------------------------------------------ events
    @SubscribeEvent
    public void onFog(EntityViewRenderEvent.FogColors e) {
        if (!active()) return;
        int[] pal = palette();
        double f = dayFactor(sunDir(0f)[1]);
        int c = Util.lerp(0x000000, pal[2], (float) f);
        e.setRed(((c >> 16) & 255) / 255f);
        e.setGreen(((c >> 8) & 255) / 255f);
        e.setBlue((c & 255) / 255f);
    }

    @SubscribeEvent(priority = EventPriority.HIGHEST)
    public void onWorld(RenderWorldLastEvent e) {
        if (!active()) return;
        Minecraft mc = Minecraft.getInstance();
        if (mc.player == null || mc.player.isUnderWater()) return;

        float pt = e.getPartialTicks();
        Matrix4f m = e.getMatrixStack().last().pose();
        int[] pal = palette();
        double[] sun = sunDir(pt);
        double f = dayFactor(sun[1]);
        double time = System.currentTimeMillis() / 1000.0;

        RenderSystem.disableTexture();
        RenderSystem.disableCull();
        RenderSystem.depthMask(false);
        RenderSystem.disableBlend();
        RenderSystem.disableAlphaTest();

        Tessellator tess = Tessellator.getInstance();
        BufferBuilder bb = tess.getBuilder();

        // купол неба
        bb.begin(GL11.GL_TRIANGLES, DefaultVertexFormats.POSITION_COLOR);
        double[] lats = {-25, 0, 8, 18, 30, 45, 62, 78, 90};
        int segs = 36;
        for (int i = 0; i < lats.length - 1; i++) {
            int c0 = skyColor(pal, lats[i], f), c1 = skyColor(pal, lats[i + 1], f);
            for (int j = 0; j < segs; j++) {
                double l0 = Math.PI * 2 * j / segs, l1 = Math.PI * 2 * (j + 1) / segs;
                double[] a = pt(lats[i], l0), b = pt(lats[i], l1), c = pt(lats[i + 1], l1), d = pt(lats[i + 1], l0);
                v(bb, m, a, c0); v(bb, m, b, c0); v(bb, m, c, c1);
                v(bb, m, a, c0); v(bb, m, c, c1); v(bb, m, d, c1);
            }
        }
        tess.end();

        // свечение, солнце, луна, звёзды
        RenderSystem.enableBlend();
        RenderSystem.blendFunc(GlStateManager.SourceFactor.SRC_ALPHA, GlStateManager.DestFactor.ONE);
        bb.begin(GL11.GL_TRIANGLES, DefaultVertexFormats.POSITION_COLOR);

        int hor = pal[2];
        int warm = Util.lerp(hor, 0xFFFFFF, 0.65f);
        int glowA = (int) (90 * Math.max(0.25, f));
        disc(bb, m, sun, R * 0.95, R * 0.6, (glowA << 24) | hor, hor & 0xFFFFFF, 24);
        int sunA = (int) (255 * Math.max(0.0, Math.min(1.0, (sun[1] + 0.2) / 0.3)));
        disc(bb, m, sun, R * 0.95, R * 0.085, (sunA << 24) | warm, ((sunA / 2) << 24) | warm, 24);

        double[] moon = {-sun[0], -sun[1], -sun[2]};
        int moonA = (int) (230 * Math.max(0.0, Math.min(1.0, (moon[1] + 0.15) / 0.3)));
        disc(bb, m, moon, R * 0.95, R * 0.14, ((moonA / 4) << 24) | 0xB8C8FF, 0xB8C8FF, 20);
        disc(bb, m, moon, R * 0.95, R * 0.055, (moonA << 24) | 0xEEF2FF, ((moonA / 2) << 24) | 0xEEF2FF, 20);

        double night = Math.max(0.0, Math.min(1.0, (-sun[1] + 0.05) / 0.25));
        if (night > 0.01) {
            int tint = Util.lerp(0xFFFFFF, hor, 0.3f);
            for (float[] s : stars) {
                double tw = 0.35 + 0.65 * (0.5 + 0.5 * Math.sin(time * 2.0 + s[4]));
                int a = (int) (255 * night * tw);
                double[] dir = {s[0], s[1], s[2]};
                disc(bb, m, dir, R * 0.97, R * 0.012 * s[3], (a << 24) | tint, tint & 0xFFFFFF, 4);
            }
        }
        tess.end();

        RenderSystem.depthMask(true);
        RenderSystem.enableCull();
        RenderSystem.enableTexture();
        RenderSystem.enableAlphaTest();
        RenderSystem.defaultBlendFunc();
        RenderSystem.disableBlend();
    }

    // ------------------------------------------------ drawing
    private double[] pt(double latDeg, double lon) {
        double lat = Math.toRadians(latDeg);
        return new double[]{R * Math.cos(lat) * Math.cos(lon), R * Math.sin(lat), R * Math.cos(lat) * Math.sin(lon)};
    }

    private void v(BufferBuilder bb, Matrix4f m, double[] p, int c) {
        v(bb, m, p[0], p[1], p[2], c);
    }

    private void v(BufferBuilder bb, Matrix4f m, double x, double y, double z, int c) {
        bb.vertex(m, (float) x, (float) y, (float) z)
                .color(((c >> 16) & 255) / 255f, ((c >> 8) & 255) / 255f, (c & 255) / 255f, ((c >>> 24) & 255) / 255f)
                .endVertex();
    }

    /** Диск перпендикулярно направлению d на расстоянии dist от камеры. */
    private void disc(BufferBuilder bb, Matrix4f m, double[] d, double dist, double rad,
                      int centerCol, int edgeCol, int segs) {
        double cx = d[0] * dist, cy = d[1] * dist, cz = d[2] * dist;
        double ax = d[1] * 0 - d[2] * 1, ay = d[2] * 0 - d[0] * 0, az = d[0] * 1 - d[1] * 0; // d x (0,1,0)
        double al = Math.sqrt(ax * ax + ay * ay + az * az);
        if (al < 1e-4) { ax = 1; ay = 0; az = 0; al = 1; }
        ax /= al; ay /= al; az /= al;
        double bx = ay * d[2] - az * d[1], by = az * d[0] - ax * d[2], bz = ax * d[1] - ay * d[0]; // a x d
        for (int i = 0; i < segs; i++) {
            double a0 = Math.PI * 2 * i / segs, a1 = Math.PI * 2 * (i + 1) / segs;
            double c0 = Math.cos(a0) * rad, s0 = Math.sin(a0) * rad;
            double c1 = Math.cos(a1) * rad, s1 = Math.sin(a1) * rad;
            v(bb, m, cx, cy, cz, centerCol);
            v(bb, m, cx + ax * c0 + bx * s0, cy + ay * c0 + by * s0, cz + az * c0 + bz * s0, edgeCol);
            v(bb, m, cx + ax * c1 + bx * s1, cy + ay * c1 + by * s1, cz + az * c1 + bz * s1, edgeCol);
        }
    }
}
