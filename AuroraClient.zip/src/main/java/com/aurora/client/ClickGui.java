package com.aurora.client;

import com.mojang.blaze3d.matrix.MatrixStack;
import net.minecraft.client.audio.SimpleSound;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.widget.TextFieldWidget;
import net.minecraft.client.util.InputMappings;
import net.minecraft.util.SoundEvents;
import net.minecraft.util.text.StringTextComponent;
import org.lwjgl.glfw.GLFW;

import java.util.ArrayList;
import java.util.List;

/** AuroraClient GUI: логотип сверху, тёмная панель с двумя колонками, док с разделами снизу. */
public class ClickGui extends Screen {
    private static final int PAD = 14, ROW = 28, CARD_H = 24, HEAD = 44, FOOT = 22;
    private static final int BTN = 22, GAP = 4, DOCK_H = 30, BRAND_H = 22;

    private static Category current = Category.COMBAT;
    private static String lastSearch = "";

    private final long openTime = System.currentTimeMillis();
    private TextFieldWidget search;
    private Module binding;
    private float fade = 0.1f;
    private int scroll = 0;
    private int W, H, X, Y, top;

    public ClickGui() {
        super(new StringTextComponent("AuroraClient"));
    }

    @Override
    protected void init() {
        W = Math.min(380, width - 12);
        H = Math.max(110, Math.min(214, height - DOCK_H - BRAND_H - 28));
        int total = BRAND_H + H + 10 + DOCK_H;
        top = Math.max(2, (height - total) / 2);
        X = (width - W) / 2;
        Y = top + BRAND_H;
        int sx = X + W - PAD - 104, sy = Y + 10;
        search = new TextFieldWidget(font, sx + 8, sy + 5, 90, 10, StringTextComponent.EMPTY);
        search.setBordered(false);
        search.setMaxLength(20);
        search.setValue(lastSearch);
        search.setResponder(s -> { lastSearch = s; scroll = 0; });
        addButton(search);
    }

    @Override
    public void removed() {
        Config.save();
    }

    private int a(int c) {
        int al = (int) (((c >>> 24) & 255) * fade);
        return (al << 24) | (c & 0xFFFFFF);
    }

    private void small(MatrixStack ms, String s, float x, float y, int color) {
        ms.pushPose();
        ms.scale(0.75f, 0.75f, 1f);
        font.drawShadow(ms, s, x / 0.75f, y / 0.75f, color);
        ms.popPose();
    }

    private float smallW(String s) { return font.width(s) * 0.75f; }

    private String keyName(int key) {
        if (key < 0) return "";
        try {
            String s = InputMappings.getKey(key, 0).getDisplayName().getString();
            return s.length() > 6 ? s.substring(0, 6) : s;
        } catch (Exception e) {
            return "?";
        }
    }

    private int count(Category c) {
        int n = 0;
        for (Module m : Modules.ALL) if (m.cat == c) n++;
        return n;
    }

    private String query() {
        return search == null ? "" : search.getValue().trim().toLowerCase();
    }

    private List<Module> visible() {
        List<Module> out = new ArrayList<>();
        String q = query();
        for (Module m : Modules.ALL) {
            if (q.isEmpty() ? m.cat == current : m.name.toLowerCase().contains(q)) out.add(m);
        }
        return out;
    }

    // ---------------------------------------------------------------- layout
    private int contentX() { return X + PAD; }
    private int cardW() { return (W - 2 * PAD - 8) / 2; }
    private int cardX(int i) { return contentX() + (i % 2) * (cardW() + 8); }
    private int cardY(int i) { return Y + HEAD + (i / 2 - scroll) * ROW; }
    private int rowsVisible() { return Math.max(1, (H - HEAD - FOOT) / ROW); }
    private boolean shown(int i) { int row = i / 2 - scroll; return row >= 0 && row < rowsVisible(); }
    private int maxScroll(int total) { return Math.max(0, (total + 1) / 2 - rowsVisible()); }

    private int dockW() { int n = Category.values().length; return n * BTN + (n - 1) * GAP + 12; }
    private int dockX() { return X + (W - dockW()) / 2; }
    private int dockY() { return Y + H + 10; }
    private int btnX(int i) { return dockX() + 6 + i * (BTN + GAP); }
    private int btnY() { return dockY() + (DOCK_H - BTN) / 2; }

    private void clickSound() {
        minecraft.getSoundManager().play(SimpleSound.forUI(SoundEvents.UI_BUTTON_CLICK, 1.0F));
    }

    // ---------------------------------------------------------------- render
    @Override
    public void render(MatrixStack ms, int mx, int my, float pt) {
        float t = Math.min(1f, (System.currentTimeMillis() - openTime) / 180f);
        fade = 0.1f + 0.9f * t;
        float sc = 0.94f + 0.06f * t;
        fill(ms, 0, 0, width, height, a(0x88050509));

        ms.pushPose();
        ms.translate(width / 2f, height / 2f, 0);
        ms.scale(sc, sc, 1f);
        ms.translate(-width / 2f, -height / 2f, 0);

        drawBrand(ms);
        drawPanel(ms, mx, my);
        drawDock(ms, mx, my);

        super.render(ms, mx, my, pt);
        ms.popPose();
    }

    private void drawBrand(MatrixStack ms) {
        String name = AuroraClient.NAME;
        int tw = font.width(name);
        int total = 14 + 6 + tw;
        int bx = (width - total) / 2, by = top + 2;
        Util.logo(ms, bx, by, 14);
        // "Aurora" градиентом, "Client" белым
        int w1 = Util.gradientText(ms, font, "Aurora", bx + 20, by + 3, 0f);
        font.drawShadow(ms, "Client", bx + 20 + w1, by + 3, a(0xFFFFFFFF));
    }

    private void drawPanel(MatrixStack ms, int mx, int my) {
        // рамка + фон
        Util.rrect(ms, X - 1, Y - 1, X + W + 1, Y + H + 1, 11, a(Util.withAlpha(Util.accent(0.1f), 0x40)));
        Util.rrect(ms, X, Y, X + W, Y + H, 10, a(0xF40B0B14));

        // шапка
        String q = query();
        font.drawShadow(ms, q.isEmpty() ? current.label : "Поиск", X + PAD, Y + 10, a(0xFFFFFFFF));
        small(ms, q.isEmpty() ? current.sub : "Результаты по всем разделам", X + PAD, Y + 23, a(0xFF77778A));
        fill(ms, X + PAD, Y + HEAD - 7, X + W - PAD, Y + HEAD - 6, a(0x18FFFFFF));

        // поиск
        int sx = X + W - PAD - 104, sy = Y + 10;
        Util.rrect(ms, sx, sy, sx + 104, sy + 18, 6, a(0x28FFFFFF));
        if (search.getValue().isEmpty() && !search.isFocused())
            small(ms, "Поиск...", sx + 8, sy + 6, a(0xFF77778A));

        // карточки
        if (current == Category.CONFIGS && q.isEmpty()) {
            small(ms, "Настройки, бинды и позиции HUD", X + PAD, Y + HEAD + 4, a(0xFFB0B0C4));
            small(ms, "сохраняются автоматически в файл", X + PAD, Y + HEAD + 16, a(0xFFB0B0C4));
            small(ms, "auroraclient.properties (папка игры)", X + PAD, Y + HEAD + 28, a(0xFF77778A));
        }
        List<Module> list = visible();
        scroll = Math.max(0, Math.min(maxScroll(list.size()), scroll));
        for (int i = 0; i < list.size(); i++) if (shown(i)) drawCard(ms, list.get(i), i, mx, my);

        // подсказка
        int fy = Y + H - 14;
        if (binding != null) {
            small(ms, "Нажми клавишу для бинда (ESC — убрать)", X + PAD, fy, a(Util.accent(0.3f)));
        } else {
            small(ms, "ПКМ — бинд", X + PAD, fy, a(0xFF5E5E72));
        }
        if (maxScroll(list.size()) > 0) {
            String s = "колесо мыши " + (scroll + 1) + "/" + (maxScroll(list.size()) + 1);
            small(ms, s, X + W - PAD - smallW(s), fy, a(0xFF5E5E72));
        }
    }

    private void drawCard(MatrixStack ms, Module m, int i, int mx, int my) {
        int x = cardX(i), y = cardY(i), w = cardW(), h = CARD_H;
        boolean hov = mx >= x && mx < x + w && my >= y && my < y + h;
        int acc = Util.accent(i * 0.15f);
        m.anim += ((m.enabled ? 1f : 0f) - m.anim) * 0.25f;
        boolean on = m.isToggle() && m.enabled;

        Util.rrect(ms, x, y, x + w, y + h, 6, a(hov ? 0xFF1D1D2B : 0xFF141420));
        if (on) Util.rrect(ms, x, y, x + w, y + h, 6, a(Util.withAlpha(acc, 0x22)));

        int textW = (int) ((w - 62) / 0.75f);
        font.drawShadow(ms, font.plainSubstrByWidth(m.name, w - 62), x + 8, y + 4, a(0xFFFFFFFF));
        small(ms, font.plainSubstrByWidth(m.desc, textW), x + 8, y + 15, a(0xFF77778A));

        int right = x + w - 8;
        if (m.isToggle()) {
            int sx = right - 22, sy = y + 7;
            Util.rrect(ms, sx, sy, sx + 22, sy + 10, 5, a(Util.mix(0x34344A, acc, m.anim)));
            int kx = sx + 2 + Math.round(12 * m.anim);
            Util.rrect(ms, kx, sy + 2, kx + 6, sy + 8, 3, a(0xFFFFFFFF));
            right = sx - 5;
        } else {
            String txt = m.isAction() ? "Open" : m.modes[m.mode];
            float tw = smallW(txt);
            Util.rrect(ms, right - tw - 8, y + 6, right, y + 18, 5, a(Util.withAlpha(acc, 0x40)));
            small(ms, txt, right - tw - 4, y + 9, a(acc));
            right = (int) (right - tw - 13);
        }

        if (!m.isAction()) {
            String bt = binding == m ? "..." : keyName(m.key);
            if (!bt.isEmpty()) {
                float bw = smallW(bt);
                Util.rrect(ms, right - bw - 6, y + 7, right, y + 17, 4, a(binding == m ? Util.withAlpha(acc, 0x70) : 0x26FFFFFF));
                small(ms, bt, right - bw - 3, y + 9, a(0xFFC4C4D4));
            }
        }
    }

    private void drawDock(MatrixStack ms, int mx, int my) {
        int dx = dockX(), dy = dockY(), dw = dockW();
        Util.rrect(ms, dx - 1, dy - 1, dx + dw + 1, dy + DOCK_H + 1, 11, a(Util.withAlpha(Util.accent(0.1f), 0x30)));
        Util.rrect(ms, dx, dy, dx + dw, dy + DOCK_H, 10, a(0xF40B0B14));

        Category[] cats = Category.values();
        Category hovered = null;
        for (int i = 0; i < cats.length; i++) {
            int bx = btnX(i), by = btnY();
            boolean sel = cats[i] == current && query().isEmpty();
            boolean hov = mx >= bx && mx < bx + BTN && my >= by && my < by + BTN;
            if (hov) hovered = cats[i];
            if (sel) Util.rrect(ms, bx, by, bx + BTN, by + BTN, 7, a(Util.accent(i * 0.1f)));
            else if (hov) Util.rrect(ms, bx, by, bx + BTN, by + BTN, 7, a(0x2AFFFFFF));
            String[] bmp = Util.ICONS[i];
            Util.icon(ms, bmp, bx + (BTN - 9) / 2, by + (BTN - bmp.length) / 2, a(sel ? 0xFFFFFFFF : 0xFF8E8EA6));
        }

        if (hovered != null) {
            String s = hovered.label + " · " + count(hovered);
            small(ms, s, X + (W - smallW(s)) / 2f, dy + DOCK_H + 4, a(0xFFB0B0C4));
        }
    }

    // ---------------------------------------------------------------- input
    @Override
    public boolean keyPressed(int key, int scan, int mods) {
        if (binding != null) {
            binding.key = (key == GLFW.GLFW_KEY_ESCAPE || key == GLFW.GLFW_KEY_BACKSPACE) ? -1 : key;
            binding = null;
            return true;
        }
        return super.keyPressed(key, scan, mods);
    }

    @Override
    public boolean mouseClicked(double mx, double my, int button) {
        if (super.mouseClicked(mx, my, button)) return true;
        if (button != 0 && button != 1) return false;
        binding = null;

        if (button == 0) {
            Category[] cats = Category.values();
            for (int i = 0; i < cats.length; i++) {
                int bx = btnX(i), by = btnY();
                if (mx >= bx && mx < bx + BTN && my >= by && my < by + BTN) {
                    current = cats[i];
                    scroll = 0;
                    search.setValue("");
                    clickSound();
                    return true;
                }
            }
        }

        List<Module> list = visible();
        for (int i = 0; i < list.size(); i++) {
            if (!shown(i)) continue;
            Module m = list.get(i);
            int x = cardX(i), y = cardY(i), w = cardW();
            if (mx >= x && mx < x + w && my >= y && my < y + CARD_H) {
                if (button == 1) {
                    if (!m.isAction()) binding = m;
                } else {
                    m.click();
                    if (m == Modules.HITSNDSEL) SoundFx.play(m.mode, 0.75f, 1.0f);
                }
                clickSound();
                return true;
            }
        }
        return false;
    }

    @Override
    public boolean mouseScrolled(double mx, double my, double delta) {
        int max = maxScroll(visible().size());
        scroll = Math.max(0, Math.min(max, scroll - (int) Math.signum(delta)));
        return true;
    }

    @Override
    public boolean isPauseScreen() { return false; }
}
