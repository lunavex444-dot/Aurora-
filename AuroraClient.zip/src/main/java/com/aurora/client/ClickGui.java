package com.aurora.client;

import com.mojang.blaze3d.matrix.MatrixStack;
import net.minecraft.client.audio.SimpleSound;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.widget.TextFieldWidget;
import net.minecraft.client.util.InputMappings;
import net.minecraft.util.SoundEvents;
import net.minecraft.util.text.StringTextComponent;
import org.lwjgl.glfw.GLFW;
import org.lwjgl.opengl.GL11;

import java.util.ArrayList;
import java.util.List;

/**
 * AuroraClient GUI 3: ряд панелей-колонок (Combat, Movement, ...) поверх игры,
 * сверху строка поиска, справа панель тем. Листание: вверх-вниз внутри панели,
 * вбок для перемещения между панелями. Заголовок панели сворачивает её.
 */
public class ClickGui extends Screen {
    private static final int PW = 106, GAP = 6, HEADH = 17, ROW = 15, SROW = 24, PY = 30, M = 8;
    private static final float NS = 0.85f;
    private static final Category[] CATS = {Category.COMBAT, Category.MOVEMENT, Category.HUD, Category.VISUALS,
            Category.EFFECTS, Category.COSMETICS, Category.CLIENT};
    private static final int N = CATS.length + 1, THEME_P = CATS.length;
    private static final String[] CFG_ROWS = {"HUD Editor", "Reset HUD", "Save settings"};
    private static final String[] CFG_BTN = {"Open", "Reset", "Save"};

    private static final int[] SCROLL = new int[N];
    private static final boolean[] COLLAPSED = new boolean[N];
    private static int hscroll = 0, themeTab = 0;
    private static String lastSearch = "";

    private final long openTime = System.currentTimeMillis();
    private TextFieldWidget search;
    private Module binding;
    private float fade = 0.1f;
    private int PH;

    // нажатие: 0 нет, 1 строка, 2 иконка бинда, 3 заголовок, 5 тема, 6 действие конфигов, 7 пустое место
    private int pressKind, pressPanel, pressIdx, axis;
    private Module pressed, sliderDrag;
    private int sliderPanel;
    private double pressX, pressY, accX, accY;
    private boolean moved;

    public ClickGui() {
        super(new StringTextComponent("AuroraClient"));
    }

    @Override
    protected void init() {
        PH = Math.max(110, Math.min(height - PY - 14, 210));
        int bw = Math.min(190, width - 16), bx = (width - bw) / 2;
        search = new TextFieldWidget(font, bx + 22, 12, bw - 30, 10, StringTextComponent.EMPTY);
        search.setBordered(false);
        search.setMaxLength(20);
        search.setValue(lastSearch);
        search.setResponder(s -> {
            lastSearch = s;
            for (int i = 0; i < N; i++) SCROLL[i] = 0;
        });
        addButton(search);
    }

    @Override
    public void removed() {
        Config.save();
    }

    // ---------------------------------------------------------------- helpers
    private int a(int c) {
        int al = (int) (((c >>> 24) & 255) * fade);
        return (al << 24) | (c & 0xFFFFFF);
    }

    private void txt(MatrixStack ms, String s, float x, float y, int color, float scale) {
        ms.pushPose();
        ms.scale(scale, scale, 1f);
        font.drawShadow(ms, s, x / scale, y / scale, color);
        ms.popPose();
    }

    private float sw(String s, float scale) { return font.width(s) * scale; }

    private String keyName(int key) {
        try {
            String s = InputMappings.getKey(key, 0).getDisplayName().getString();
            return s.length() > 2 ? s.substring(0, 2) : s;
        } catch (Exception e) {
            return "?";
        }
    }

    private String query() {
        return search == null ? "" : search.getValue().trim().toLowerCase();
    }

    private void clickSound() {
        minecraft.getSoundManager().play(SimpleSound.forUI(SoundEvents.UI_BUTTON_CLICK, 1.0F));
    }

    private int clamp(int v, int lo, int hi) { return Math.max(lo, Math.min(hi, v)); }

    // ---------------------------------------------------------------- layout
    private int px(int p) { return M + p * (PW + GAP) - hscroll; }
    private int panelH(int p) { return COLLAPSED[p] ? HEADH : PH; }
    private int maxHScroll() { return Math.max(0, M + N * (PW + GAP) - GAP + M - width); }
    private int themeCount() { return themeTab == 0 ? Modules.THEME.modes.length : CFG_ROWS.length; }
    private int rowH(Module m) { return m.isSlider() ? SROW : ROW; }

    private List<Module> rows(int p) {
        List<Module> out = new ArrayList<>();
        String q = query();
        for (Module m : Modules.ALL) {
            if (m.cat == CATS[p] && (q.isEmpty() || m.name.toLowerCase().contains(q))) out.add(m);
        }
        return out;
    }

    private int contentH(int p) {
        if (p == THEME_P) return themeCount() * ROW + 4;
        int h = 4;
        for (Module m : rows(p)) h += rowH(m);
        return h;
    }

    private int maxScroll(int p) { return Math.max(0, contentH(p) - (panelH(p) - HEADH)); }

    private int rowTop(int p, int idx) {
        int y = PY + HEADH + 2 - SCROLL[p];
        if (p == THEME_P) return y + idx * ROW;
        List<Module> l = rows(p);
        for (int i = 0; i < idx && i < l.size(); i++) y += rowH(l.get(i));
        return y;
    }

    private int tab0W() { return (int) sw("Theme", 0.75f) + 10; }

    /** Что под пальцем: {панель, строка, часть}. Часть: 1 строка, 2 иконка, 3 заголовок, 4/5 вкладки, 6 ползунок. */
    private int[] find(double mx, double my) {
        for (int p = 0; p < N; p++) {
            int x = px(p);
            if (mx < x || mx >= x + PW || my < PY || my >= PY + panelH(p)) continue;
            if (my < PY + HEADH) {
                if (p == THEME_P) return new int[]{p, 0, mx < x + 4 + tab0W() + 1 ? 4 : 5};
                return new int[]{p, 0, 3};
            }
            int count = p == THEME_P ? themeCount() : rows(p).size();
            List<Module> l = p == THEME_P ? null : rows(p);
            for (int i = 0; i < count; i++) {
                int y = rowTop(p, i);
                int rh = p == THEME_P ? ROW : rowH(l.get(i));
                if (my >= y && my < y + rh) {
                    int part = 1;
                    if (l != null) {
                        Module m = l.get(i);
                        if (m.isSlider()) { if (my >= y + 12) part = 6; }
                        else if (!m.isAction() && mx < x + 20) part = 2;
                    }
                    return new int[]{p, i, part};
                }
            }
            return new int[]{p, -1, 0};
        }
        return null;
    }

    // ---------------------------------------------------------------- render
    @Override
    public void render(MatrixStack ms, int mx, int my, float pt) {
        float t = Math.min(1f, (System.currentTimeMillis() - openTime) / 180f);
        fade = 0.1f + 0.9f * t;
        hscroll = clamp(hscroll, 0, maxHScroll());

        fill(ms, 0, 0, width, height, a(0x66000000));
        fillGradient(ms, 0, 0, width, height / 2, a(Util.withAlpha(Util.accent(0.2f), 0x30)), 0x00000000);

        drawTopBar(ms);
        for (int p = 0; p < N; p++) drawPanel(ms, p, mx, my);

        String hint = binding != null ? "Нажми клавишу для бинда (ESC — убрать)"
                : "Тап — вкл/выкл  ·  «+» слева — бинд  ·  тяни — листать  ·  заголовок — свернуть";
        txt(ms, hint, (width - sw(hint, 0.75f)) / 2f, height - 9, a(binding != null ? Util.accent(0.3f) : 0xFF5E5E72), 0.75f);

        super.render(ms, mx, my, pt);
    }

    private void drawTopBar(MatrixStack ms) {
        int bw = Math.min(190, width - 16), bx = (width - bw) / 2, by = 8;
        Util.rrect(ms, bx - 1, by - 1, bx + bw + 1, by + 17, 9, a(0x22FFFFFF));
        Util.rrect(ms, bx, by, bx + bw, by + 16, 8, a(0xD0111116));
        Util.rrect(ms, bx + 8, by + 5, bx + 13, by + 7, 1, a(0xFF8E8EA6));
        Util.rrect(ms, bx + 8, by + 6, bx + 17, by + 12, 1, a(0xFF8E8EA6));
        if (search.getValue().isEmpty() && !search.isFocused())
            txt(ms, "Поиск модулей...", bx + 22, by + 5, a(0xFF6E6E82), 0.8f);

        String lab = AuroraClient.NAME + " 1.13";
        float lw = sw(lab, 0.75f);
        int rx = (int) (width - M - lw - 10);
        if (rx > bx + bw + 4) {
            Util.rrect(ms, rx, by + 1, rx + lw + 10, by + 15, 6, a(Util.withAlpha(Util.accent(0.2f), 0x40)));
            txt(ms, lab, rx + 5, by + 5, a(0xFFE6E6F0), 0.75f);
        }
    }

    private void scissorOn(int x, int y, int w, int h) {
        double s = minecraft.getWindow().getGuiScale();
        int x0 = Math.max(0, x), x1 = Math.min(width, x + w);
        int sx = (int) Math.round(x0 * s), swid = (int) Math.round(Math.max(0, x1 - x0) * s);
        int sy = (int) Math.round(minecraft.getWindow().getHeight() - (y + h) * s);
        int sh = (int) Math.round(h * s);
        GL11.glEnable(GL11.GL_SCISSOR_TEST);
        GL11.glScissor(sx, Math.max(0, sy), Math.max(0, swid), Math.max(0, sh));
    }

    private void scissorOff() {
        GL11.glDisable(GL11.GL_SCISSOR_TEST);
    }

    private void drawPanel(MatrixStack ms, int p, int mx, int my) {
        int x = px(p);
        if (x + PW < 0 || x > width) return;
        int h = panelH(p);
        int acc = Util.accent(p * 0.12f);

        Util.rrect(ms, x - 1, PY - 1, x + PW + 1, PY + h + 1, 8, a(0x1CFFFFFF));
        Util.rrect(ms, x, PY, x + PW, PY + h, 7, a(0xCC111115));

        // заголовок
        if (p < THEME_P) {
            txt(ms, CATS[p].label.toUpperCase(), x + 8, PY + 5, a(0xFFE8E8F0), 0.8f);
            int cx = x + PW - 15, cy = PY + 4;
            Util.rrect(ms, cx, cy, cx + 9, cy + 9, 3, a(COLLAPSED[p] ? 0x50FFFFFF : 0xCCFFFFFF));
            if (COLLAPSED[p]) Util.rrect(ms, cx + 1, cy + 1, cx + 8, cy + 8, 2, a(0xFF121216));
        } else {
            String[] tabs = {"Theme", "Configs"};
            int tx = x + 4;
            for (int t = 0; t < 2; t++) {
                int tw = (int) sw(tabs[t], 0.75f) + 10;
                Util.rrect(ms, tx, PY + 3, tx + tw, PY + 14, 5,
                        a(themeTab == t ? Util.withAlpha(acc, 0xDD) : 0x28FFFFFF));
                txt(ms, tabs[t], tx + 5, PY + 6, a(0xFFFFFFFF), 0.75f);
                tx += tw + 3;
            }
        }
        if (COLLAPSED[p]) return;
        fill(ms, x + 5, PY + HEADH - 1, x + PW - 5, PY + HEADH, a(0x14FFFFFF));

        scissorOn(x, PY + HEADH, PW, h - HEADH);
        int top = PY + HEADH, bottom = PY + h;
        if (p == THEME_P) {
            for (int i = 0; i < themeCount(); i++) {
                int y = rowTop(p, i);
                if (y + ROW < top || y > bottom) continue;
                drawThemeRow(ms, i, x, y, mx, my, top, bottom);
            }
        } else {
            List<Module> list = rows(p);
            for (int i = 0; i < list.size(); i++) {
                Module m = list.get(i);
                int y = rowTop(p, i), rh = rowH(m);
                if (y + rh < top || y > bottom) continue;
                drawRow(ms, m, x, y, rh, i, mx, my, top, bottom);
            }
            if (list.isEmpty()) txt(ms, "—", x + 10, top + 6, a(0xFF5E5E72), 0.8f);
        }
        scissorOff();

        // полоса прокрутки
        int ms2 = maxScroll(p);
        if (ms2 > 0) {
            int trackY = top + 2, trackH = h - HEADH - 6;
            int th = Math.max(8, trackH * (h - HEADH) / contentH(p));
            int ty = trackY + (trackH - th) * SCROLL[p] / ms2;
            Util.rrect(ms, x + PW - 3, ty, x + PW - 1, ty + th, 1, a(Util.withAlpha(acc, 0x99)));
        }
    }

    private void drawRow(MatrixStack ms, Module m, int x, int y, int rh, int idx, int mx, int my, int top, int bottom) {
        boolean hov = sliderDrag == null && mx >= x && mx < x + PW && my >= y && my < y + rh && my >= top && my < bottom;
        int acc = Util.accent(idx * 0.12f);
        boolean on = m.isToggle() && m.enabled;
        m.anim += ((m.enabled ? 1f : 0f) - m.anim) * 0.25f;

        if (on) {
            Util.rrect(ms, x + 3, y, x + PW - 3, y + rh, 3, a(Util.withAlpha(acc, 0x26)));
            fill(ms, x + 3, y + 2, x + 5, y + rh - 2, a(acc));
        } else if (hov) {
            Util.rrect(ms, x + 3, y, x + PW - 3, y + rh, 3, a(0x18FFFFFF));
        }

        // иконка бинда
        int ix = x + 8, iy = y + 3;
        if (!m.isAction() && !m.isSlider()) {
            boolean bnd = binding == m;
            Util.rrect(ms, ix, iy, ix + 9, iy + 9, 4, a(bnd ? Util.withAlpha(acc, 0xAA) : 0x30FFFFFF));
            if (bnd) {
                txt(ms, "..", ix + 2, iy + 2, a(0xFFFFFFFF), 0.7f);
            } else if (m.key >= 0) {
                String kn = keyName(m.key);
                txt(ms, kn, ix + 4.5f - sw(kn, 0.65f) / 2f, iy + 2.5f, a(0xFFFFFFFF), 0.65f);
            } else {
                fill(ms, ix + 2, iy + 4, ix + 7, iy + 5, a(0xFF8E8EA6));
                fill(ms, ix + 4, iy + 2, ix + 5, iy + 7, a(0xFF8E8EA6));
            }
        } else {
            Util.rrect(ms, ix + 3, iy + 3, ix + 6, iy + 6, 1, a(0x40FFFFFF));
        }

        String right = null;
        if (m.isSlider()) right = m.valueText();
        else if (m.isAction()) right = "Open";
        else if (!m.isToggle()) right = m.modes[m.mode];
        float rw = right == null ? 0 : sw(right, 0.75f);

        int avail = (int) (PW - 20 - 8 - (right != null ? rw + 6 : 18));
        txt(ms, font.plainSubstrByWidth(m.name, (int) (avail / NS)), x + 20, y + 4,
                a(on ? 0xFFFFFFFF : 0xFFB4B4C0), NS);

        if (m.isToggle()) {
            int cx = x + PW - 15, cy = y + 3;
            Util.rrect(ms, cx, cy, cx + 9, cy + 9, 3, a(on ? acc : 0x50FFFFFF));
            if (on) Util.rrect(ms, cx + 3, cy + 3, cx + 6, cy + 6, 1, a(0xFFFFFFFF));
            else Util.rrect(ms, cx + 1, cy + 1, cx + 8, cy + 8, 2, a(0xFF121216));
        } else {
            txt(ms, right, x + PW - 8 - rw, y + 5, a(acc), 0.75f);
        }

        if (m.isSlider()) {
            int ty = y + 16, tw = PW - 16;
            Util.rrect(ms, x + 8, ty, x + 8 + tw, ty + 3, 1, a(0x30FFFFFF));
            int fw = Math.max(3, (int) (tw * m.fraction()));
            Util.rrect(ms, x + 8, ty, x + 8 + fw, ty + 3, 1, a(acc));
            Util.rrect(ms, x + 8 + fw - 3, ty - 1, x + 8 + fw + 3, ty + 4, 2, a(0xFFFFFFFF));
        }
    }

    private void drawThemeRow(MatrixStack ms, int i, int x, int y, int mx, int my, int top, int bottom) {
        boolean hov = mx >= x && mx < x + PW && my >= y && my < y + ROW && my >= top && my < bottom;
        if (hov) Util.rrect(ms, x + 3, y, x + PW - 3, y + ROW, 3, a(0x18FFFFFF));

        if (themeTab == 0) {
            boolean sel = Modules.THEME.mode == i;
            Util.rrect(ms, x + 8, y + 4, x + 15, y + 11, 3, a(0x66FFFFFF));
            if (sel) Util.rrect(ms, x + 10, y + 6, x + 13, y + 9, 1, a(0xFFFFFFFF));
            else Util.rrect(ms, x + 9, y + 5, x + 14, y + 10, 2, a(0xFF111115));
            txt(ms, Modules.THEME.modes[i], x + 20, y + 4, a(sel ? 0xFFFFFFFF : 0xFFB4B4C0), NS);
            Util.rrect(ms, x + PW - 20, y + 4, x + PW - 8, y + 11, 2, a(0xFF000000 | Util.themeColor(i)));
        } else {
            txt(ms, CFG_ROWS[i], x + 10, y + 4, a(0xFFB4B4C0), NS);
            float bw = sw(CFG_BTN[i], 0.75f);
            Util.rrect(ms, x + PW - 14 - bw, y + 3, x + PW - 6, y + 12, 4, a(Util.withAlpha(Util.accent(0.2f), 0x44)));
            txt(ms, CFG_BTN[i], x + PW - 10 - bw, y + 5, a(0xFFE6E6F0), 0.75f);
        }
    }

    // ---------------------------------------------------------------- input
    @Override
    public boolean keyPressed(int key, int scan, int mods) {
        if (binding != null) {
            binding.key = (key == GLFW.GLFW_KEY_ESCAPE || key == GLFW.GLFW_KEY_BACKSPACE) ? -1 : key;
            binding = null;
            return true;
        }
        return super.keyPressed(key, scan, mods);
    }

    private void setSlider(Module m, double mx, int panelX) {
        m.setFraction((mx - (panelX + 8)) / (double) (PW - 16));
    }

    @Override
    public boolean mouseClicked(double mx, double my, int button) {
        if (super.mouseClicked(mx, my, button)) return true;
        if (button != 0 && button != 1) return false;
        binding = null;
        pressKind = 0;
        pressed = null;
        moved = false;
        axis = 0;
        accX = 0;
        accY = 0;
        pressX = mx;
        pressY = my;

        int[] h = find(mx, my);
        if (h == null) { pressKind = 7; pressPanel = -1; return true; }
        pressPanel = h[0];
        pressIdx = h[1];

        if (h[2] == 4 || h[2] == 5) {
            themeTab = h[2] - 4;
            SCROLL[THEME_P] = 0;
            clickSound();
            return true;
        }
        if (h[2] == 3) { pressKind = 3; return true; }
        if (h[2] == 0) { pressKind = 7; return true; }

        if (h[0] == THEME_P) { pressKind = themeTab == 0 ? 5 : 6; return true; }

        Module m = rows(h[0]).get(h[1]);
        if (button == 1) {
            if (!m.isAction() && !m.isSlider()) binding = m;
            clickSound();
            return true;
        }
        if (h[2] == 6) {
            sliderDrag = m;
            sliderPanel = h[0];
            setSlider(m, mx, px(h[0]));
            return true;
        }
        pressed = m;
        pressKind = h[2] == 2 ? 2 : 1;
        return true;
    }

    @Override
    public boolean mouseDragged(double mx, double my, int button, double dx, double dy) {
        if (sliderDrag != null) {
            setSlider(sliderDrag, mx, px(sliderPanel));
            return true;
        }
        if (pressKind != 0) {
            if (!moved && (Math.abs(my - pressY) > 4 || Math.abs(mx - pressX) > 4)) {
                moved = true;
                axis = Math.abs(my - pressY) > Math.abs(mx - pressX) ? 1 : 2;
            }
            if (moved) {
                if (axis == 1 && pressPanel >= 0 && !COLLAPSED[pressPanel]) {
                    accY += dy;
                    int d = (int) accY;
                    if (d != 0) {
                        SCROLL[pressPanel] = clamp(SCROLL[pressPanel] - d, 0, maxScroll(pressPanel));
                        accY -= d;
                    }
                } else if (axis == 2) {
                    accX += dx;
                    int d = (int) accX;
                    if (d != 0) {
                        hscroll = clamp(hscroll - d, 0, maxHScroll());
                        accX -= d;
                    }
                }
            }
            return true;
        }
        return super.mouseDragged(mx, my, button, dx, dy);
    }

    @Override
    public boolean mouseReleased(double mx, double my, int button) {
        if (sliderDrag != null) {
            sliderDrag = null;
            return true;
        }
        if (pressKind != 0) {
            if (!moved) act();
            pressKind = 0;
            pressed = null;
            moved = false;
            return true;
        }
        return super.mouseReleased(mx, my, button);
    }

    private void act() {
        switch (pressKind) {
            case 1:
                if (pressed != null) {
                    pressed.click();
                    if (pressed == Modules.HITSNDSEL) SoundFx.play(pressed.mode, 0.75f, 1.0f);
                    clickSound();
                }
                break;
            case 2:
                binding = pressed;
                clickSound();
                break;
            case 3:
                if (pressPanel >= 0) COLLAPSED[pressPanel] = !COLLAPSED[pressPanel];
                clickSound();
                break;
            case 5:
                Modules.THEME.mode = pressIdx;
                clickSound();
                break;
            case 6:
                clickSound();
                if (pressIdx == 0) minecraft.setScreen(new HudEditor());
                else if (pressIdx == 1) Hud.reset();
                else Config.save();
                break;
            default:
                break;
        }
    }

    @Override
    public boolean mouseScrolled(double mx, double my, double delta) {
        int[] h = find(mx, my);
        if (h != null && !COLLAPSED[h[0]]) {
            SCROLL[h[0]] = clamp(SCROLL[h[0]] - (int) (Math.signum(delta) * 18), 0, maxScroll(h[0]));
        } else {
            hscroll = clamp(hscroll - (int) (Math.signum(delta) * 40), 0, maxHScroll());
        }
        return true;
    }

    @Override
    public boolean isPauseScreen() { return false; }
}
