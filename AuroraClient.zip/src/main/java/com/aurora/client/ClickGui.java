package com.aurora.client;

import com.mojang.blaze3d.matrix.MatrixStack;
import net.minecraft.client.audio.SimpleSound;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.widget.TextFieldWidget;
import net.minecraft.client.util.InputMappings;
import net.minecraft.util.SoundEvents;
import net.minecraft.util.text.StringTextComponent;
import org.lwjgl.glfw.GLFW;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class ClickGui extends Screen {
    private static Category current = Category.COMBAT;
    private static String lastSearch = "";
    private final long openTime = System.currentTimeMillis();
    private TextFieldWidget search;
    private Module binding, selected;
    private float fade;
    private int moduleScroll, settingsScroll;
    private int X,Y,W,H,SIDE,SETTINGS;

    public ClickGui(){super(new StringTextComponent("Aurora Client 1.9"));}

    @Override protected void init(){
        W=Math.min(760,width-14); H=Math.min(420,height-14);
        X=(width-W)/2; Y=(height-H)/2;
        SIDE=Math.max(124,Math.min(150,W/5)); SETTINGS=Math.max(210,Math.min(250,W/3));
        int sx=X+W-SETTINGS-18-132, sy=Y+12;
        search=new TextFieldWidget(font,sx+8,sy+5,116,14,StringTextComponent.EMPTY);
        search.setBordered(false); search.setMaxLength(28); search.setValue(lastSearch);
        search.setResponder(s->{lastSearch=s;moduleScroll=0;}); addButton(search);
    }
    @Override public void removed(){Config.save();}
    private int al(int c){int a=(int)(((c>>>24)&255)*fade);return(a<<24)|(c&0xFFFFFF);}
    private void t(MatrixStack m,String s,float x,float y,int c){font.drawShadow(m,s,x,y,al(c));}
    private void sm(MatrixStack m,String s,float x,float y,int c){m.pushPose();m.scale(.78f,.78f,1);font.drawShadow(m,s,x/.78f,y/.78f,al(c));m.popPose();}
    private String keyName(int k){if(k<0)return"-";try{String s=InputMappings.getKey(k,0).getDisplayName().getString();return s.length()>9?s.substring(0,9):s;}catch(Exception e){return"?";}}
    private boolean child(Module m){
        return m==Modules.AURARANGE||m==Modules.AURAROTATION||m==Modules.AURATARGETS||m==Modules.AURAPRIORITY||
        m==Modules.AURADELAY||m==Modules.AURAFOV||m==Modules.AURAMODE||m==Modules.AURAWALLS||m==Modules.AURAWEAPON||
        m==Modules.AIMSPEED||m==Modules.CLICKCPS||m==Modules.VELOCITYAMT||m==Modules.TOTEMHP||m==Modules.CROSSSTYLE||
        m==Modules.PSTYLE||m==Modules.PCOLOR||m==Modules.PDENSITY||m==Modules.HITSNDSEL||m==Modules.SNDVOL||
        m==Modules.HATSTYLE||m==Modules.TRAILSTYLE||m==Modules.TARGETSTYLE||m==Modules.COSCOLOR;
    }
    private int count(Category c){int n=0;for(Module m:Modules.ALL)if(m.cat==c&&!child(m))n++;return n;}
    private String q(){return search==null?"":search.getValue().trim().toLowerCase();}
    private List<Module> visible(){List<Module>o=new ArrayList<>();for(Module m:Modules.ALL)if(!child(m)&&(q().isEmpty()?m.cat==current:m.name.toLowerCase().contains(q())))o.add(m);return o;}
    private int cx(){return X+SIDE+12;} private int cr(){return X+W-SETTINGS-12;}
    private int cw(){return Math.max(110,(cr()-cx()-8)/2);} private int cardX(int i){return cx()+(i%2)*(cw()+8);}
    private int cardY(int i){return Y+58+(i/2-moduleScroll)*54;} private int rows(){return Math.max(1,(H-76)/54);}
    private boolean shown(int i){int r=i/2-moduleScroll;return r>=0&&r<rows();}
    private int maxScroll(int n){return Math.max(0,(n+1)/2-rows());}
    private int sx(){return X+W-SETTINGS+15;} private int sr(){return X+W-7;}
    private void click(){if(minecraft!=null)minecraft.getSoundManager().play(SimpleSound.forUI(SoundEvents.UI_BUTTON_CLICK,1));}

    @Override public void render(MatrixStack m,int mx,int my,float pt){
        float tt=Math.min(1f,(System.currentTimeMillis()-openTime)/220f);fade=.15f+.85f*tt;
        fill(m,0,0,width,height,al(0xC9000008));
        int g=Util.accent(0),g2=Util.accent(1.8f);
        for(int i=0;i<8;i++){int yy=(int)((System.currentTimeMillis()/24L+i*83)%Math.max(1,height));fill(m,0,yy,width,yy+1,al(Util.withAlpha(i%2==0?g:g2,0x20)));}
        m.pushPose();m.translate(width/2f,height/2f,0);m.scale(.96f+.04f*tt,.96f+.04f*tt,1);m.translate(-width/2f,-height/2f,0);
        Util.rrect(m,X-2,Y-2,X+W+2,Y+H+2,14,al(Util.withAlpha(g,0x90)));
        Util.rrect(m,X,Y,X+W,Y+H,12,al(0xF20A0A14));
        Util.rrect(m,X+7,Y+7,X+SIDE,Y+H-7,10,al(0xB0101020));
        Util.rrect(m,cx()-5,Y+7,cr()+5,Y+H-7,10,al(0x95101020));
        Util.rrect(m,X+W-SETTINGS+5,Y+7,X+W-7,Y+H-7,10,al(0xA0141028));

        Util.rrect(m,X+16,Y+14,X+32,Y+30,5,al(Util.withAlpha(g,0xFF)));t(m,"A",X+20,Y+17,0xFFFFFFFF);
        Util.gradientText(m,font,"AURORA",X+39,Y+14,0);sm(m,"Client 1.9",X+39,Y+29,0xFF9D91B8);

        int ry=Y+48;
        for(Category c:Category.values()){
            boolean sel=c==current,hov=mx>=X+12&&mx<X+SIDE-5&&my>=ry&&my<ry+28;
            if(sel)Util.rrect(m,X+12,ry,X+SIDE-5,ry+28,7,al(Util.withAlpha(g,0xA0)));
            else if(hov)Util.rrect(m,X+12,ry,X+SIDE-5,ry+28,7,al(0x2AFFFFFF));
            t(m,c.label,X+25,ry+6,sel?0xFFFFFFFF:0xFFB6B1C4);
            sm(m,c.sub,X+25,ry+18,sel?0xFFE1D9FF:0xFF777284);
            sm(m,String.valueOf(count(c)),X+SIDE-22,ry+9,sel?g:0xFF666173);ry+=31;
        }
        int uy=Y+H-38;Util.rrect(m,X+12,uy,X+SIDE-5,uy+27,7,al(0x28FFFFFF));
        String nm=minecraft.getUser().getName(),ini=nm.isEmpty()?"?":nm.substring(0,1).toUpperCase();
        Util.rrect(m,X+17,uy+5,X+35,uy+23,6,al(Util.withAlpha(g,0xA0)));t(m,ini,X+22,uy+8,0xFFFFFFFF);
        sm(m,font.plainSubstrByWidth(nm,62),X+42,uy+5,0xFFFFFFFF);sm(m,"Premium Client",X+42,uy+16,g);

        t(m,q().isEmpty()?current.label:"Search",cx(),Y+15,0xFFFFFFFF);sm(m,q().isEmpty()?current.sub:"Результаты поиска",cx(),Y+30,0xFF8F899C);
        int qx=cr()-124;Util.rrect(m,qx,Y+12,cr(),Y+34,7,al(0x30FFFFFF));
        if(search.getValue().isEmpty()&&!search.isFocused())sm(m,"Поиск модулей...",qx+9,Y+19,0xFF777180);

        List<Module> list=visible();moduleScroll=Math.max(0,Math.min(maxScroll(list.size()),moduleScroll));
        for(int i=0;i<list.size();i++)if(shown(i))drawCard(m,list.get(i),i,mx,my);
        drawSettings(m,mx,my);
        if(binding!=null)sm(m,"Нажми клавишу • ESC = убрать",cx(),Y+H-14,g);
        m.popPose();super.render(m,mx,my,pt);
    }

    private void drawCard(MatrixStack m,Module mod,int i,int mx,int my){
        int x=cardX(i),y=cardY(i),w=cw(),h=45;boolean hov=mx>=x&&mx<x+w&&my>=y&&my<y+h,sel=mod==selected;int g=Util.accent(i*.17f);
        if(sel)Util.rrect(m,x-1,y-1,x+w+1,y+h+1,8,al(Util.withAlpha(g,0x90)));
        Util.rrect(m,x,y,x+w,y+h,8,al(hov?0xFF1D1A29:0xFF15141E));
        t(m,mod.name,x+10,y+8,0xFFFFFFFF);sm(m,mod.desc,x+10,y+23,0xFF8E879A);
        if(mod.isToggle()){Util.rrect(m,x+w-34,y+8,x+w-9,y+20,6,al(Util.mix(0x383442,g,mod.enabled?1:0)));Util.rrect(m,x+w-32+(mod.enabled?12:0),y+10,x+w-24+(mod.enabled?12:0),y+18,4,al(0xFFFFFFFF));}
        else sm(m,mod.isAction()?"OPEN":mod.modes[mod.mode],x+w-58,y+9,g);
        sm(m,"⚙",x+w-64,y+8,sel?g:0xFF666071);
        if(!mod.isAction()){Util.rrect(m,x+w-46,y+28,x+w-8,y+40,5,al(binding==mod?Util.withAlpha(g,0x90):0x24FFFFFF));sm(m,binding==mod?"...":keyName(mod.key),x+w-42,y+31,0xFFD5D0DF);}
    }

    private List<Module> settingsFor(Module m){
        if(m==null)return new ArrayList<>();
        List<Module>s=new ArrayList<>();s.add(m);
        if(m==Modules.KILLAURA)s.addAll(Arrays.asList(Modules.AURARANGE,Modules.AURAROTATION,Modules.AURATARGETS,Modules.AURAPRIORITY,Modules.AURADELAY,Modules.AURAFOV,Modules.AURAMODE,Modules.AURAWALLS,Modules.AURAWEAPON));
        else if(m==Modules.AIMASSIST)s.add(Modules.AIMSPEED);
        else if(m==Modules.AUTOCLICKER)s.add(Modules.CLICKCPS);
        else if(m==Modules.VELOCITY)s.add(Modules.VELOCITYAMT);
        else if(m==Modules.CROSSHAIR)s.add(Modules.CROSSSTYLE);
        else if(m==Modules.HITPART)s.addAll(Arrays.asList(Modules.PSTYLE,Modules.PCOLOR,Modules.PDENSITY));
        else if(m==Modules.HITSOUND)s.addAll(Arrays.asList(Modules.HITSNDSEL,Modules.SNDVOL));
        else if(m==Modules.CHINAHAT)s.add(Modules.HATSTYLE);
        else if(m==Modules.TRAILS)s.add(Modules.TRAILSTYLE);
        else if(m==Modules.TARGETESP)s.addAll(Arrays.asList(Modules.TARGETSTYLE,Modules.COSCOLOR));
        else if(m==Modules.THEME)s.add(Modules.ANIMATED);
        return s;
    }

    private void drawSettings(MatrixStack m,int mx,int my){
        int x=sx(),r=sr();t(m,selected==null?"Module Settings":selected.name,x,Y+16,0xFFFFFFFF);
        sm(m,selected==null?"Выбери модуль":"Настройки • "+selected.cat.label,x,Y+31,0xFF8F899C);
        Util.rrect(m,r-22,Y+12,r,Y+34,7,al(0x22FFFFFF));sm(m,"×",r-14,Y+17,0xFFE8E1EF);
        if(selected==null){Util.rrect(m,x,Y+55,r,Y+105,8,al(0x201FFFFFF));sm(m,"Нажми ⚙ на модуле",x+12,Y+67,Util.accent(0));sm(m,"чтобы открыть его",x+12,Y+81,0xFF9B94A7);return;}
        List<Module>ss=settingsFor(selected);int rh=43,start=Y+48-settingsScroll*rh;
        for(int i=0;i<ss.size();i++){int yy=start+i*rh;if(yy>=Y+42&&yy<=Y+H-42)drawSetting(m,ss.get(i),x,yy,r-x,mx,my);}
        int max=Math.max(0,ss.size()-Math.max(1,(H-88)/rh));settingsScroll=Math.max(0,Math.min(max,settingsScroll));
        sm(m,"Клик = изменить • бинды внизу",x,Y+H-18,0xFF777180);
    }

    private void drawSetting(MatrixStack m,Module mod,int x,int y,int w,int mx,int my){
        boolean hov=mx>=x&&mx<x+w&&my>=y&&my<y+36;int g=Util.accent(y*.01f);
        Util.rrect(m,x,y,x+w,y+36,8,al(hov?0xFF201D2B:0xFF17151F));t(m,mod.name,x+10,y+7,0xFFFFFFFF);sm(m,mod.desc,x+10,y+21,0xFF837D8E);
        if(mod.isToggle()){Util.rrect(m,x+w-38,y+9,x+w-10,y+21,6,al(Util.mix(0x383442,g,mod.enabled?1:0)));Util.rrect(m,x+w-36+(mod.enabled?14:0),y+11,x+w-27+(mod.enabled?14:0),y+19,4,al(0xFFFFFFFF));}
        else if(mod.isAction())sm(m,"OPEN",x+w-43,y+11,g);
        else{String v=mod.modes[mod.mode];Util.rrect(m,x+w-78,y+7,x+w-10,y+28,6,al(Util.withAlpha(g,0x42)));sm(m,v,x+w-70,y+12,g);}
    }

    @Override public boolean mouseClicked(double mx,double my,int b){
        if(super.mouseClicked(mx,my,b))return true;if(b!=0)return false;
        if(mx>=sr()-22&&mx<=sr()&&my>=Y+12&&my<=Y+34){minecraft.setScreen(null);return true;}binding=null;
        int ry=Y+48;for(Category c:Category.values()){if(mx>=X+12&&mx<X+SIDE-5&&my>=ry&&my<ry+28){current=c;moduleScroll=0;settingsScroll=0;search.setValue("");selected=null;click();return true;}ry+=31;}
        List<Module>list=visible();for(int i=0;i<list.size();i++){if(!shown(i))continue;Module mod=list.get(i);int x=cardX(i),y=cardY(i),w=cw();
            if(mx>=x&&mx<x+w&&my>=y&&my<y+45){if(!mod.isAction()&&mx>=x+w-46&&my>=y+27){binding=mod;return true;}if(mx>=x+w-70&&my<y+25){selected=mod;settingsScroll=0;click();return true;}mod.click();selected=mod;settingsScroll=0;click();return true;}}
        if(selected!=null){int x=sx(),w=sr()-x;List<Module>ss=settingsFor(selected);int rh=43,start=Y+48-settingsScroll*rh;for(int i=0;i<ss.size();i++){int yy=start+i*rh;if(mx>=x&&mx<x+w&&my>=yy&&my<yy+36){ss.get(i).click();click();return true;}}}
        return false;
    }
    @Override public boolean keyPressed(int key,int scan,int mods){if(binding!=null){binding.key=(key==GLFW.GLFW_KEY_ESCAPE||key==GLFW.GLFW_KEY_BACKSPACE)?-1:key;binding=null;Config.save();return true;}if(key==GLFW.GLFW_KEY_ESCAPE){minecraft.setScreen(null);return true;}return super.keyPressed(key,scan,mods);}
    @Override public boolean mouseScrolled(double mx,double my,double d){if(mx>=X+W-SETTINGS&&selected!=null){List<Module>ss=settingsFor(selected);int max=Math.max(0,ss.size()-Math.max(1,(H-88)/43));settingsScroll=Math.max(0,Math.min(max,settingsScroll-(int)Math.signum(d)));}else moduleScroll=Math.max(0,Math.min(maxScroll(visible().size()),moduleScroll-(int)Math.signum(d)));return true;}
    @Override public boolean isPauseScreen(){return false;}
}
