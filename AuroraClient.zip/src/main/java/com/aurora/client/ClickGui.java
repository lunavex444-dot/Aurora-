package com.aurora.client;

import com.mojang.blaze3d.matrix.MatrixStack;
import net.minecraft.client.audio.SimpleSound;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.widget.TextFieldWidget;
import net.minecraft.client.util.InputMappings;
import net.minecraft.util.SoundEvents;
import net.minecraft.util.text.StringTextComponent;
import org.lwjgl.glfw.GLFW;

import java.util.ArrayList;
import java.util.List;

/**
 * AuroraClient GUI 2: одна широкая панель, сверху вкладки-иконки (активная раскрывается),
 * карточки в две колонки с переключателями, режимами и ползунками.
 * Удобно с телефона: действие по отпусканию, листание перетаскиванием, плашка бинда.
 */
public class ClickGui extends Screen {
    private static final int PAD = 12, HEAD = 32, TABH = 24, ROWH = 38, CARDH = 34, FOOT = 16;

    private static Category current = Category.COMBAT;
    private static String lastSearch = "";

    private final long openTime = System.currentTimeMillis();
    private TextFieldWidget search;
    private Module binding;
    private float fade = 0.1f;
    private int scroll = 0;
    private int W, H, X, Y;

    // состояние нажатия
    private Module sliderDrag, pressed;
    private int pressKind;            // 0 нет, 1 карточка, 2 плашка бинда, 3 пустое место
    private double pressY, dragAcc;
    private boolean moved;

    public ClickGui() {
        super(new StringTextComponent("AuroraClient"));
    }

    @Override
    protected void init() {
        W = Math.min(396, width - 8);
        H = Math.max(120, Math.min(236, height - 8));
        X = (width - W) / 2;
        Y = (height - H) / 2;
        int sx = X + W - PAD - 110, sy = Y + 7;
        search = new TextFieldWidget(font, sx + 8, sy + 5, 94, 10, StringTextComponent.EMPTY);
        search.setBordered(false);
        search.setMaxLength(20);
        search.setValue(lastSearch);
        search.setResponder(s -> { lastSearch = s; scroll = 0; });
        addButton(search);
    }

    @Override
    public void removed() {
        Config.save();
    }

    // ---------------------------------------------------------------- helpers
    private int a(int c) {
        int al = (int) (((c >>> 24) & 255) * fade);
        return (al << 24) | (c & 0xFFFFFF);
    }

    private void small(MatrixStack ms, String s, float x, float y, int color) {
        ms.pushPose();
        ms.scale(0.75f, 0.75f, 1f);
        font.drawShadow(ms, s, x / 0.75f, y / 0.75f, color);
        ms.popPose();
    }

    private float smallW(String s) { return font.width(s) * 0.75f; }

    private String keyName(int key) {
        if (key < 0) return "+";
        try {
            String s = InputMappings.getKey(key, 0).getDisplayName().getString();
            return s.length() > 6 ? s.substring(0, 6) : s;
        } catch (Exception e) {
            return "?";
        }
    }

    private String query() {
        return search == null ? "" : search.getValue().trim().toLowerCase();
    }

    private List<Module> visible() {
        List<Module> out = new ArrayList<>();
        String q = query();
        for (Module m : Modules.ALL) {
            if (q.isEmpty() ? m.cat == current : m.name.toLowerCase().contains(q)) out.add(m);
        }
        return out;
    }

    private void clickSound() {
        minecraft.getSoundManager().play(SimpleSound.forUI(SoundEvents.UI_BUTTON_CLICK, 1.0F));
    }

    // ---------------------------------------------------------------- layout
    private int contentTop() { return Y + HEAD + TABH + 6; }
    private int contentX() { return X + PAD; }
    private int cardW() { return (W - 2 * PAD - 8) / 2; }
    private int cardX(int i) { return contentX() + (i % 2) * (cardW() + 8); }
    private int cardY(int i) { return contentTop() + (i / 2 - scroll) * ROWH; }
    private int rowsVisible() { return Math.max(1, (H - HEAD - TABH - 6 - FOOT) / ROWH); }
    private boolean shown(int i) { int r = i / 2 - scroll; return r >= 0 && r < rowsVisible(); }
    private int maxScroll(int total) { return Math.max(0, (total + 1) / 2 - rowsVisible()); }

    private int tabW(Category c) { return c == current && query().isEmpty() ? 22 + font.width(c.label) + 8 : 22; }

    private int tabX(int idx) {
        int x = X + PAD;
        Category[] cats = Category.values();
        for (int j = 0; j < idx; j++) x += tabW(cats[j]) + 4;
        return x;
    }

    private int tabY() { return Y + HEAD + 2; }

    /** Правая граница свободного места слева от элемента управления. */
    private int afterControl(Module m, int x, int w) {
        int right = x + w - 9;
        if (m.isToggle()) return right - 24 - 5;
        if (m.isSlider()) return (int) (right - smallW(m.valueText()) - 13);
        String txt = m.isAction() ? "Open" : m.modes[m.mode];
        return (int) (right - smallW(txt) - 13);
    }

    private String bindText(Module m) { return binding == m ? "..." : keyName(m.key); }

    private boolean canBind(Module m) { return !m.isAction() && !m.isSlider(); }

    private boolean inBindPill(Module m, int x, int y, int w, double mx, double my) {
        if (!canBind(m)) return false;
        int right = afterControl(m, x, w);
        float bw = smallW(bindText(m));
        return mx >= right - bw - 8 && mx < right + 2 && my >= y + 4 && my < y + 20;
    }

    // ---------------------------------------------------------------- render
    @Override
    public void render(MatrixStack ms, int mx, int my, float pt) {
        float t = Math.min(1f, (System.currentTimeMillis() - openTime) / 180f);
        fade = 0.1f + 0.9f * t;
        float sc = 0.94f + 0.06f * t;

        fill(ms, 0, 0, width, height, a(0x99050509));
        fillGradient(ms, 0, 0, width, (int) (height * 0.6f), a(Util.withAlpha(Util.accent(0.2f), 0x40)), 0x00000000);

        ms.pushPose();
        ms.translate(width / 2f, height / 2f, 0);
        ms.scale(sc, sc, 1f);
        ms.translate(-width / 2f, -height / 2f, 0);

        drawPanel(ms, mx, my);

        super.render(ms, mx, my, pt);
        ms.popPose();
    }

    private void drawPanel(MatrixStack ms, int mx, int my) {
        Util.rrect(ms, X - 1, Y - 1, X + W + 1, Y + H + 1, 12, a(Util.withAlpha(Util.accent(0.1f), 0x50)));
        Util.rrect(ms, X, Y, X + W, Y + H, 11, a(0xF20B0B14));

        // бренд
        Util.logo(ms, X + PAD, Y + 8, 16);
        int w1 = Util.gradientText(ms, font, "Aurora", X + PAD + 22, Y + 12, 0f);
        font.drawShadow(ms, "Client", X + PAD + 22 + w1, Y + 12, a(0xFFFFFFFF));

        // поиск
        int sx = X + W - PAD - 110, sy = Y + 7;
        Util.rrect(ms, sx, sy, sx + 110, sy + 20, 7, a(0x28FFFFFF));
        if (search.getValue().isEmpty() && !search.isFocused())
            small(ms, "Поиск модулей...", sx + 9, sy + 7, a(0xFF77778A));

        // вкладки
        Category[] cats = Category.values();
        for (int i = 0; i < cats.length; i++) {
            int bx = tabX(i), by = tabY(), bw = tabW(cats[i]), bh = 20;
            boolean sel = cats[i] == current && query().isEmpty();
            boolean hov = mx >= bx && mx < bx + bw && my >= by && my < by + bh;
            if (sel) Util.rrect(ms, bx, by, bx + bw, by + bh, 8, a(Util.accent(i * 0.1f)));
            else if (hov) Util.rrect(ms, bx, by, bx + bw, by + bh, 8, a(0x2AFFFFFF));
            String[] bmp = Util.ICONS[i];
            Util.icon(ms, bmp, bx + (22 - 9) / 2, by + (bh - bmp.length) / 2, a(sel ? 0xFFFFFFFF : 0xFF8E8EA6));
            if (sel) font.drawShadow(ms, cats[i].label, bx + 22, by + 6, a(0xFFFFFFFF));
        }
        fill(ms, X + PAD, Y + HEAD + TABH + 2, X + W - PAD, Y + HEAD + TABH + 3, a(0x18FFFFFF));

        // карточки
        String q = query();
        List<Module> list = visible();
        scroll = Math.max(0, Math.min(maxScroll(list.size()), scroll));

        if (current == Category.CONFIGS && q.isEmpty()) {
            small(ms, "Настройки, бинды, ползунки и позиции HUD", X + PAD, contentTop() + 4, a(0xFFB0B0C4));
            small(ms, "сохраняются автоматически в файл", X + PAD, contentTop() + 16, a(0xFFB0B0C4));
            small(ms, "auroraclient.properties (папка игры)", X + PAD, contentTop() + 28, a(0xFF77778A));
        }
        if (list.isEmpty() && !q.isEmpty()) small(ms, "Ничего не найдено", X + PAD, contentTop() + 4, a(0xFF77778A));

        for (int i = 0; i < list.size(); i++) if (shown(i)) drawCard(ms, list.get(i), i, mx, my);

        // полоса прокрутки
        int total = (list.size() + 1) / 2, vis = rowsVisible();
        if (total > vis) {
            int trackY = contentTop(), trackH = vis * ROWH - 4, bx = X + W - 6;
            Util.rrect(ms, bx, trackY, bx + 2, trackY + trackH, 1, a(0x20FFFFFF));
            int th = Math.max(10, trackH * vis / total);
            int ty = trackY + (trackH - th) * scroll / Math.max(1, total - vis);
            Util.rrect(ms, bx, ty, bx + 2, ty + th, 1, a(Util.accent(0.3f)));
        }

        // подвал
        int fy = Y + H - 12;
        if (binding != null) small(ms, "Нажми клавишу для бинда (ESC — убрать)", X + PAD, fy, a(Util.accent(0.3f)));
        else small(ms, "Тап — вкл/выкл  ·  плашка справа — бинд  ·  тяни — листать", X + PAD, fy, a(0xFF5E5E72));
        String cnt = list.size() + " модулей";
        small(ms, cnt, X + W - PAD - smallW(cnt), fy, a(0xFF5E5E72));
    }

    private void drawCard(MatrixStack ms, Module m, int i, int mx, int my) {
        int x = cardX(i), y = cardY(i), w = cardW(), h = CARDH;
        boolean hov = mx >= x && mx < x + w && my >= y && my < y + h;
        int acc = Util.accent(i * 0.15f);
        m.anim += ((m.enabled ? 1f : 0f) - m.anim) * 0.25f;
        boolean on = m.isToggle() && m.enabled;

        if (on) Util.rrect(ms, x - 1, y - 1, x + w + 1, y + h + 1, 8, a(Util.withAlpha(acc, 0x55)));
        Util.rrect(ms, x, y, x + w, y + h, 7, a(hov ? 0xFF1E1E2C : 0xFF151521));
        if (on) Util.rrect(ms, x, y, x + w, y + h, 7, a(Util.withAlpha(acc, 0x24)));

        int right = x + w - 9;
        if (m.isToggle()) {
            int sx = right - 24, sy = y + 6;
            Util.rrect(ms, sx, sy, sx + 24, sy + 12, 6, a(Util.mix(0x34344A, acc, m.anim)));
            int kx = sx + 2 + Math.round(12 * m.anim);
            Util.rrect(ms, kx, sy + 2, kx + 8, sy + 10, 4, a(0xFFFFFFFF));
        } else if (m.isSlider()) {
            String vt = m.valueText();
            float vw = smallW(vt);
            Util.rrect(ms, right - vw - 8, y + 5, right, y + 17, 5, a(Util.withAlpha(acc, 0x40)));
            small(ms, vt, right - vw - 4, y + 8, a(acc));
        } else {
            String txt = m.isAction() ? "Open" : m.modes[m.mode];
            float tw = smallW(txt);
            Util.rrect(ms, right - tw - 8, y + 5, right, y + 17, 5, a(Util.withAlpha(acc, 0x40)));
            small(ms, txt, right - tw - 4, y + 8, a(acc));
        }

        int left = afterControl(m, x, w);
        if (canBind(m)) {
            String bt = bindText(m);
            float bw = smallW(bt);
            boolean active = binding == m;
            Util.rrect(ms, left - bw - 6, y + 6, left, y + 16, 4, a(active ? Util.withAlpha(acc, 0x70) : 0x26FFFFFF));
            small(ms, bt, left - bw - 3, y + 8, a(m.key < 0 && !active ? 0xFF6E6E82 : 0xFFC4C4D4));
            left = (int) (left - bw - 10);
        }

        font.drawShadow(ms, font.plainSubstrByWidth(m.name, Math.max(10, left - (x + 10))), x + 10, y + 6, a(0xFFFFFFFF));

        if (m.isSlider()) {
            small(ms, font.plainSubstrByWidth(m.desc, (int) ((w - 20) / 0.75f)), x + 10, y + 17, a(0xFF77778A));
            int tx = x + 10, tw = w - 20, ty = y + 26;
            Util.rrect(ms, tx, ty, tx + tw, ty + 4, 2, a(0x30FFFFFF));
            int fw = Math.max(4, (int) (tw * m.fraction()));
            Util.rrect(ms, tx, ty, tx + fw, ty + 4, 2, a(acc));
            Util.rrect(ms, tx + fw - 4, ty - 2, tx + fw + 4, ty + 6, 4, a(0xFFFFFFFF));
        } else {
            small(ms, font.plainSubstrByWidth(m.desc, (int) ((w - 20) / 0.75f)), x + 10, y + 20, a(0xFF77778A));
        }
    }

    // ---------------------------------------------------------------- input
    @Override
    public boolean keyPressed(int key, int scan, int mods) {
        if (binding != null) {
            binding.key = (key == GLFW.GLFW_KEY_ESCAPE || key == GLFW.GLFW_KEY_BACKSPACE) ? -1 : key;
            binding = null;
            return true;
        }
        return super.keyPressed(key, scan, mods);
    }

    private int hitCard(double mx, double my, List<Module> list) {
        for (int i = 0; i < list.size(); i++) {
            if (!shown(i)) continue;
            int x = cardX(i), y = cardY(i);
            if (mx >= x && mx < x + cardW() && my >= y && my < y + CARDH) return i;
        }
        return -1;
    }

    private void setSlider(Module m, double mx, int cardX) {
        m.setFraction((mx - (cardX + 10)) / (double) (cardW() - 20));
    }

    @Override
    public boolean mouseClicked(double mx, double my, int button) {
        if (super.mouseClicked(mx, my, button)) return true;
        if (button != 0 && button != 1) return false;
        binding = null;

        // вкладки
        if (button == 0) {
            Category[] cats = Category.values();
            for (int i = 0; i < cats.length; i++) {
                int bx = tabX(i), by = tabY(), bw = tabW(cats[i]);
                if (mx >= bx && mx < bx + bw && my >= by && my < by + 20) {
                    current = cats[i];
                    scroll = 0;
                    search.setValue("");
                    clickSound();
                    return true;
                }
            }
        }

        List<Module> list = visible();
        int idx = hitCard(mx, my, list);
        if (idx >= 0) {
            Module m = list.get(idx);
            int x = cardX(idx), y = cardY(idx);
            if (button == 1) {
                if (canBind(m)) binding = m;
                clickSound();
                return true;
            }
            if (m.isSlider() && my >= y + 20) {
                sliderDrag = m;
                setSlider(m, mx, x);
                return true;
            }
            pressed = m;
            pressKind = inBindPill(m, x, y, cardW(), mx, my) ? 2 : 1;
            pressY = my;
            dragAcc = 0;
            moved = false;
            return true;
        }

        if (mx >= X && mx < X + W && my >= contentTop() && my < Y + H - FOOT) {
            pressed = null;
            pressKind = 3;
            pressY = my;
            dragAcc = 0;
            moved = false;
            return true;
        }
        return false;
    }

    @Override
    public boolean mouseDragged(double mx, double my, int button, double dx, double dy) {
        if (sliderDrag != null) {
            List<Module> list = visible();
            int idx = list.indexOf(sliderDrag);
            if (idx >= 0) setSlider(sliderDrag, mx, cardX(idx));
            return true;
        }
        if (pressKind != 0) {
            if (Math.abs(my - pressY) > 4) moved = true;
            if (moved) {
                dragAcc += dy;
                while (dragAcc > ROWH) { scroll--; dragAcc -= ROWH; }
                while (dragAcc < -ROWH) { scroll++; dragAcc += ROWH; }
                scroll = Math.max(0, Math.min(maxScroll(visible().size()), scroll));
            }
            return true;
        }
        return super.mouseDragged(mx, my, button, dx, dy);
    }

    @Override
    public boolean mouseReleased(double mx, double my, int button) {
        if (sliderDrag != null) {
            sliderDrag = null;
            return true;
        }
        if (pressKind != 0) {
            if (!moved && pressed != null) {
                if (pressKind == 2) {
                    binding = pressed;
                    clickSound();
                } else if (pressKind == 1) {
                    pressed.click();
                    if (pressed == Modules.HITSNDSEL) SoundFx.play(pressed.mode, 0.75f, 1.0f);
                    clickSound();
                }
            }
            pressed = null;
            pressKind = 0;
            moved = false;
            return true;
        }
        return super.mouseReleased(mx, my, button);
    }

    @Override
    public boolean mouseScrolled(double mx, double my, double delta) {
        int max = maxScroll(visible().size());
        scroll = Math.max(0, Math.min(max, scroll - (int) Math.signum(delta)));
        return true;
    }

    @Override
    public boolean isPauseScreen() { return false; }
}
