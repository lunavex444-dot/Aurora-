package com.aurora.client;

import com.mojang.blaze3d.matrix.MatrixStack;
import net.minecraft.client.audio.SimpleSound;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.widget.TextFieldWidget;
import net.minecraft.util.SoundEvents;
import net.minecraft.util.text.StringTextComponent;

import java.util.ArrayList;
import java.util.List;

public class ClickGui extends Screen {
    private static final int SIDE = 104;
    private static Category current = Category.HUD;
    private static String lastSearch = "";

    private final long openTime = System.currentTimeMillis();
    private TextFieldWidget search;
    private float fade = 0.1f;
    private int W, H, X, Y;

    public ClickGui() {
        super(new StringTextComponent("Aurora"));
    }

    @Override
    protected void init() {
        W = Math.min(400, width - 12);
        H = Math.min(232, height - 12);
        X = (width - W) / 2;
        Y = (height - H) / 2;
        int sx = X + W - 12 - 112, sy = Y + 12;
        search = new TextFieldWidget(font, sx + 8, sy + 5, 98, 12, StringTextComponent.EMPTY);
        search.setBordered(false);
        search.setMaxLength(20);
        search.setValue(lastSearch);
        search.setResponder(s -> lastSearch = s);
        addButton(search);
    }

    @Override
    public void removed() {
        Config.save();
    }

    private int a(int c) {
        int al = (int) (((c >>> 24) & 255) * fade);
        return (al << 24) | (c & 0xFFFFFF);
    }

    private void small(MatrixStack ms, String s, float x, float y, int color) {
        ms.pushPose();
        ms.scale(0.75f, 0.75f, 1f);
        font.drawShadow(ms, s, x / 0.75f, y / 0.75f, color);
        ms.popPose();
    }

    private int count(Category c) {
        int n = 0;
        for (Module m : Modules.ALL) if (m.cat == c) n++;
        return n;
    }

    private String query() {
        return search == null ? "" : search.getValue().trim().toLowerCase();
    }

    private List<Module> visible() {
        List<Module> out = new ArrayList<>();
        String q = query();
        for (Module m : Modules.ALL) {
            if (q.isEmpty() ? m.cat == current : m.name.toLowerCase().contains(q)) out.add(m);
        }
        return out;
    }

    private int contentX() { return X + SIDE + 12; }
    private int contentR() { return X + W - 12; }
    private int cardW() { return (contentR() - contentX() - 8) / 2; }
    private int cardX(int i) { return contentX() + (i % 2) * (cardW() + 8); }
    private int cardY(int i) { return Y + 44 + (i / 2) * 40; }

    private void clickSound() {
        minecraft.getSoundManager().play(SimpleSound.forUI(SoundEvents.UI_BUTTON_CLICK, 1.0F));
    }

    @Override
    public void render(MatrixStack ms, int mx, int my, float pt) {
        fade = 0.1f + 0.9f * Math.min(1f, (System.currentTimeMillis() - openTime) / 180f);
        fill(ms, 0, 0, width, height, a(0x77000000));

        // panel
        Util.rrect(ms, X - 1, Y - 1, X + W + 1, Y + H + 1, 11, a(0x30FFFFFF));
        Util.rrect(ms, X, Y, X + W, Y + H, 10, a(0xE8101018));
        Util.rrect(ms, X + 6, Y + 6, X + SIDE, Y + H - 6, 8, a(0x50000000));

        // logo
        Util.rrect(ms, X + 14, Y + 14, X + 28, Y + 28, 4, Util.accent(0f));
        font.drawShadow(ms, "A", X + 14 + (14 - font.width("A")) / 2f, Y + 17, 0xFFFFFFFF);
        Util.gradientText(ms, font, "Aurora", X + 34, Y + 17, 0f);

        // categories
        int ry = Y + 40;
        for (Category c : Category.values()) {
            boolean sel = c == current;
            boolean hov = mx >= X + 10 && mx < X + SIDE - 4 && my >= ry && my < ry + 20;
            if (sel) Util.rrect(ms, X + 10, ry, X + SIDE - 4, ry + 20, 6, a(Util.withAlpha(Util.accent(0.2f), 0x55)));
            else if (hov) Util.rrect(ms, X + 10, ry, X + SIDE - 4, ry + 20, 6, a(0x22FFFFFF));
            font.drawShadow(ms, c.label, X + 19, ry + 6, a(sel ? 0xFFFFFFFF : 0xFF9A9AAE));
            String cnt = String.valueOf(count(c));
            small(ms, cnt, X + SIDE - 14 - font.width(cnt) * 0.75f, ry + 7, a(0xFF6E6E82));
            ry += 24;
        }

        // user card
        int uy = Y + H - 38;
        Util.rrect(ms, X + 10, uy, X + SIDE - 4, uy + 28, 7, a(0x30FFFFFF));
        Util.rrect(ms, X + 15, uy + 6, X + 31, uy + 22, 5, Util.accent(0.5f));
        String nm = minecraft.getUser().getName();
        String initial = nm.isEmpty() ? "?" : nm.substring(0, 1).toUpperCase();
        font.drawShadow(ms, initial, X + 15 + (16 - font.width(initial)) / 2f, uy + 10, 0xFFFFFFFF);
        font.drawShadow(ms, font.plainSubstrByWidth(nm, 58), X + 36, uy + 6, a(0xFFFFFFFF));
        small(ms, "Aurora Client", X + 36, uy + 17, a(Util.accent(0.5f)));

        // header
        String q = query();
        int cx = contentX(), right = contentR();
        font.drawShadow(ms, q.isEmpty() ? current.label : "Поиск", cx, Y + 14, a(0xFFFFFFFF));
        small(ms, q.isEmpty() ? current.sub : "Результаты по всем разделам", cx, Y + 27, a(0xFF77778A));

        // search box
        int sx = right - 112, sy = Y + 12;
        Util.rrect(ms, sx, sy, right, sy + 20, 6, a(0x30FFFFFF));
        if (search.getValue().isEmpty() && !search.isFocused())
            small(ms, "Поиск модулей...", sx + 8, sy + 7, a(0xFF77778A));

        // cards
        if (current == Category.CONFIGS && q.isEmpty()) {
            small(ms, "Настройки сохраняются автоматически", cx, Y + 52, a(0xFFB0B0C4));
            small(ms, "Файл: auroraclient.properties в папке игры", cx, Y + 66, a(0xFF77778A));
        }
        List<Module> list = visible();
        for (int i = 0; i < list.size(); i++) {
            drawCard(ms, list.get(i), i, mx, my);
        }

        super.render(ms, mx, my, pt);
    }

    private void drawCard(MatrixStack ms, Module m, int i, int mx, int my) {
        int x = cardX(i), y = cardY(i), w = cardW(), h = 34;
        boolean hov = mx >= x && mx < x + w && my >= y && my < y + h;
        int acc = Util.accent(i * 0.15f);
        m.anim += ((m.enabled ? 1f : 0f) - m.anim) * 0.25f;
        boolean on = m.isToggle() && m.enabled;

        if (on) Util.rrect(ms, x - 1, y - 1, x + w + 1, y + h + 1, 8, a(Util.withAlpha(acc, 0x70)));
        Util.rrect(ms, x, y, x + w, y + h, 7, a(hov ? 0xFF22222E : 0xFF1A1A24));
        if (on) Util.rrect(ms, x, y, x + w, y + h, 7, a(Util.withAlpha(acc, 0x30)));

        font.drawShadow(ms, m.name, x + 9, y + 8, a(0xFFFFFFFF));
        small(ms, m.desc, x + 9, y + 21, a(0xFF8A8AA0));

        if (m.isToggle()) {
            int sx = x + w - 34, sy = y + 11;
            Util.rrect(ms, sx, sy, sx + 26, sy + 12, 6, a(Util.mix(0x3A3A48, acc, m.anim)));
            int kx = sx + 2 + Math.round(12 * m.anim);
            Util.rrect(ms, kx, sy + 2, kx + 8, sy + 10, 4, a(0xFFFFFFFF));
        } else {
            String txt = m.modes[m.mode];
            float tw = font.width(txt) * 0.75f;
            Util.rrect(ms, x + w - 14 - tw, y + 10, x + w - 6, y + 24, 5, a(Util.withAlpha(acc, 0x40)));
            small(ms, txt, x + w - 10 - tw, y + 14, a(acc));
        }
    }

    @Override
    public boolean mouseClicked(double mx, double my, int button) {
        if (super.mouseClicked(mx, my, button)) return true;
        if (button != 0) return false;

        int ry = Y + 40;
        for (Category c : Category.values()) {
            if (mx >= X + 10 && mx < X + SIDE - 4 && my >= ry && my < ry + 20) {
                current = c;
                search.setValue("");
                clickSound();
                return true;
            }
            ry += 24;
        }

        List<Module> list = visible();
        for (int i = 0; i < list.size(); i++) {
            int x = cardX(i), y = cardY(i);
            if (mx >= x && mx < x + cardW() && my >= y && my < y + 34) {
                list.get(i).click();
                clickSound();
                return true;
            }
        }
        return false;
    }

    @Override
    public boolean isPauseScreen() { return false; }
}
