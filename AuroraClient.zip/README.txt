Aurora Client (Forge 1.16.5)
1) Скачай Forge MDK 1.16.5 (36.2.x) с files.minecraftforge.net
2) Распакуй MDK, удали его папку src, скопируй вместо неё src из этого архива
3) В build.gradle MDK поставь: group = 'com.aurora.client', archivesBaseName = 'auroraclient'
4) Запусти: gradlew build  -> jar будет в build/libs, кидай в папку mods


AuroraClient 1.9 Main Menu
- Replaces the vanilla Minecraft 1.16.5 main menu with AuroraMainMenu.
- Lightweight animated Aurora background without shaders.
- Singleplayer, Multiplayer, Options and Quit Game buttons.
