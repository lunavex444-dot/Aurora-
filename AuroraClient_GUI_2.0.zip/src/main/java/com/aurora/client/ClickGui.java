package com.aurora.client;

import com.mojang.blaze3d.matrix.MatrixStack;
import net.minecraft.client.audio.SimpleSound;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.widget.TextFieldWidget;
import net.minecraft.client.util.InputMappings;
import net.minecraft.util.SoundEvents;
import net.minecraft.util.text.StringTextComponent;
import org.lwjgl.glfw.GLFW;

import java.util.ArrayList;
import java.util.List;

/**
 * Aurora ClickGUI 2.0 - three-panel glass/neon layout.
 * Designed to stay light on mobile Java/Forge 1.16.5.
 */
public class ClickGui extends Screen {
    private static final int SIDE = 142;
    private static final int SETTINGS = 260;
    private static Category current = Category.COMBAT;
    private static String lastSearch = "";
    private static Module selected;

    private final long openTime = System.currentTimeMillis();
    private TextFieldWidget search;
    private Module binding;
    private Module draggingSlider;
    private float fade = 0.1f;
    private float openScale = 0.96f;
    private int scroll = 0;
    private int W, H, X, Y;
    private boolean compact;

    public ClickGui() { super(new StringTextComponent("Aurora")); }

    @Override
    protected void init() {
        compact = width < 820;
        W = Math.min(compact ? 730 : 900, width - 12);
        H = Math.min(455, height - 12);
        X = (width - W) / 2;
        Y = (height - H) / 2;
        int sx = X + W - 194, sy = Y + 13;
        search = new TextFieldWidget(font, sx + 25, sy + 5, 164, 14, StringTextComponent.EMPTY);
        search.setBordered(false);
        search.setMaxLength(24);
        search.setValue(lastSearch);
        search.setResponder(s -> { lastSearch = s; scroll = 0; });
        addButton(search);
        if (selected == null || !Modules.ALL.contains(selected)) selected = Modules.ALL.get(0);
    }

    @Override public void removed() { Config.save(); }

    private int a(int c) {
        int al = Math.max(0, Math.min(255, (int)(((c >>> 24) & 255) * fade)));
        return (al << 24) | (c & 0xFFFFFF);
    }

    private void small(MatrixStack ms, String s, float x, float y, int color) {
        ms.pushPose(); ms.scale(0.75f, 0.75f, 1f);
        font.drawShadow(ms, s, x / 0.75f, y / 0.75f, color); ms.popPose();
    }

    private String keyName(int key) {
        if (key < 0) return "None";
        try {
            String s = InputMappings.getKey(key, 0).getDisplayName().getString();
            return s.length() > 9 ? s.substring(0, 9) : s;
        } catch (Exception e) { return "?"; }
    }

    private int count(Category c) { int n=0; for(Module m:Modules.ALL) if(m.cat==c)n++; return n; }
    private String query() { return search == null ? "" : search.getValue().trim().toLowerCase(); }

    private List<Module> visible() {
        List<Module> out = new ArrayList<>(); String q=query();
        for(Module m:Modules.ALL) if(q.isEmpty() ? m.cat==current : m.name.toLowerCase().contains(q)) out.add(m);
        return out;
    }

    private int contentX() { return X + SIDE + 12; }
    private int settingsX() { return X + W - SETTINGS - 10; }
    private int contentR() { return settingsX() - 10; }
    private int cardW() { return Math.max(155, (contentR()-contentX()-10)/2); }
    private int cardX(int i) { return contentX() + (i%2)*(cardW()+10); }
    private int cardY(int i) { return Y+78+(i/2-scroll)*64; }
    private int rowsVisible() { return Math.max(1,(H-112)/64); }
    private boolean shown(int i) { int row=i/2-scroll; return row>=0&&row<rowsVisible(); }
    private int maxScroll(int total) { return Math.max(0,(total+1)/2-rowsVisible()); }
    private void clickSound() { minecraft.getSoundManager().play(SimpleSound.forUI(SoundEvents.UI_BUTTON_CLICK,1.0F)); }

    @Override
    public void render(MatrixStack ms, int mx, int my, float pt) {
        float t=Math.min(1f,(System.currentTimeMillis()-openTime)/190f);
        fade=0.08f+0.92f*t; openScale=0.965f+0.035f*t;

        fill(ms,0,0,width,height,a(0xB9000000));
        drawBackdrop(ms);

        ms.pushPose();
        ms.translate(width/2f,height/2f,0); ms.scale(openScale,openScale,1); ms.translate(-width/2f,-height/2f,0);

        int accent=Util.accent(0f);
        Util.rrect(ms,X-2,Y-2,X+W+2,Y+H+2,16,a(Util.withAlpha(accent,0x72)));
        Util.rrect(ms,X,Y,X+W,Y+H,15,a(0xF10A0C13));
        Util.rrect(ms,X+7,Y+7,X+SIDE,Y+H-7,11,a(0xB910121A));
        Util.rrect(ms,contentX(),Y+7,settingsX()-3,Y+H-7,11,a(0x6D0D0F17));
        Util.rrect(ms,settingsX(),Y+7,X+W-7,Y+H-7,11,a(0x8D0D0F17));
        fill(ms,X+SIDE,Y+8,X+SIDE+1,Y+H-8,a(0x20FFFFFF));
        fill(ms,X+SIDE+7,Y+57,X+W-12,Y+58,a(Util.withAlpha(accent,0x42)));

        drawCategories(ms,mx,my);
        drawHeader(ms);

        List<Module> list=visible();
        scroll=Math.max(0,Math.min(maxScroll(list.size()),scroll));
        for(int i=0;i<list.size();i++) if(shown(i)) drawCard(ms,list.get(i),i,mx,my);
        drawSettings(ms,mx,my);

        if(binding!=null) {
            Util.rrect(ms,contentX(),Y+H-34,settingsX()-10,Y+H-11,7,a(Util.withAlpha(accent,0x38)));
            small(ms,"Нажми клавишу для бинда • ESC отмена",contentX()+9,Y+H-26,a(0xFFEFEAFF));
        }
        super.render(ms,mx,my,pt);
        ms.popPose();
    }

    private void drawBackdrop(MatrixStack ms) {
        int c=Util.accent(0.2f);
        // Only a few static-ish orbs: visually rich without per-frame particle work.
        int t=(int)((System.currentTimeMillis()/40)%80);
        Util.rrect(ms,-40+t,70,180+t,210,70,a(Util.withAlpha(c,0x09)));
        Util.rrect(ms,width-180-t,height-210,width+40-t,height-20,90,a(Util.withAlpha(Util.accent(0.7f),0x08)));
    }

    private void drawCategories(MatrixStack ms,int mx,int my){
        int ry=Y+72;
        for(Category c:Category.values()){
            boolean sel=c==current, hov=mx>=X+12&&mx<X+SIDE-5&&my>=ry&&my<ry+29;
            if(sel){
                Util.rrect(ms,X+13,ry,X+SIDE-6,ry+29,9,a(Util.withAlpha(Util.accent(0f),0x48)));
                Util.rrect(ms,X+13,ry+6,X+16,ry+24,2,a(Util.accent(0f)));
            } else if(hov) Util.rrect(ms,X+13,ry,X+SIDE-6,ry+29,9,a(0x20FFFFFF));
            Util.rrect(ms,X+22,ry+7,X+43,ry+28,6,a(sel?Util.withAlpha(Util.accent(0.2f),0x40):0x18FFFFFF));
            small(ms,c.label.substring(0,1),X+29,ry+13,a(sel?0xFFFFFFFF:0xFF898A9E));
            font.drawShadow(ms,c.label,X+51,ry+10,a(sel?0xFFF7F5FF:0xFF9697AA));
            String cnt=String.valueOf(count(c)); small(ms,cnt,X+SIDE-25,ry+11,a(0xFF686A7D));
            ry+=31;
        }
        int uy=Y+H-54;
        Util.rrect(ms,X+13,uy,X+SIDE-6,uy+38,9,a(0x25FFFFFF));
        Util.rrect(ms,X+21,uy+8,X+43,uy+30,7,a(Util.accent(0.5f)));
        String nm=minecraft.getUser().getName(); String initial=nm.isEmpty()?"?":nm.substring(0,1).toUpperCase();
        font.drawShadow(ms,initial,X+28,uy+12,0xFFFFFFFF);
        font.drawShadow(ms,font.plainSubstrByWidth(nm,65),X+51,uy+8,a(0xFFFFFFFF));
        small(ms,"AURORA  •  1.16.5",X+51,uy+23,a(0xFF77798D));
    }

    private void drawHeader(MatrixStack ms){
        int cx=contentX(), right=contentR(); String q=query();
        font.drawShadow(ms,q.isEmpty()?current.label:"Search",cx,Y+14,a(0xFFF5F3FF));
        small(ms,q.isEmpty()?current.sub:"Результаты по всем разделам",cx,Y+31,a(0xFF77798D));
        int sx=right-194,sy=Y+12;
        Util.rrect(ms,sx,sy,right,sy+30,8,a(0xD0131620));
        // magnifier
        Util.rrect(ms,sx+10,sy+9,sx+19,sy+18,5,a(0x00000000));
        small(ms,"⌕",sx+10,sy+7,a(0xFF9294A8));
        if(search.getValue().isEmpty()&&!search.isFocused()) small(ms,"Поиск модулей",sx+28,sy+9,a(0xFF74768A));
    }

    private void drawCard(MatrixStack ms,Module m,int i,int mx,int my){
        int x=cardX(i),y=cardY(i),w=cardW(),h=57;
        boolean hov=mx>=x&&mx<x+w&&my>=y&&my<y+h;
        int acc=Util.accent(i*0.08f);
        m.anim += ((m.enabled?1f:0f)-m.anim)*0.18f;
        boolean on=m.isToggle()&&m.enabled;
        if(selected==m) Util.rrect(ms,x-1,y-1,x+w+1,y+h+1,11,a(Util.withAlpha(acc,0x7A)));
        else if(on) Util.rrect(ms,x-1,y-1,x+w+1,y+h+1,11,a(Util.withAlpha(acc,0x28)));
        Util.rrect(ms,x,y,x+w,y+h,10,a(hov?0xFF191C27:0xFF11141D));
        if(on) Util.rrect(ms,x+1,y+1,x+4,y+h-1,2,a(acc));
        Util.rrect(ms,x+11,y+11,x+41,y+41,8,a(on?Util.withAlpha(acc,0x42):0x1CFFFFFF));
        String initial=m.name.isEmpty()?"?":m.name.substring(0,1).toUpperCase();
        font.drawShadow(ms,initial,x+20,y+18,a(on?0xFFFFFFFF:0xFFB6B4C7));
        font.drawShadow(ms,m.name,x+52,y+9,a(0xFFF1EFF8));
        small(ms,m.desc,x+52,y+25,a(0xFF858698));
        if(m.isToggle()) drawSwitch(ms,x+w-46,y+12,on,acc);
        else if(m.modes!=null){
            String txt=m.modes[Math.max(0,Math.min(m.mode,m.modes.length-1))];
            int tw=Math.max(40,(int)(font.width(txt)*0.75f)+18);
            Util.rrect(ms,x+w-tw-10,y+11,x+w-10,y+28,7,a(Util.withAlpha(acc,0x35)));
            small(ms,txt,x+w-tw-3,y+15,a(acc));
        }
        small(ms,selected==m?"Выбрано • ПКМ для выбора":"ПКМ: настройки",x+52,y+43,a(selected==m?acc:0xFF626477));
    }

    private void drawSettings(MatrixStack ms,int mx,int my){
        int x=settingsX(), r=X+W-10, y=Y+66, b=Y+H-10;
        Util.rrect(ms,x,y,r,b,12,a(0xD90E1119));
        Module m=selected; if(m==null)return;
        int acc=Util.accent(0.25f);

        // top identity block
        Util.rrect(ms,x+10,y+10,r-10,y+65,9,a(0x18FFFFFF));
        Util.rrect(ms,x+19,y+19,x+51,y+51,9,a(Util.withAlpha(acc,0x48)));
        font.drawShadow(ms,m.name,x+62,y+15,a(0xFFF6F4FF));
        small(ms,m.cat.label+"  •  "+(m.enabled?"ON":"OFF"),x+62,y+31,a(m.enabled?0xFF73E8A4:0xFF77798D));
        small(ms,"Настройки модуля",x+62,y+45,a(0xFF77798D));

        int ry=y+78;
        if(m.isToggle()){
            font.drawShadow(ms,"Enabled",x+14,ry+5,a(0xFFEDEBF5));
            drawSwitch(ms,r-52,ry,trueIf(m),acc);
            ry+=35;
        }

        font.drawShadow(ms,"Keybind",x+14,ry+5,a(0xFFEDEBF5));
        Util.rrect(ms,r-93,ry,r-14,ry+24,7,a(0x22FFFFFF));
        small(ms,binding==m?"PRESS KEY":keyName(m.key),r-84,ry+8,a(binding==m?acc:0xFFD8D6E4));
        ry+=38;

        if(m.modes!=null){
            font.drawShadow(ms,"Mode / Value",x+14,ry+3,a(0xFFEDEBF5));
            small(ms,"выбери значение ниже",x+14,ry+16,a(0xFF77798D));
            ry+=31;
            if(isNumericModes(m.modes)) ry=drawNumericControl(ms,m,x,r,ry,acc);
            else ry=drawModeChips(ms,m,x,r,ry,acc);
        }

        // Context cards make the panel feel like a real client instead of a flat menu.
        int infoY=Math.min(ry+14,b-74);
        Util.rrect(ms,x+12,infoY,r-12,infoY+54,9,a(0x18FFFFFF));
        small(ms,"AURORA TIP",x+22,infoY+9,a(acc));
        small(ms,tipFor(m),x+22,infoY+24,a(0xFFAAA9B8));
        small(ms,"ПКМ по модулю • ЛКМ переключает",x+22,infoY+39,a(0xFF707284));

        small(ms,"ЛКМ — включить  •  ПКМ — выбрать",x+14,b-31,a(0xFF66687A));
        small(ms,"ESC — закрыть  •  колесо — прокрутка",x+14,b-18,a(0xFF66687A));
    }

    private boolean trueIf(Module m){ return m.enabled; }

    private void drawSwitch(MatrixStack ms,int x,int y,boolean on,int acc){
        Util.rrect(ms,x,y,x+35,y+19,9,a(on?Util.withAlpha(acc,0xD8):0x30323F));
        Util.rrect(ms,x+(on?19:3),y+4,x+(on?30:14),y+15,6,a(0xFFF7F5FF));
    }

    private boolean isNumericModes(String[] modes){
        if(modes.length<2)return false;
        for(String s:modes) try{Float.parseFloat(s.replace("%",""));}catch(Exception e){return false;}
        return true;
    }

    private int drawNumericControl(MatrixStack ms,Module m,int x,int r,int y,int acc){
        int sy=y+3, lx=x+16, rx=r-18;
        Util.rrect(ms,lx,sy+13,rx,sy+17,3,a(0x30323F));
        float p=m.modes.length<=1?0f:(float)m.mode/(m.modes.length-1);
        Util.rrect(ms,lx,sy+13,lx+(int)((rx-lx)*p),sy+17,3,a(acc));
        Util.rrect(ms,lx+(int)((rx-lx)*p)-5,sy+8,lx+(int)((rx-lx)*p)+5,sy+18,5,a(0xFFF5F3FF));
        small(ms,m.modes[m.mode],r-53,sy-1,a(acc));
        small(ms,"перетащи ползунок",x+14,sy+28,a(0xFF77798D));
        return y+52;
    }

    private int drawModeChips(MatrixStack ms,Module m,int x,int r,int y,int acc){
        int chipX=x+14, chipY=y;
        for(int i=0;i<m.modes.length;i++){
            String s=m.modes[i]; int cw=Math.max(48,(int)(font.width(s)*0.75f)+20);
            if(chipX+cw>r-14){chipX=x+14;chipY+=29;}
            boolean sel=i==m.mode;
            Util.rrect(ms,chipX,chipY,chipX+cw,chipY+23,7,a(sel?Util.withAlpha(acc,0x70):0x20FFFFFF));
            small(ms,s,chipX+10,chipY+7,a(sel?0xFFFFFFFF:0xFFAAAABC));
            chipX+=cw+6;
        }
        return chipY+34;
    }

    private String tipFor(Module m){
        String n=m.name.toLowerCase();
        if(n.contains("fog")) return "Цвет и атмосфера мира без тяжёлых шейдеров.";
        if(n.contains("theme")) return "Меняй акцент клиента — GUI обновится сразу.";
        if(n.contains("particle")) return "Для телефона лучше Low/Medium — меньше нагрузки.";
        if(n.contains("aura")) return "ПКМ открывает настройки, ЛКМ быстро переключает.";
        if(n.contains("hud")) return "Используй HUD Editor, чтобы расставить элементы.";
        return "Все изменения сохраняются при закрытии меню.";
    }

    @Override public boolean keyPressed(int key,int scan,int mods){
        if(binding!=null){
            if(key==GLFW.GLFW_KEY_ESCAPE){binding=null;return true;}
            binding.key=key==GLFW.GLFW_KEY_BACKSPACE?-1:key; binding=null; Config.save(); return true;
        }
        return super.keyPressed(key,scan,mods);
    }

    @Override public boolean mouseClicked(double mx,double my,int button){
        if(super.mouseClicked(mx,my,button)) return true;
        if(button!=0&&button!=1)return false;

        int ry=Y+72;
        for(Category c:Category.values()){
            if(mx>=X+13&&mx<X+SIDE-6&&my>=ry&&my<ry+29){current=c;scroll=0;search.setValue("");clickSound();return true;}
            ry+=31;
        }

        List<Module> list=visible();
        for(int i=0;i<list.size();i++){
            if(!shown(i))continue;
            Module m=list.get(i); int x=cardX(i),y=cardY(i),w=cardW();
            if(mx>=x&&mx<x+w&&my>=y&&my<y+57){
                if(button==1){selected=m;clickSound();return true;}
                if(m.isToggle()&&mx>=x+w-62&&my<y+34)m.click();
                else if(m.modes!=null&&mx>=x+w-90)m.click();
                else selected=m;
                if(m==Modules.HITSNDSEL)SoundFx.play(m.mode,0.75f,1.0f);
                clickSound();return true;
            }
        }

        int rx=settingsX(),rr=X+W-10,sy=Y+66;
        if(selected!=null&&mx>=rx&&mx<rr&&my>=sy){
            if(selected.isToggle()&&my>=sy+78&&my<sy+109){selected.click();clickSound();return true;}
            int by=sy+(selected.isToggle()?113:78);
            if(my>=by&&my<by+24){binding=selected;clickSound();return true;}
            if(selected.modes!=null){
                int myStart=by+38;
                if(isNumericModes(selected.modes)){
                    int lx=rx+16, rrx=rr-18;
                    if(my>=myStart+10&&my<=myStart+28){setNumericFromMouse(selected,(float)((mx-lx)/(double)(rrx-lx)));clickSound();return true;}
                }else{
                    int chipX=rx+14,chipY=myStart;
                    for(int i=0;i<selected.modes.length;i++){
                        int cw=Math.max(48,(int)(font.width(selected.modes[i])*0.75f)+20);
                        if(chipX+cw>rr-14){chipX=rx+14;chipY+=29;}
                        if(mx>=chipX&&mx<chipX+cw&&my>=chipY&&my<chipY+23){selected.mode=i;clickSound();return true;}
                        chipX+=cw+6;
                    }
                }
            }
        }
        return false;
    }

    private void setNumericFromMouse(Module m,float p){
        p=Math.max(0,Math.min(0.999f,p));
        m.mode=Math.max(0,Math.min(m.modes.length-1,(int)Math.floor(p*m.modes.length)));
        draggingSlider=m;
    }

    @Override public boolean mouseDragged(double mx,double my,int button,double dx,double dy){
        if(draggingSlider!=null&&button==0){
            int lx=settingsX()+16, rr=X+W-28;
            setNumericFromMouse(draggingSlider,(float)((mx-lx)/(double)(rr-lx)));
            return true;
        }
        return super.mouseDragged(mx,my,button,dx,dy);
    }

    @Override public boolean mouseReleased(double mx,double my,int button){ if(button==0)draggingSlider=null; return super.mouseReleased(mx,my,button); }
    @Override public boolean mouseScrolled(double mx,double my,double delta){int max=maxScroll(visible().size());scroll=Math.max(0,Math.min(max,scroll-(int)Math.signum(delta)));return true;}
    @Override public boolean isPauseScreen(){return false;}
}
