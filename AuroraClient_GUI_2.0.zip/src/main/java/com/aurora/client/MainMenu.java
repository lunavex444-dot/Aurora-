package com.aurora.client;

import com.mojang.blaze3d.matrix.MatrixStack;
import net.minecraft.client.gui.screen.MultiplayerScreen;
import net.minecraft.client.gui.screen.OptionsScreen;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.screen.WorldSelectionScreen;
import net.minecraft.client.gui.widget.button.Button;
import net.minecraft.util.text.StringTextComponent;
import net.minecraftforge.fml.client.gui.GuiUtils;
import org.lwjgl.glfw.GLFW;

public class MainMenu extends Screen {
    private final Screen parent;
    private float fade = 0f;

    public MainMenu(Screen parent) {
        super(new StringTextComponent("Aurora Client"));
        this.parent = parent;
    }

    @Override
    protected void init() {
        int bw = Math.min(260, width - 40);
        int bh = 32;
        int x = (width - bw) / 2;
        int y = height / 2 - 18;

        addButton(new Button(x, y, bw, bh, new StringTextComponent("Singleplayer"), b -> minecraft.setScreen(new WorldSelectionScreen(this))));
        addButton(new Button(x, y + 38, bw, bh, new StringTextComponent("Multiplayer"), b -> minecraft.setScreen(new MultiplayerScreen(this))));
        addButton(new Button(x, y + 76, bw / 2 - 4, bh, new StringTextComponent("Options"), b -> minecraft.setScreen(new OptionsScreen(this, minecraft.options))));
        addButton(new Button(x + bw / 2 + 4, y + 76, bw / 2 - 4, bh, new StringTextComponent("Quit"), b -> minecraft.stop()));
    }

    @Override
    public void render(MatrixStack ms, int mx, int my, float pt) {
        fade = Math.min(1f, fade + 0.06f);
        int bg = (int)(0xFF * fade) << 24;
        fill(ms, 0, 0, width, height, bg | 0x05060B);

        // Aurora-like background bands, kept lightweight for phone performance.
        int c1 = Util.accent(0f);
        int c2 = Util.accent(0.7f);
        fill(ms, 0, height / 3, width, height / 3 + 2, Util.withAlpha(c1, 0x22));
        fill(ms, 0, height * 2 / 3, width, height * 2 / 3 + 2, Util.withAlpha(c2, 0x18));

        int cx = width / 2;
        Util.rrect(ms, cx - 31, 42, cx + 31, 104, 18, Util.withAlpha(c1, 0xCC));
        font.drawShadow(ms, "A", cx - 10, 58, 0xFFFFFFFF);
        Util.gradientText(ms, font, "AURORA", cx - font.width("AURORA") / 2f, 116, 0f);
        drawCenteredString(ms, font, "CLIENT  •  1.16.5", cx, 136, 0xFF77798D);
        drawCenteredString(ms, font, "Neon Edition", cx, 151, Util.accent(0.4f));

        // Tiny status footer.
        String player = minecraft.getUser() == null ? "Player" : minecraft.getUser().getName();
        drawCenteredString(ms, font, player + "  •  Aurora", cx, height - 24, 0xFF6D6F82);
        super.render(ms, mx, my, pt);
    }

    @Override
    public boolean keyPressed(int key, int scan, int mods) {
        if (key == GLFW.GLFW_KEY_ESCAPE) {
            if (parent != null) minecraft.setScreen(parent); else minecraft.setScreen(null);
            return true;
        }
        return super.keyPressed(key, scan, mods);
    }
}
