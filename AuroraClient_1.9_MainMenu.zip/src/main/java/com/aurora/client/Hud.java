package com.aurora.client;

import java.util.Arrays;
import java.util.List;
import java.util.Properties;

public class Hud {
    public static final HudElement WATERMARK = new HudElement("Watermark");
    public static final HudElement TARGET    = new HudElement("Target HUD");
    public static final HudElement KEYS      = new HudElement("Keystrokes");
    public static final HudElement ARMOR     = new HudElement("ArmorHUD");
    public static final HudElement COORDS    = new HudElement("Coordinates");
    public static final HudElement ARRAY     = new HudElement("ArrayList");

    public static final List<HudElement> ALL = Arrays.asList(WATERMARK, TARGET, KEYS, ARMOR, COORDS, ARRAY);

    public static void reset() {
        for (HudElement e : ALL) { e.dx = 0; e.dy = 0; }
    }

    private static String k(HudElement e, String s) { return "pos." + e.name.replace(' ', '_') + "." + s; }

    public static void save(Properties p) {
        for (HudElement e : ALL) {
            p.setProperty(k(e, "x"), String.valueOf(e.dx));
            p.setProperty(k(e, "y"), String.valueOf(e.dy));
        }
    }

    public static void load(Properties p) {
        for (HudElement e : ALL) {
            try {
                String x = p.getProperty(k(e, "x")), y = p.getProperty(k(e, "y"));
                if (x != null) e.dx = Integer.parseInt(x);
                if (y != null) e.dy = Integer.parseInt(y);
            } catch (NumberFormatException ignored) {}
        }
    }
}
