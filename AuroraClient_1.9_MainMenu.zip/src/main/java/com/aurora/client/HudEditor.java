package com.aurora.client;

import com.mojang.blaze3d.matrix.MatrixStack;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.util.text.StringTextComponent;

import java.util.List;

public class HudEditor extends Screen {
    private HudElement drag;

    public HudEditor() {
        super(new StringTextComponent("HUD Editor"));
    }

    @Override
    public void removed() {
        Config.save();
    }

    private void outline(MatrixStack ms, int x, int y, int w, int h, int c) {
        fill(ms, x - 1, y - 1, x + w + 1, y, c);
        fill(ms, x - 1, y + h, x + w + 1, y + h + 1, c);
        fill(ms, x - 1, y, x, y + h, c);
        fill(ms, x + w, y, x + w + 1, y + h, c);
    }

    @Override
    public void render(MatrixStack ms, int mx, int my, float pt) {
        fill(ms, 0, 0, width, height, 0x40000000);
        drawCenteredString(ms, font, "Перетаскивай элементы пальцем или мышкой", width / 2, 8, 0xFFFFFFFF);

        for (HudElement el : Hud.ALL) {
            if (!el.visible()) continue;
            int c = el == drag ? Util.accent(0f) : Util.withAlpha(Util.accent(0.3f), 0xB0);
            outline(ms, el.x, el.y, el.w, el.h, c);
            ms.pushPose();
            ms.scale(0.75f, 0.75f, 1f);
            font.drawShadow(ms, el.name, el.x / 0.75f, Math.max(2, el.y - 9) / 0.75f, 0xFFFFFFFF);
            ms.popPose();
        }

        int bw = 80, bh = 18, by = height - 28;
        Util.rrect(ms, width / 2 - bw - 4, by, width / 2 - 4, by + bh, 6, 0xE0301820);
        drawCenteredString(ms, font, "Сбросить", width / 2 - bw / 2 - 4, by + 5, 0xFFFFFFFF);
        Util.rrect(ms, width / 2 + 4, by, width / 2 + 4 + bw, by + bh, 6, Util.withAlpha(Util.accent(0f), 0xE0));
        drawCenteredString(ms, font, "Готово", width / 2 + 4 + bw / 2, by + 5, 0xFFFFFFFF);

        super.render(ms, mx, my, pt);
    }

    @Override
    public boolean mouseClicked(double mx, double my, int button) {
        int bw = 80, bh = 18, by = height - 28;
        if (my >= by && my <= by + bh) {
            if (mx >= width / 2 - bw - 4 && mx <= width / 2 - 4) { Hud.reset(); return true; }
            if (mx >= width / 2 + 4 && mx <= width / 2 + 4 + bw) { onClose(); return true; }
        }
        List<HudElement> all = Hud.ALL;
        for (int i = all.size() - 1; i >= 0; i--) {
            if (all.get(i).contains(mx, my)) { drag = all.get(i); return true; }
        }
        return super.mouseClicked(mx, my, button);
    }

    @Override
    public boolean mouseDragged(double mx, double my, int button, double dx, double dy) {
        if (drag != null) {
            drag.dx += (int) Math.round(dx);
            drag.dy += (int) Math.round(dy);
            return true;
        }
        return super.mouseDragged(mx, my, button, dx, dy);
    }

    @Override
    public boolean mouseReleased(double mx, double my, int button) {
        drag = null;
        return super.mouseReleased(mx, my, button);
    }

    @Override
    public boolean isPauseScreen() { return false; }
}
