package com.aurora.client;

import com.mojang.blaze3d.platform.GlStateManager;
import com.mojang.blaze3d.systems.RenderSystem;
import net.minecraft.client.Minecraft;
import net.minecraft.client.entity.player.ClientPlayerEntity;
import net.minecraft.client.renderer.ActiveRenderInfo;
import net.minecraft.client.renderer.BufferBuilder;
import net.minecraft.client.renderer.Tessellator;
import net.minecraft.client.renderer.vertex.DefaultVertexFormats;
import net.minecraft.entity.Entity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.item.ArmorStandEntity;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.vector.Matrix4f;
import net.minecraft.util.math.vector.Vector3d;
import net.minecraftforge.client.event.RenderWorldLastEvent;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import org.lwjgl.opengl.GL11;

import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.List;

/**
 * Личная косметика Aurora: шляпы (China / Halo / Crown), шлейф, аура, орбиты
 * вокруг тела и кольца вокруг цели. Всё рисуется самим модом.
 */
public class Cosmetics {
    private final ArrayDeque<double[]> trail = new ArrayDeque<>();
    private double camX, camY, camZ;
    private double[] rightV, upV, lookV;

    // ------------------------------------------------ colors
    private int hsv(float h) {
        h = h - (float) Math.floor(h);
        float s = 0.6f, v = 1f;
        int i = (int) (h * 6);
        float f = h * 6 - i;
        float p = v * (1 - s), q = v * (1 - f * s), t = v * (1 - (1 - f) * s);
        float r, g, b;
        switch (i % 6) {
            case 0:  r = v; g = t; b = p; break;
            case 1:  r = q; g = v; b = p; break;
            case 2:  r = p; g = v; b = t; break;
            case 3:  r = p; g = q; b = v; break;
            case 4:  r = t; g = p; b = v; break;
            default: r = v; g = p; b = q; break;
        }
        return ((int) (r * 255) << 16) | ((int) (g * 255) << 8) | (int) (b * 255);
    }

    private int col(float off, float alpha) {
        int a = (int) (Math.max(0f, Math.min(1f, alpha)) * 255);
        int rgb = Modules.COSCOLOR.mode == 1
                ? hsv(off + (System.currentTimeMillis() % 6000L) / 6000f)
                : (Util.accent(off) & 0xFFFFFF);
        return (a << 24) | rgb;
    }

    private int white(float alpha) {
        return ((int) (Math.max(0f, Math.min(1f, alpha)) * 255) << 24) | 0xFFFFFF;
    }

    // ------------------------------------------------ events
    @SubscribeEvent
    public void onTick(TickEvent.ClientTickEvent e) {
        if (e.phase != TickEvent.Phase.END) return;
        Minecraft mc = Minecraft.getInstance();
        ClientPlayerEntity p = mc.player;
        if (p == null || mc.level == null) { trail.clear(); return; }
        if (mc.isPaused()) return;

        Entity look = mc.crosshairPickEntity;
        if (look instanceof LivingEntity && look != p && !(look instanceof ArmorStandEntity))
            Targeting.set((LivingEntity) look);

        if (Modules.TRAILS.enabled) {
            trail.addLast(new double[]{p.getX(), p.getY(), p.getZ()});
            while (trail.size() > 34) trail.pollFirst();
        } else {
            trail.clear();
        }
    }

    @SubscribeEvent
    public void onWorld(RenderWorldLastEvent e) {
        Minecraft mc = Minecraft.getInstance();
        ClientPlayerEntity p = mc.player;
        if (p == null || mc.level == null) return;

        LivingEntity target = Modules.TARGETESP.enabled ? Targeting.get() : null;
        boolean any = Modules.CHINAHAT.enabled || Modules.TRAILS.enabled || Modules.BODYGLOW.enabled
                || Modules.ORBIT.enabled || target != null;
        if (!any) return;

        float pt = e.getPartialTicks();
        ActiveRenderInfo cam = mc.gameRenderer.getMainCamera();
        Vector3d cp = cam.getPosition();
        camX = cp.x; camY = cp.y; camZ = cp.z;
        Matrix4f m = e.getMatrixStack().last().pose();

        double yaw = Math.toRadians(cam.getYRot());
        double pitch = Math.toRadians(cam.getXRot());
        double lx = -Math.sin(yaw) * Math.cos(pitch);
        double ly = -Math.sin(pitch);
        double lz = Math.cos(yaw) * Math.cos(pitch);
        lookV = new double[]{lx, ly, lz};
        rightV = new double[]{-Math.cos(yaw), 0, -Math.sin(yaw)};
        upV = new double[]{ly * Math.sin(yaw), lz * Math.cos(yaw) - lx * Math.sin(yaw), -ly * Math.cos(yaw)};

        double px = MathHelper.lerp((double) pt, p.xo, p.getX());
        double py = MathHelper.lerp((double) pt, p.yo, p.getY());
        double pz = MathHelper.lerp((double) pt, p.zo, p.getZ());
        double eyeY = py + p.getEyeHeight();
        double dx = cp.x - px, dy = cp.y - eyeY, dz = cp.z - pz;
        boolean third = dx * dx + dy * dy + dz * dz > 0.64;
        double time = System.currentTimeMillis() / 1000.0;

        RenderSystem.enableBlend();
        RenderSystem.blendFunc(GlStateManager.SourceFactor.SRC_ALPHA, GlStateManager.DestFactor.ONE);
        RenderSystem.disableTexture();
        RenderSystem.disableCull();
        RenderSystem.depthMask(false);
        RenderSystem.disableAlphaTest();

        Tessellator tess = Tessellator.getInstance();
        BufferBuilder bb = tess.getBuilder();
        bb.begin(GL11.GL_TRIANGLES, DefaultVertexFormats.POSITION_COLOR);

        if (Modules.TRAILS.enabled) drawTrail(bb, m, px, py, pz, time);
        if (third) {
            if (Modules.BODYGLOW.enabled) aura(bb, m, px, py, pz, p.getBbWidth(), p.getBbHeight(), time);
            if (Modules.CHINAHAT.enabled) hat(bb, m, px, py + p.getBbHeight() + 0.02, pz, time);
            if (Modules.ORBIT.enabled) orbit(bb, m, px, py, pz, time);
        }
        if (target != null) {
            double tx = MathHelper.lerp((double) pt, target.xo, target.getX());
            double ty = MathHelper.lerp((double) pt, target.yo, target.getY());
            double tz = MathHelper.lerp((double) pt, target.zo, target.getZ());
            switch (Modules.TARGETSTYLE.mode) {
                case 0:  rings(bb, m, tx, ty, tz, target.getBbWidth(), target.getBbHeight(), time); break;
                case 1:  targetOrbs(bb, m, tx, ty, tz, target.getBbWidth(), target.getBbHeight(), time); break;
                default: marker(bb, m, tx, ty, tz, target.getBbHeight(), time); break;
            }
        }

        tess.end();

        RenderSystem.depthMask(true);
        RenderSystem.enableCull();
        RenderSystem.enableTexture();
        RenderSystem.enableAlphaTest();
        RenderSystem.defaultBlendFunc();
        RenderSystem.disableBlend();
    }

    // ------------------------------------------------ cosmetics
    private void drawTrail(BufferBuilder bb, Matrix4f m, double px, double py, double pz, double time) {
        List<double[]> pts = new ArrayList<>(trail);
        pts.add(new double[]{px, py, pz});
        int n = pts.size();
        if (n < 2) return;

        if (Modules.TRAILSTYLE.mode == 0) {
            double h = 0.95;
            for (int i = 0; i < n - 1; i++) {
                double[] a = pts.get(i), b = pts.get(i + 1);
                float fa = i / (float) (n - 1), fb = (i + 1) / (float) (n - 1);
                float aa = fa * fa * 0.75f, ab = fb * fb * 0.75f;
                double[] a0 = {a[0], a[1] + 0.05, a[2]};
                double[] a1 = {a[0], a[1] + h, a[2]};
                double[] b1 = {b[0], b[1] + h, b[2]};
                double[] b0 = {b[0], b[1] + 0.05, b[2]};
                quad(bb, m, a0, a1, b1, b0,
                        col(fa * 0.7f, aa), col(fa * 0.7f, aa * 0.15f),
                        col(fb * 0.7f, ab * 0.15f), col(fb * 0.7f, ab));
            }
        } else {
            for (int i = 0; i < n; i++) {
                double[] a = pts.get(i);
                float f = i / (float) (n - 1);
                double[] c = {a[0], a[1] + 0.5 + Math.sin(time * 3 + i * 0.7) * 0.35, a[2]};
                orb(bb, m, c, 0.06 + 0.14 * f, col(f * 0.7f, f * 0.7f), 8);
                orb(bb, m, c, 0.03 + 0.05 * f, white(f * 0.9f), 6);
            }
        }
    }

    private void aura(BufferBuilder bb, Matrix4f m, double px, double py, double pz,
                      double w, double h, double time) {
        double[] c = {px + lookV[0] * 0.45, py + h * 0.5 + lookV[1] * 0.45, pz + lookV[2] * 0.45};
        double pulse = 0.88 + 0.12 * Math.sin(time * 2.5);
        double rw = w * 1.9 * pulse, rh = h * 0.78 * pulse;
        int segs = 28;
        int centre = col(0f, 0.5f);
        for (int i = 0; i < segs; i++) {
            double a0 = Math.PI * 2 * i / segs, a1 = Math.PI * 2 * (i + 1) / segs;
            float h0 = (float) i / segs, h1 = (float) (i + 1) / segs;
            double[] m0 = off(c, Math.cos(a0) * rw * 0.55, Math.sin(a0) * rh * 0.55);
            double[] m1 = off(c, Math.cos(a1) * rw * 0.55, Math.sin(a1) * rh * 0.55);
            double[] o0 = off(c, Math.cos(a0) * rw, Math.sin(a0) * rh);
            double[] o1 = off(c, Math.cos(a1) * rw, Math.sin(a1) * rh);
            tri(bb, m, c, m0, m1, centre, col(h0, 0.22f), col(h1, 0.22f));
            quad(bb, m, m0, m1, o1, o0, col(h0, 0.22f), col(h1, 0.22f), col(h1, 0f), col(h0, 0f));
        }
    }

    private void hat(BufferBuilder bb, Matrix4f m, double px, double top, double pz, double time) {
        int style = Modules.HATSTYLE.mode;
        if (style == 0) {
            int n = 32;
            double r = 0.55;
            double[] apex = {px, top + 0.42, pz};
            for (int i = 0; i < n; i++) {
                double a0 = Math.PI * 2 * i / n, a1 = Math.PI * 2 * (i + 1) / n;
                double[] b0 = {px + Math.cos(a0) * r, top, pz + Math.sin(a0) * r};
                double[] b1 = {px + Math.cos(a1) * r, top, pz + Math.sin(a1) * r};
                double[] o0 = {px + Math.cos(a0) * (r + 0.08), top - 0.01, pz + Math.sin(a0) * (r + 0.08)};
                double[] o1 = {px + Math.cos(a1) * (r + 0.08), top - 0.01, pz + Math.sin(a1) * (r + 0.08)};
                float h0 = (float) i / n, h1 = (float) (i + 1) / n;
                tri(bb, m, apex, b0, b1, col(0f, 0.9f), col(h0, 0.5f), col(h1, 0.5f));
                quad(bb, m, b0, b1, o1, o0, col(h0, 0.8f), col(h1, 0.8f), col(h1, 0f), col(h0, 0f));
            }
        } else if (style == 1) {
            double y = top + 0.3 + Math.sin(time * 2.0) * 0.03;
            int n = 40;
            for (int i = 0; i < n; i++) {
                double a0 = Math.PI * 2 * i / n, a1 = Math.PI * 2 * (i + 1) / n;
                float h0 = (float) i / n + (float) (time * 0.3), h1 = (float) (i + 1) / n + (float) (time * 0.3);
                double[] i0 = {px + Math.cos(a0) * 0.28, y, pz + Math.sin(a0) * 0.28};
                double[] i1 = {px + Math.cos(a1) * 0.28, y, pz + Math.sin(a1) * 0.28};
                double[] c0 = {px + Math.cos(a0) * 0.38, y, pz + Math.sin(a0) * 0.38};
                double[] c1 = {px + Math.cos(a1) * 0.38, y, pz + Math.sin(a1) * 0.38};
                double[] o0 = {px + Math.cos(a0) * 0.55, y, pz + Math.sin(a0) * 0.55};
                double[] o1 = {px + Math.cos(a1) * 0.55, y, pz + Math.sin(a1) * 0.55};
                quad(bb, m, i0, i1, c1, c0, col(h0, 0.2f), col(h1, 0.2f), col(h1, 0.95f), col(h0, 0.95f));
                quad(bb, m, c0, c1, o1, o0, col(h0, 0.95f), col(h1, 0.95f), col(h1, 0f), col(h0, 0f));
                double[] t0 = {c0[0], y + 0.12, c0[2]};
                double[] t1 = {c1[0], y + 0.12, c1[2]};
                quad(bb, m, c0, c1, t1, t0, col(h0, 0.7f), col(h1, 0.7f), col(h1, 0f), col(h0, 0f));
            }
        } else {
            double y = top + 0.02, r = 0.34;
            int n = 32;
            for (int i = 0; i < n; i++) {
                double a0 = Math.PI * 2 * i / n, a1 = Math.PI * 2 * (i + 1) / n;
                float h0 = (float) i / n, h1 = (float) (i + 1) / n;
                double[] b0 = {px + Math.cos(a0) * r, y, pz + Math.sin(a0) * r};
                double[] b1 = {px + Math.cos(a1) * r, y, pz + Math.sin(a1) * r};
                double[] t0 = {b0[0], y + 0.1, b0[2]};
                double[] t1 = {b1[0], y + 0.1, b1[2]};
                quad(bb, m, b0, b1, t1, t0, col(h0, 0.55f), col(h1, 0.55f), col(h0, 0.9f), col(h1, 0.9f));
            }
            int spikes = 8;
            for (int k = 0; k < spikes; k++) {
                double a0 = Math.PI * 2 * k / spikes, a1 = Math.PI * 2 * (k + 1) / spikes;
                double am = (a0 + a1) / 2;
                double[] b0 = {px + Math.cos(a0) * r, y + 0.1, pz + Math.sin(a0) * r};
                double[] b1 = {px + Math.cos(a1) * r, y + 0.1, pz + Math.sin(a1) * r};
                double[] apex = {px + Math.cos(am) * r * 0.95, y + 0.34, pz + Math.sin(am) * r * 0.95};
                float h = (float) k / spikes;
                tri(bb, m, b0, b1, apex, col(h, 0.85f), col(h + 0.1f, 0.85f), white(1f));
            }
        }
    }

    private void orbit(BufferBuilder bb, Matrix4f m, double px, double py, double pz, double time) {
        int count = 5;
        for (int k = 0; k < count; k++) {
            for (int t = 0; t < 5; t++) {
                double ang = time * 1.6 + k * Math.PI * 2 / count - t * 0.12;
                double y = py + 0.9 + Math.sin(time * 2.2 + k * 1.3 - t * 0.1) * 0.35;
                double[] c = {px + Math.cos(ang) * 0.95, y, pz + Math.sin(ang) * 0.95};
                float f = 1f - t / 5f;
                orb(bb, m, c, 0.2 * f, col(k / (float) count, 0.5f * f), 10);
                if (t == 0) {
                    orb(bb, m, c, 0.1, col(k / (float) count, 0.95f), 8);
                    orb(bb, m, c, 0.045, white(1f), 6);
                }
            }
        }
    }

    private void rings(BufferBuilder bb, Matrix4f m, double tx, double ty, double tz,
                       double bw, double bh, double time) {
        double rad = bw * 0.75 + 0.3;
        int n = 48;
        for (int k = 0; k < 2; k++) {
            double y = ty + (0.5 + 0.5 * Math.sin(time * 1.8 + k * Math.PI)) * bh;
            double rot = time * (k == 0 ? 3.0 : -3.0);
            for (int i = 0; i < n; i++) {
                double a0 = Math.PI * 2 * i / n, a1 = Math.PI * 2 * (i + 1) / n;
                float b0 = (float) Math.pow(Math.max(0, Math.cos(a0 - rot)), 3);
                float b1 = (float) Math.pow(Math.max(0, Math.cos(a1 - rot)), 3);
                float al0 = 0.1f + 0.85f * b0, al1 = 0.1f + 0.85f * b1;
                float h0 = (float) i / n, h1 = (float) (i + 1) / n;
                double[] t0 = {tx + Math.cos(a0) * rad, y + 0.02, tz + Math.sin(a0) * rad};
                double[] t1 = {tx + Math.cos(a1) * rad, y + 0.02, tz + Math.sin(a1) * rad};
                double[] u0 = {t0[0], y - 0.16, t0[2]};
                double[] u1 = {t1[0], y - 0.16, t1[2]};
                quad(bb, m, t0, t1, u1, u0, col(h0, al0), col(h1, al1), col(h1, al1 * 0.05f), col(h0, al0 * 0.05f));
            }
        }
    }

    /** Target ESP: четыре светящихся шара с хвостами летают вокруг цели. */
    private void targetOrbs(BufferBuilder bb, Matrix4f m, double tx, double ty, double tz,
                            double bw, double bh, double time) {
        double rad = bw * 0.8 + 0.35;
        int count = 4;
        for (int k = 0; k < count; k++) {
            for (int t = 0; t < 7; t++) {
                double ang = time * 2.4 + k * Math.PI * 2 / count - t * 0.11;
                double y = ty + bh * (0.5 + 0.38 * Math.sin(time * 1.7 + k * 1.57 - t * 0.08));
                double[] c = {tx + Math.cos(ang) * rad, y, tz + Math.sin(ang) * rad};
                float f = 1f - t / 7f;
                float hue = k / (float) count + t * 0.02f;
                orb(bb, m, c, 0.17 * f + 0.02, col(hue, 0.55f * f), 10);
                if (t == 0) {
                    orb(bb, m, c, 0.09, col(hue, 0.95f), 8);
                    orb(bb, m, c, 0.04, white(1f), 6);
                }
            }
        }
    }

    /** Target ESP: вращающийся кристалл-маркер над головой цели. */
    private void marker(BufferBuilder bb, Matrix4f m, double tx, double ty, double tz,
                        double bh, double time) {
        double top = ty + bh + 0.55 + Math.sin(time * 2.0) * 0.08;
        double s = 0.26, hgt = 0.34;
        double ang = time * 2.2;
        double[] apexT = {tx, top + hgt, tz};
        double[] apexB = {tx, top - hgt, tz};
        double[][] eq = new double[4][];
        for (int i = 0; i < 4; i++) {
            double a = ang + i * Math.PI / 2;
            eq[i] = new double[]{tx + Math.cos(a) * s, top, tz + Math.sin(a) * s};
        }
        for (int i = 0; i < 4; i++) {
            int j = (i + 1) % 4;
            float shade = (float) (0.45 + 0.4 * (0.5 + 0.5 * Math.sin(ang * 1.0 + i * Math.PI / 2)));
            float h0 = i / 4f, h1 = (i + 1) / 4f;
            tri(bb, m, apexT, eq[i], eq[j], white(0.95f), col(h0, shade), col(h1, shade));
            tri(bb, m, apexB, eq[j], eq[i], col(0.5f, 0.9f), col(h1, shade), col(h0, shade));
        }
        double[] c = {tx, top, tz};
        orb(bb, m, c, 0.65, col(0f, 0.28f), 12);
        orb(bb, m, c, 0.16, white(0.8f), 8);
    }

    // ------------------------------------------------ drawing helpers
    private void v(BufferBuilder bb, Matrix4f m, double x, double y, double z, int c) {
        bb.vertex(m, (float) (x - camX), (float) (y - camY), (float) (z - camZ))
                .color(((c >> 16) & 255) / 255f, ((c >> 8) & 255) / 255f, (c & 255) / 255f, ((c >>> 24) & 255) / 255f)
                .endVertex();
    }

    private void tri(BufferBuilder bb, Matrix4f m, double[] a, double[] b, double[] c, int ca, int cb, int cc) {
        v(bb, m, a[0], a[1], a[2], ca);
        v(bb, m, b[0], b[1], b[2], cb);
        v(bb, m, c[0], c[1], c[2], cc);
    }

    private void quad(BufferBuilder bb, Matrix4f m, double[] a, double[] b, double[] c, double[] d,
                      int ca, int cb, int cc, int cd) {
        tri(bb, m, a, b, c, ca, cb, cc);
        tri(bb, m, a, c, d, ca, cc, cd);
    }

    private double[] off(double[] c, double a, double b) {
        return new double[]{c[0] + rightV[0] * a + upV[0] * b,
                c[1] + rightV[1] * a + upV[1] * b,
                c[2] + rightV[2] * a + upV[2] * b};
    }

    /** Мягкий светящийся диск лицом к камере. */
    private void orb(BufferBuilder bb, Matrix4f m, double[] c, double rad, int color, int segs) {
        int edge = color & 0x00FFFFFF;
        for (int i = 0; i < segs; i++) {
            double a0 = Math.PI * 2 * i / segs, a1 = Math.PI * 2 * (i + 1) / segs;
            tri(bb, m, c, off(c, Math.cos(a0) * rad, Math.sin(a0) * rad),
                    off(c, Math.cos(a1) * rad, Math.sin(a1) * rad), color, edge, edge);
        }
    }
}
