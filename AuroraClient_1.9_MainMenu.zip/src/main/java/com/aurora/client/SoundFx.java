package com.aurora.client;

import net.minecraft.client.Minecraft;
import net.minecraft.util.SoundCategory;
import net.minecraft.util.SoundEvents;
import org.lwjgl.BufferUtils;
import org.lwjgl.openal.AL10;

import java.nio.ShortBuffer;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Random;

/**
 * Собственные звуки Aurora. Синтезируются прямо в моде и играются через OpenAL,
 * поэтому никаких файлов и ванильных звуков. Если OpenAL недоступен, играет запасной звук.
 */
public class SoundFx {
    public static final String[] NAMES = {"Crystal", "Pop", "Bell", "Laser", "Snap", "Coin", "Bonk", "Zap"};
    private static final int KILL = 8;
    private static final int RATE = 44100;

    private static final int[] buffers = new int[9];
    private static final List<Integer> sources = new ArrayList<>();
    private static boolean failed = false;

    private static short[] synth(int kind) {
        double dur;
        switch (kind) {
            case 0: dur = 0.40; break;
            case 1: dur = 0.15; break;
            case 2: dur = 0.70; break;
            case 3: dur = 0.25; break;
            case 4: dur = 0.10; break;
            case 5: dur = 0.45; break;
            case 6: dur = 0.22; break;
            case 7: dur = 0.25; break;
            default: dur = 0.90; break;
        }
        int n = (int) (RATE * dur);
        double[] d = new double[n];
        Random r = new Random(7);
        double phase = 0;
        double[] notes = {1047, 1319, 1568, 2093};

        for (int i = 0; i < n; i++) {
            double t = i / (double) RATE;
            double s;
            switch (kind) {
                case 0: // Crystal: звонкий стеклянный перелив
                    s = (Math.sin(2 * Math.PI * 1760 * t) * 0.55 + Math.sin(2 * Math.PI * 2349 * t) * 0.35
                            + Math.sin(2 * Math.PI * 3520 * t) * 0.22) * Math.exp(-9 * t);
                    break;
                case 1: { // Pop: короткий пузырь
                    double f = 90 + 310 * Math.exp(-40 * t);
                    phase += 2 * Math.PI * f / RATE;
                    s = Math.sin(phase) * Math.exp(-26 * t);
                    break;
                }
                case 2: // Bell: FM-колокольчик
                    s = Math.sin(2 * Math.PI * 880 * t + 3 * Math.exp(-6 * t) * Math.sin(2 * Math.PI * 3080 * t))
                            * Math.exp(-5 * t);
                    break;
                case 3: { // Laser: падающий свист
                    double f = 300 + 2100 * Math.exp(-18 * t);
                    phase += 2 * Math.PI * f / RATE;
                    s = Math.sin(phase) * Math.exp(-11 * t);
                    break;
                }
                case 4: // Snap: сухой щелчок
                    s = (r.nextDouble() * 2 - 1) * 0.6 * Math.exp(-70 * t)
                            + Math.sin(2 * Math.PI * 1500 * t) * 0.6 * Math.exp(-45 * t);
                    break;
                case 5: { // Coin: две ноты
                    boolean first = t < 0.07;
                    double f = first ? 988 : 1319;
                    double tt = first ? t : t - 0.07;
                    s = (Math.sin(2 * Math.PI * f * t) + 0.3 * Math.sin(4 * Math.PI * f * t))
                            * Math.exp(-(first ? 25 : 9) * tt);
                    break;
                }
                case 6: { // Bonk: глухой тяжёлый удар
                    double f = 60 + 160 * Math.exp(-30 * t);
                    phase += 2 * Math.PI * f / RATE;
                    s = Math.sin(phase) * Math.exp(-14 * t) + (t < 0.004 ? (r.nextDouble() * 2 - 1) * 0.7 : 0);
                    break;
                }
                case 7: { // Zap: электрический разряд
                    double saw = 2 * ((t * 220) % 1.0) - 1;
                    s = saw * 0.5 * Math.exp(-14 * t)
                            + (r.nextDouble() * 2 - 1) * 0.5 * Math.exp(-40 * t)
                            + Math.sin(2 * Math.PI * (1800 - 5000 * t) * t) * 0.4 * Math.exp(-16 * t);
                    break;
                }
                default: { // Kill: восходящий аккорд
                    s = 0;
                    for (int k = 0; k < notes.length; k++) {
                        double tt = t - k * 0.07;
                        if (tt < 0) continue;
                        s += (Math.sin(2 * Math.PI * notes[k] * tt) + 0.25 * Math.sin(4 * Math.PI * notes[k] * tt))
                                * Math.exp(-7 * tt) * 0.5;
                    }
                    break;
                }
            }
            d[i] = s * Math.min(1.0, t / 0.002);
        }

        double peak = 0.0001;
        for (double v : d) peak = Math.max(peak, Math.abs(v));
        int fade = (int) (RATE * 0.005);
        short[] out = new short[n];
        for (int i = 0; i < n; i++) {
            double v = d[i] / peak * 0.8;
            if (i > n - fade) v *= (n - i) / (double) fade;
            out[i] = (short) (v * 32767);
        }
        return out;
    }

    private static int buffer(int kind) {
        if (buffers[kind] == 0) {
            short[] data = synth(kind);
            ShortBuffer sb = BufferUtils.createShortBuffer(data.length);
            sb.put(data);
            sb.flip();
            int buf = AL10.alGenBuffers();
            AL10.alBufferData(buf, AL10.AL_FORMAT_MONO16, sb, RATE);
            buffers[kind] = buf;
        }
        return buffers[kind];
    }

    public static void cleanup() {
        if (failed || sources.isEmpty()) return;
        try {
            Iterator<Integer> it = sources.iterator();
            while (it.hasNext()) {
                int src = it.next();
                if (AL10.alGetSourcei(src, AL10.AL_SOURCE_STATE) == AL10.AL_STOPPED) {
                    AL10.alDeleteSources(src);
                    it.remove();
                }
            }
        } catch (Throwable t) {
            failed = true;
        }
    }

    public static void playKill(float vol) { play(KILL, vol, 1.0f); }

    public static void play(int kind, float vol, float pitch) {
        Minecraft mc = Minecraft.getInstance();
        float gain = vol * mc.options.getSoundSourceVolume(SoundCategory.PLAYERS);
        if (!failed) {
            try {
                AL10.alGetError();
                int buf = buffer(kind);
                int src = AL10.alGenSources();
                AL10.alSourcei(src, AL10.AL_BUFFER, buf);
                AL10.alSourcef(src, AL10.AL_GAIN, gain);
                AL10.alSourcef(src, AL10.AL_PITCH, pitch);
                AL10.alSourcei(src, AL10.AL_SOURCE_RELATIVE, AL10.AL_TRUE);
                AL10.alSource3f(src, AL10.AL_POSITION, 0f, 0f, 0f);
                AL10.alSourcePlay(src);
                if (AL10.alGetError() != AL10.AL_NO_ERROR) throw new IllegalStateException("AL error");
                sources.add(src);
                return;
            } catch (Throwable t) {
                failed = true;
            }
        }
        // запасной вариант, если OpenAL недоступен
        if (mc.level != null && mc.player != null) {
            mc.level.playLocalSound(mc.player.getX(), mc.player.getY(), mc.player.getZ(),
                    kind == KILL ? SoundEvents.PLAYER_LEVELUP : SoundEvents.EXPERIENCE_ORB_PICKUP,
                    SoundCategory.PLAYERS, vol, pitch, false);
        }
    }
}
