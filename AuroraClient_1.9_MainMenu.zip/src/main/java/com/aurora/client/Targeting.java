package com.aurora.client;

import net.minecraft.entity.LivingEntity;

/** Общая цель (по прицелу или последнему удару) для HUD и косметики. */
public class Targeting {
    private static LivingEntity target;
    private static long time;

    public static void set(LivingEntity t) {
        target = t;
        time = System.currentTimeMillis();
    }

    public static LivingEntity get() {
        if (target != null && (System.currentTimeMillis() - time > 3000 || !target.isAlive())) target = null;
        return target;
    }
}
