package com.aurora.client;

public class HudElement {
    public final String name;
    public int dx, dy;            // user offset
    public int x, y, w, h;        // last drawn bounds
    private long lastDrawn = 0;

    public HudElement(String name) { this.name = name; }

    public void set(int x, int y, int w, int h) {
        this.x = x; this.y = y; this.w = w; this.h = h;
        this.lastDrawn = System.currentTimeMillis();
    }

    public boolean visible() { return System.currentTimeMillis() - lastDrawn < 400; }

    public boolean contains(double mx, double my) {
        return visible() && mx >= x && mx <= x + w && my >= y && my <= y + h;
    }
}
