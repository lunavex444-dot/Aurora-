package com.aurora.client;

import net.minecraft.client.settings.KeyBinding;
import net.minecraftforge.common.MinecraftForge;
import net.minecraftforge.client.event.GuiOpenEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraft.client.gui.screen.MainMenuScreen;
import net.minecraftforge.fml.client.registry.ClientRegistry;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.event.lifecycle.FMLClientSetupEvent;
import net.minecraftforge.fml.javafmlmod.FMLJavaModLoadingContext;
import org.lwjgl.glfw.GLFW;

@Mod(AuroraClient.MODID)
public class AuroraClient {
    public static final String MODID = "auroraclient";
    public static final String NAME = "Aurora";
    public static KeyBinding OPEN_GUI;

    public AuroraClient() {
        FMLJavaModLoadingContext.get().getModEventBus().addListener(this::clientSetup);
    }

    private void clientSetup(final FMLClientSetupEvent event) {
        OPEN_GUI = new KeyBinding("Open Aurora menu", GLFW.GLFW_KEY_RIGHT_SHIFT, "Aurora Client");
        ClientRegistry.registerKeyBinding(OPEN_GUI);
        Config.load();
        MinecraftForge.EVENT_BUS.register(this);
        MinecraftForge.EVENT_BUS.register(new HudRenderer());
        MinecraftForge.EVENT_BUS.register(new Combat());
        MinecraftForge.EVENT_BUS.register(new Particles());
        MinecraftForge.EVENT_BUS.register(new Cosmetics());
    }
    @SubscribeEvent
    public void onGuiOpen(GuiOpenEvent event) {
        if (event.getGui() instanceof MainMenuScreen && !(event.getGui() instanceof AuroraMainMenu)) {
            event.setGui(new AuroraMainMenu());
        }
    }

}
