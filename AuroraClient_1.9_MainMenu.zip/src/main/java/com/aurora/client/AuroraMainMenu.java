package com.aurora.client;

import com.mojang.blaze3d.matrix.MatrixStack;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.screen.MultiplayerScreen;
import net.minecraft.client.gui.screen.OptionsScreen;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.screen.WorldSelectionScreen;
import net.minecraft.util.text.StringTextComponent;
import org.lwjgl.glfw.GLFW;

/** Aurora's replacement for the vanilla 1.16.5 main menu. */
public class AuroraMainMenu extends Screen {
    private final long openedAt = System.currentTimeMillis();
    private float fade;

    public AuroraMainMenu() {
        super(new StringTextComponent("Aurora Client"));
    }

    private int accent(float offset) {
        return Util.accent(offset);
    }

    private boolean over(int x, int y, int w, int h, double mx, double my) {
        return mx >= x && mx <= x + w && my >= y && my <= y + h;
    }

    private void button(MatrixStack ms, String text, int x, int y, int w, int h, boolean hover, float offset) {
        int ac = accent(offset);
        if (hover) {
            Util.rrect(ms, x - 1, y - 1, x + w + 1, y + h + 1, 9, Util.withAlpha(ac, (int)(120 * fade)));
            Util.rrect(ms, x, y, x + w, y + h, 8, Util.withAlpha(ac, (int)(48 * fade)));
        } else {
            Util.rrect(ms, x, y, x + w, y + h, 8, Util.withAlpha(0x15151F, (int)(235 * fade)));
        }
        int tw = font.width(text);
        font.drawShadow(ms, text, x + (w - tw) / 2f, y + (h - 8) / 2f, hover ? 0xFFFFFFFF : 0xFFE7E7F0);
    }

    private void drawBackground(MatrixStack ms, float pt) {
        // Lightweight animated gradient; no texture/panorama rendering = friendlier on phones.
        int top = 0xFF05030B;
        int mid = 0xFF0B0718;
        int bottom = 0xFF03030A;
        fill(ms, 0, 0, width, height / 2, top);
        fill(ms, 0, height / 2, width, height, bottom);
        fill(ms, 0, height / 3, width, height * 2 / 3, mid);

        long now = System.currentTimeMillis();
        float pulse = (float)((Math.sin(now / 1400.0) + 1.0) * 0.5);
        int ac = accent(0f);
        int ac2 = accent(1.0f);

        // Soft aurora bands. They are simple rounded strips rather than expensive blur shaders.
        for (int i = 0; i < 5; i++) {
            float phase = now / (1700f + i * 130f) + i * 1.7f;
            int cx = (int)(width * (0.50f + 0.33f * Math.sin(phase)));
            int cy = (int)(height * (0.42f + 0.10f * Math.cos(phase * 0.8f)));
            int rw = 150 + i * 55;
            int rh = 12 + i * 4;
            Util.rrect(ms, cx - rw, cy - rh, cx + rw, cy + rh, rh,
                    Util.withAlpha(i % 2 == 0 ? ac : ac2, (int)((18 + i * 4) * fade)));
        }

        // A few cheap stars/particles.
        for (int i = 0; i < 24; i++) {
            double sx = (i * 83 + 41) % Math.max(1, width);
            double sy = (i * 47 + 23) % Math.max(1, height);
            float twinkle = (float)(0.35 + 0.35 * Math.sin(now / 700.0 + i));
            fill(ms, (int)sx, (int)sy, (int)sx + 1, (int)sy + 1,
                    Util.withAlpha(0xFFFFFFFF, (int)(255 * twinkle * fade)));
        }

        // Vignette-like side panels.
        fill(ms, 0, 0, 34, height, Util.withAlpha(0x000000, (int)(90 * fade)));
        fill(ms, width - 34, 0, width, height, Util.withAlpha(0x000000, (int)(90 * fade)));
        fill(ms, 0, height - 42, width, height, Util.withAlpha(0x000000, (int)(110 * fade)));
    }

    @Override
    public void render(MatrixStack ms, int mx, int my, float pt) {
        float t = Math.min(1f, (System.currentTimeMillis() - openedAt) / 320f);
        fade = 0.12f + 0.88f * t;
        drawBackground(ms, pt);

        int center = width / 2;
        int bw = Math.min(260, Math.max(190, width - 42));
        int bh = 24;
        int gap = 7;
        int total = bh * 4 + gap * 3;
        int startY = height / 2 - total / 2 + 18;

        // Logo
        String title = "AURORA";
        int tw = font.width(title);
        font.drawShadow(ms, title, center - tw / 2f, startY - 86, 0xFFFFFFFF);
        String sub = "CLIENT 1.9";
        int sw = font.width(sub);
        font.drawShadow(ms, sub, center - sw / 2f, startY - 68, accent(0.5f));

        // Small top-right status
        String ver = "Minecraft 1.16.5  •  Forge";
        font.drawShadow(ms, ver, width - font.width(ver) - 10, 10, 0xFF8E8EA3);

        String[] labels = {"Singleplayer", "Multiplayer", "Options", "Quit Game"};
        for (int i = 0; i < labels.length; i++) {
            int y = startY + i * (bh + gap);
            button(ms, labels[i], center - bw / 2, y, bw, bh,
                    over(center - bw / 2, y, bw, bh, mx, my), i * 0.18f);
        }

        // Quick client menu shortcut.
        int qx = 12, qy = height - 31, qw = 92, qh = 20;
        boolean qhvr = over(qx, qy, qw, qh, mx, my);
        Util.rrect(ms, qx, qy, qx + qw, qy + qh, 7,
                Util.withAlpha(qhvr ? accent(0.4f) : 0x171722, qhvr ? 90 : 210));
        font.drawShadow(ms, "Aurora GUI", qx + 13, qy + 6, 0xFFFFFFFF);

        String footer = "Aurora Client 1.9  •  More than just a client";
        font.drawShadow(ms, footer, center - font.width(footer) / 2f, height - 16, 0xFF77778B);
        super.render(ms, mx, my, pt);
    }

    @Override
    public boolean mouseClicked(double mx, double my, int button) {
        if (button != GLFW.GLFW_MOUSE_BUTTON_LEFT) return false;
        int center = width / 2;
        int bw = Math.min(260, Math.max(190, width - 42));
        int bh = 24, gap = 7;
        int total = bh * 4 + gap * 3;
        int startY = height / 2 - total / 2 + 18;
        for (int i = 0; i < 4; i++) {
            int y = startY + i * (bh + gap);
            if (!over(center - bw / 2, y, bw, bh, mx, my)) continue;
            Minecraft mc = Minecraft.getInstance();
            if (i == 0) mc.setScreen(new WorldSelectionScreen(this));
            else if (i == 1) mc.setScreen(new MultiplayerScreen(this));
            else if (i == 2) mc.setScreen(new OptionsScreen(this, mc.options));
            else mc.stop();
            return true;
        }
        if (over(12, height - 31, 92, 20, mx, my)) {
            Minecraft.getInstance().setScreen(new ClickGui());
            return true;
        }
        return super.mouseClicked(mx, my, button);
    }

    @Override
    public boolean keyPressed(int key, int scanCode, int modifiers) {
        if (key == GLFW.GLFW_KEY_ESCAPE) return false;
        return super.keyPressed(key, scanCode, modifiers);
    }
}
