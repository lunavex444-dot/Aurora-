package com.aurora.client;

import net.minecraft.client.Minecraft;

import java.util.Arrays;
import java.util.List;

public class Modules {
    // Combat
    public static final Module TARGETHUD  = new Module("Target HUD", "Здоровье и ник цели", Category.COMBAT, true);
    public static final Module AUTOSPRINT = new Module("AutoSprint", "Авто-бег при ходьбе", Category.COMBAT, false);

    // Combat: KillAura
    public static final Module KILLAURA     = new Module("KillAura", "Авто-атака целей рядом", Category.COMBAT, false);
    public static final Module AURARANGE    = new Module("Aura Range", "Дальность атаки", Category.COMBAT,
            new String[]{"3.0", "3.5", "4.0", "4.5", "5.0", "6.0"});
    public static final Module AURAROTATION = new Module("Aura Rotation", "Поворот к цели", Category.COMBAT,
            new String[]{"Smooth", "Snap", "None"});
    public static final Module AURATARGETS  = new Module("Aura Targets", "Кого бить", Category.COMBAT,
            new String[]{"Players", "Mobs", "All"});
    public static final Module AURAPRIORITY = new Module("Aura Priority", "Приоритет цели", Category.COMBAT,
            new String[]{"Distance", "Health", "Angle"});
    public static final Module AURADELAY    = new Module("Aura Delay", "Скорость ударов", Category.COMBAT,
            new String[]{"Cooldown", "100ms", "60ms"});
    public static final Module AURAFOV     = new Module("Aura FOV", "Угол обзора цели", Category.COMBAT,
            new String[]{"360", "180", "120", "90"});
    public static final Module AURAMODE    = new Module("Aura Mode", "Одна цель или переключение", Category.COMBAT,
            new String[]{"Single", "Switch"});
    public static final Module AURAWALLS   = new Module("Aura Walls", "Бить через стены", Category.COMBAT, false);
    public static final Module AURAWEAPON  = new Module("Aura Weapon", "Только с мечом или топором", Category.COMBAT, false);

    // Combat: aim / clicks
    public static final Module AIMASSIST  = new Module("AimAssist", "Плавное наведение на цель", Category.COMBAT, false);
    public static final Module AIMSPEED   = new Module("Aim Speed", "Скорость наведения", Category.COMBAT,
            new String[]{"Slow", "Medium", "Fast"});
    public static final Module TRIGGERBOT = new Module("TriggerBot", "Бьёт, когда прицел на цели", Category.COMBAT, false);
    public static final Module AUTOCLICKER = new Module("AutoClicker", "Авто-клик при зажатой ЛКМ", Category.COMBAT, false);
    public static final Module CLICKCPS   = new Module("Click CPS", "Скорость автокликера", Category.COMBAT,
            new String[]{"6", "8", "10", "12", "14", "16", "20"});

    // Combat: hit modifiers
    public static final Module CRITICALS   = new Module("Criticals", "Криты на земле (пакеты)", Category.COMBAT, false);
    public static final Module SPRINTRESET = new Module("Sprint Reset", "W-tap: больше отбрасывания", Category.COMBAT, false);
    public static final Module VELOCITY    = new Module("Velocity", "Меньше отбрасывания", Category.COMBAT, false);
    public static final Module VELOCITYAMT = new Module("Velocity Amount", "Сколько отброса оставить", Category.COMBAT,
            new String[]{"0%", "25%", "50%", "75%"});

    // Combat: totem
    public static final Module AUTOTOTEM = new Module("AutoTotem", "Тотем в левую руку", Category.COMBAT, false);
    public static final Module TOTEMHP   = new Module("Totem HP", "Когда брать тотем", Category.COMBAT,
            new String[]{"Always", "10 HP", "6 HP"});

    // Movement
    public static final Module GUIMOVE  = new Module("GuiMove", "Ходьба при открытом меню", Category.MOVEMENT, false);
    public static final Module AUTOJUMP = new Module("AutoJump", "Авто-прыжок на блоки", Category.MOVEMENT, false);

    // HUD
    public static final Module WATERMARK  = new Module("Watermark", "Плашка сверху слева", Category.HUD, true);
    public static final Module COORDS     = new Module("Coordinates", "Координаты XYZ", Category.HUD, true);
    public static final Module ARRAYLIST  = new Module("ArrayList", "Список модулей справа", Category.HUD, true);
    public static final Module KEYSTROKES = new Module("Keystrokes", "WASD, клики и CPS", Category.HUD, false);
    public static final Module ARMOR      = new Module("ArmorHUD", "Броня и прочность", Category.HUD, false);

    // Visuals
    public static final Module FULLBRIGHT  = new Module("Fullbright", "Максимальная яркость", Category.VISUALS, false);
    public static final Module ZOOM        = new Module("Zoom", "Приближение камеры", Category.VISUALS, false);
    public static final Module CROSSHAIR   = new Module("Crosshair", "Свой прицел", Category.VISUALS, false);
    public static final Module CROSSSTYLE  = new Module("Crosshair Style", "Вид прицела", Category.VISUALS,
            new String[]{"Cross", "Dot", "Ring"});

    // Effects: particles
    public static final Module HITPART   = new Module("Hit Particles", "Искры при ударе", Category.EFFECTS, true);
    public static final Module KILLFX    = new Module("Kill Effect", "Взрыв при убийстве", Category.EFFECTS, true);
    public static final Module WORLDPART = new Module("World Particles", "Светлячки вокруг тебя", Category.EFFECTS, false);
    public static final Module LANDING   = new Module("Landing Effects", "Волны при приземлении", Category.EFFECTS, false);
    public static final Module PSTYLE    = new Module("Particle Style", "Вид частиц", Category.EFFECTS,
            new String[]{"Stars", "Orbs", "Sparks", "Mixed"});
    public static final Module PCOLOR    = new Module("Particle Color", "Цвет частиц", Category.EFFECTS,
            new String[]{"Theme", "Rainbow", "White"});
    public static final Module PDENSITY  = new Module("Particle Density", "Количество частиц", Category.EFFECTS,
            new String[]{"Low", "Medium", "High"});
    public static final Module HITSOUND  = new Module("Hit Sound", "Свой звук при ударе", Category.EFFECTS, true);
    public static final Module HITSNDSEL = new Module("Hit Sound Type", "Какой звук играть", Category.EFFECTS, SoundFx.NAMES);
    public static final Module KILLSOUND = new Module("Kill Sound", "Звук при убийстве", Category.EFFECTS, true);
    public static final Module SNDVOL    = new Module("Sound Volume", "Громкость звуков", Category.EFFECTS,
            new String[]{"50%", "75%", "100%"});

    // Cosmetics
    public static final Module CHINAHAT   = new Module("Hat", "Шляпа над головой", Category.COSMETICS, true);
    public static final Module HATSTYLE   = new Module("Hat Style", "Вид шляпы", Category.COSMETICS,
            new String[]{"China", "Halo", "Crown"});
    public static final Module TRAILS     = new Module("Trails", "Светящийся шлейф", Category.COSMETICS, true);
    public static final Module TRAILSTYLE = new Module("Trail Style", "Вид шлейфа", Category.COSMETICS,
            new String[]{"Ribbon", "Sparkle"});
    public static final Module BODYGLOW   = new Module("Body Glow", "Аура вокруг тела", Category.COSMETICS, true);
    public static final Module ORBIT      = new Module("Orbit", "Шары вокруг тебя", Category.COSMETICS, false);
    public static final Module TARGETESP  = new Module("Target ESP", "Кольца вокруг цели", Category.COSMETICS, true);
    public static final Module TARGETSTYLE = new Module("Target Style", "Вид Target ESP", Category.COSMETICS,
            new String[]{"Rings", "Orbs", "Marker"});
    public static final Module COSCOLOR   = new Module("Cosmetic Color", "Цвет косметики", Category.COSMETICS,
            new String[]{"Theme", "Rainbow"});

    // Client
    public static final Module THEME    = new Module("Theme", "Цвет интерфейса", Category.CLIENT,
            new String[]{"Aurora", "Ocean", "Sunset", "Mint", "Cherry", "Gold", "Neon", "Mono"});
    public static final Module ANIMATED = new Module("Animated", "Переливы цвета", Category.CLIENT, true);
    public static final Module SHOWPING = new Module("Show Ping", "Пинг в ватермарке", Category.CLIENT, true);
    public static final Module SHOWCPS  = new Module("Show CPS", "CPS в ватермарке", Category.CLIENT, true);
    public static final Module HUDEDIT  = new Module("HUD Editor", "Перетащи элементы HUD", Category.CLIENT,
            () -> Minecraft.getInstance().setScreen(new HudEditor()));

    public static final List<Module> ALL = Arrays.asList(
            TARGETHUD, AUTOSPRINT,
            KILLAURA, AURARANGE, AURAROTATION, AURATARGETS, AURAPRIORITY, AURADELAY,
            AURAFOV, AURAMODE, AURAWALLS, AURAWEAPON,
            AIMASSIST, AIMSPEED, TRIGGERBOT, AUTOCLICKER, CLICKCPS,
            CRITICALS, SPRINTRESET, VELOCITY, VELOCITYAMT,
            AUTOTOTEM, TOTEMHP,
            GUIMOVE, AUTOJUMP,
            WATERMARK, COORDS, ARRAYLIST, KEYSTROKES, ARMOR,
            FULLBRIGHT, ZOOM, CROSSHAIR, CROSSSTYLE,
            HITPART, KILLFX, WORLDPART, LANDING, PSTYLE, PCOLOR, PDENSITY,
            HITSOUND, HITSNDSEL, KILLSOUND, SNDVOL,
            CHINAHAT, HATSTYLE, TRAILS, TRAILSTYLE, BODYGLOW, ORBIT, TARGETESP, TARGETSTYLE, COSCOLOR,
            THEME, ANIMATED, SHOWPING, SHOWCPS, HUDEDIT);

    static {
        CLICKCPS.mode = 2;    // 10 CPS
        VELOCITYAMT.mode = 2; // 50%
        PSTYLE.mode = 3;      // Mixed
        PDENSITY.mode = 1;    // Medium
        SNDVOL.mode = 1;      // 75%
    }
}
