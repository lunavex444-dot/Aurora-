Aurora Client (Forge 1.16.5)
1) Скачай Forge MDK 1.16.5 (36.2.x) с files.minecraftforge.net
2) Распакуй MDK, удали его папку src, скопируй вместо неё src из этого архива
3) В build.gradle MDK поставь: group = 'com.aurora.client', archivesBaseName = 'auroraclient'
4) Запусти: gradlew build  -> jar будет в build/libs, кидай в папку mods


Aurora Client 1.9 Main Menu: vanilla MainMenuScreen is replaced with AuroraMainMenu. The GUI uses lightweight shapes/animations for better mobile performance.
